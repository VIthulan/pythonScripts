coloredlogs --demo
