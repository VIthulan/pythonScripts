"""
Couch service module to handle couch related functions
"""
import logging
import os
import glob
import math
import datetime

from pulse_agent.utils import sub_process
from pulse_agent.utils.moxy_client import moxy_client
from pulse_agent.utils import file_utils
from pulse_agent.utils.config import config
from pulse_agent.services.dtos.value_desc import ValueDesc
from pulse_agent.services import cinco_identity
from pulse_agent.utils.decorators.try_except import try_except


class Couch(object):
    """
    Couch related methods and attributes
    """

    def __init__(self):
        pass

    def is_couch_running(self):
        """ Returns couch db status """
        couch_running_command = "lsof -i:5984 | grep LIST | grep couchdb"
        logging.debug(couch_running_command)
        couch_running_result = sub_process.p_open_stripped(couch_running_command)

        if couch_running_result == "":
            return "NOT_RUNNING"

        return "RUNNING"

    def get_couchdb_version(self):
        """ returns the version of CouchDB installed on the system. """
        couchdb = sub_process.p_open_no_shell('couchdb -V'.split())
        out, err = couchdb.communicate()
        if err is not None:
            logging.error('Error while getting couchdb version: %s', err)
            return config.ERROR_MESSAGE

        return out.split('\n')[0].split()[4]

    def is_couch_compaction_running(self):
        """
        return true when .compact file is available in /var/lib/couchdb/*
        or /var/lib/couchdb/.*/mrview during 3am-4am
        :return: true/false
        """
        couch_compaction_state = self.check_couch_db_compactions()
        current_time = datetime.datetime.now().time()
        start_time = datetime.datetime.strptime(config.COUCH_COMPACTION_START_TIME,
                                                "%H:%M:%S").time()
        end_time = datetime.datetime.strptime(config.COUCH_COMPACTION_END_TIME, "%H:%M:%S").time()
        return (
            couch_compaction_state.VALUE == config.MESSAGE_COMPACTION_RUNNING
            and start_time <= current_time <= end_time)

    def check_couch_db_compactions(self):
        """
        Checks couch db compactions
        :return: ValueDesc
        """
        try:
            # Finding compaction files  on /var/lib/couchdb/
            command_compact_loc_1 = 'ls -l /var/lib/couchdb/* | grep compact'
            compaction_compact_loc_1 = sub_process.p_open_stripped(command_compact_loc_1)
            logging.info("couch db compactions location 1: %s", compaction_compact_loc_1)

            # Finding compaction files  on /var/lib/couchdb/.*/mrview
            command_compact_loc_2 = 'ls -la /var/lib/couchdb/.*/mrview | grep compact'
            compaction_compact_loc_2 = sub_process.p_open_stripped(command_compact_loc_2)
            logging.info("couch db compactions location 2: %s", compaction_compact_loc_2)

            # All compactions
            compaction = compaction_compact_loc_1 + compaction_compact_loc_2
            logging.info("couch db compactions : %s", compaction)

            if compaction == '':
                logging.info('No CouchDB compaction failures success')
                return ValueDesc()

            logging.info('Compaction may be still running')
            return ValueDesc(value=config.MESSAGE_COMPACTION_RUNNING)

        except Exception as exception:
            logging.exception('Error while checking couch compaction: %s', exception)
            return ValueDesc(value=config.ERROR_MESSAGE)

    def get_couch_db_size(self):
        """
        Get couch db size
        :return: status
        """
        merchant_id = cinco_identity.get_merchant_id()
        couch_db_file_path = "%s%s.couch" % (config.COUCH_DB_FILE_PATH, merchant_id)

        logging.debug('couch db path %s : ', couch_db_file_path)

        size = 0
        error = 'NULL'

        try:
            if os.path.exists(couch_db_file_path):
                couch_db_size_command = "stat -c %%s %s" % couch_db_file_path  # escape the first %s
                logging.info(couch_db_size_command)
                size = int(sub_process.p_open_stripped(couch_db_size_command))
                logging.info('Couch db size in bytes %s :', size)
            else:
                error = 'couch db file is not found'
                logging.error('couch db file is not found')
        except Exception as exception:
            error = 'exception occurred while reading couch db size: %s', exception
            logging.exception('exception occurred while reading couch db size: %s', exception)

        return dict(
            SIZE=size,
            ERROR=error
        )

    def delete_couch_compact_file(self):
        """
        call the moxy end point to delete the partial compaction file
        :return: Status
        """
        try:
            response = moxy_client.delete(config.PARTIAL_COMPACT_FILE_REMOVAL_END_POINT)

            logging.debug("MOXY response - status : %s, text: %s", response.status_code,
                          response.text)

            if response.status_code == 200:
                logging.info('Compact file deleted successfully')
                return 'Compact file deleted successfully'

            logging.error('Error while deleting compact file: %s', response.text)
            return response.text

        except Exception as exception:
            logging.exception(
                'Error while calling moxy endpoint for partial compact file removal: %s', exception)
            return 'Error while calling moxy endpoint for partial compact file removal'

            # check couch corruptions within today and yesterday

    def check_couch_corruptions(self, caller):
        """
        Check if couch corruptions are happening
        :param caller: on-demand/reboot
        :return: status
        """
        couch_corruptions_list = []
        try:
            if file_utils.does_file_exceeds_threshold(config.COUCH_LOG_FILES,
                                                      config.COUCH_FILE_SIZE_THRESHOLD):
                logging.warning("One or more of analyzing files exceeds %s MB in couch logs",
                                config.COUCH_FILE_SIZE_THRESHOLD)
                return ValueDesc(value=config.ERROR_MESSAGE)

            if caller == 'reboot':
                today_status = self.check_couch_corruptions_given_date()
                yesterday_status = self.check_couch_corruptions_given_date(time_delta=1)
                # If exception comes in either method this should return error message
                if today_status == config.ERROR_MESSAGE \
                        or yesterday_status == config.ERROR_MESSAGE:
                    return ValueDesc(value=config.ERROR_MESSAGE)

                couch_corruptions_list = today_status + yesterday_status
            elif caller == 'on-demand':
                # If exception comes in either method this should return error message
                if self.check_couch_corruptions_given_date() == config.ERROR_MESSAGE:
                    return ValueDesc(value=config.ERROR_MESSAGE)
                couch_corruptions_list = self.check_couch_corruptions_given_date()

            couch_corruptions_count = len(couch_corruptions_list)
            logging.info('couch_corruptions_count %s', couch_corruptions_count)

            if couch_corruptions_count == 0:
                return ValueDesc()

            logging.debug('Here is the first line: %s', couch_corruptions_list[0])

            # Getting date_time for the first occurrence of yesterday and today
            couch_corruption_date_time = couch_corruptions_list[0].split(']')[0].split('[')[1]

            return ValueDesc(value=config.MESSAGE_COUCH_CORRUPTION, desc=couch_corruptions_list[0],
                             date=couch_corruption_date_time)
        except Exception as exception:
            logging.exception('Error while checking couch corruption: %s', exception)
            return ValueDesc(value=config.ERROR_MESSAGE)

    def check_couch_corruptions_given_date(self, time_delta=0):
        """
        Check couch corruptions on given date
        :param time_delta: how many days backwards (today:time_delta = 0, yesterday:time_delta = 1)
        :return:
        """
        day = datetime.date.today() - datetime.timedelta(time_delta)
        date = day.strftime("%a, %d %b %Y")
        try:

            command = ('zgrep "file_corruption" ' + config.COUCH_LOG_FILES +
                       ' | grep "' + date + '" | head -1')
            logging.debug(command)
            couch_corruptions_list = sub_process.p_open_stripped(command).splitlines()
            logging.debug('Here is the first line: %s', couch_corruptions_list)
            return couch_corruptions_list

        except Exception as exception:
            logging.exception('Error while getting couch corruptions for today: %s', exception)
            return config.ERROR_MESSAGE

    def check_if_couch_log_exceeds(self):
        """
        Checks if couch log size exceeds
        :return:
        """
        try:
            # File size threshold 500 MB
            FILE_SIZE_THRESHOLD = 500

            # Get all matching files for a file path regex
            matching_files = glob.glob(config.COUCH_LOG_FILES)
            anomalous_files = []

            for matching_file in matching_files:
                statinfo = os.stat(matching_file)
                file_size = statinfo.st_size / math.pow(1024, 2)
                if file_size > FILE_SIZE_THRESHOLD:
                    anomalous_files.append(
                        'file: ' + matching_file + ' size: ' + str(file_size) + ' MB')

            logging.warning('Anomalous couch Files: %s', anomalous_files)

            if anomalous_files:
                return ValueDesc(value=config.MESSAGE_COUCH_LOG_SIZE_EXCEEDS_THRESHOLD,
                                 desc=str(anomalous_files))
            return ValueDesc()

        except Exception as exception:
            logging.exception(
                'Error while getting one or more couch log files exceeds threshold: %s', exception)
            return ValueDesc(value=config.ERROR_MESSAGE)

    @try_except(level='exception', default=ValueDesc())
    def check_if_couch_size_exceeds_threshold(self):
        """
        Checks if couch db size exceeds threshold.
        :return:
        """
        # Couch DB size threshold 2000 MB = 2GB
        DB_SIZE_THRESHOLD = 2048

        couch_db_file = config.COUCH_DB_FILE_PATH + cinco_identity.get_merchant_id() + '.couch'

        stat_info = os.stat(couch_db_file)
        db_size = stat_info.st_size / math.pow(1024, 2)

        if db_size > DB_SIZE_THRESHOLD:
            return ValueDesc(
                value=config.MESSAGE_COUCH_DB_SIZE_EXCEEDS + ': ' + str(
                    DB_SIZE_THRESHOLD) + '. Current size:' + str(db_size),
                desc='Couch DB size:' + str(db_size))
        return ValueDesc()


couch = Couch()
