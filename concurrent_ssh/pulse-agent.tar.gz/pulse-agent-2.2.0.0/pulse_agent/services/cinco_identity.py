"""
This module contains functions that will give details about cinco POS
"""
import logging
import json
import os
import re
from pulse_agent.utils.config import config
from pulse_agent.utils.config_managers import pos_config_manager
from pulse_agent.utils.moxy_client import moxy_client
from pulse_agent.utils import sub_process


def get_merchant_id():
    """
    Get merchant ID
    :return: merchantID
    """
    preference_entries = pos_config_manager.load_pref_entries(config.PREFS_FILE)
    if not preference_entries:
        logging.error("Error: Preference entries empty")
        return 'Error: Preference entries empty'
    return pos_config_manager.get_preference_value(preference_entries, config.MERCHANT_ID)


def get_register_no():
    """
    Get register no
    :return: registerNo
    """
    preference_entries = pos_config_manager.load_pref_entries(config.PREFS_FILE)
    if not preference_entries:
        logging.error("Error: Preference entries empty")
        return 'Error: Preference entries empty'
    return pos_config_manager.get_preference_value(preference_entries, config.STATION_ID)


def get_merchant_name():
    """
    Get merchant name
    :return: merchantName
    """
    try:
        response = moxy_client.get(
                "/data/" + get_merchant_id() + "/_design/merchant/_view/restricted")
        parsed_response = json.loads(response.text)
        merchant_name = json.dumps(parsed_response["rows"][0]["value"]["name"]).strip('"')
        logging.debug("MERCHANT NAME: %s", merchant_name)
        return merchant_name or ''
    except Exception as exception:
        logging.exception('Error while getting merchant name: %s', exception)
        return ''


def get_device_identifier():
    """
    Get device identifier
    :return: combination fo merchantID and RegisterNo
    """
    merchant_id = get_merchant_id()
    register_no = get_register_no()
    if merchant_id == '' or register_no == '':
        return get_mac_address()
    return merchant_id + '-' + register_no


def get_cinco_version():
    """
    Get cinco version
    :return: version
    """
    if not moxy_client.is_new_moxy():
        try:
            command = 'cincoinfo | grep "CincoVersion" | cut -d ":" -f 2'
            logging.debug(command)
            cinco_version = sub_process.p_open_stripped(command)
            logging.info("Cinco version: %s", str(cinco_version))
            return str(cinco_version)
        except Exception as exception:
            logging.exception(
                    'Error while getting the cinco version using old method(cincoinfo): %s',
                    exception)
            return config.ERROR_MESSAGE
    else:
        try:
            response = moxy_client.get(config.CINCO_VERSION_ENDPOINT)
            cinco_version = response.json().get("moxyVersion")

            logging.info("Cinco version: %s", str(cinco_version))

            return str(cinco_version)
        except Exception as exception:
            logging.exception('Error while getting cinco version from moxy end point: %s',
                              exception)
            return config.ERROR_MESSAGE


def get_image_version():
    """
    # Read the Image  Version number
    :return: Image version
    """
    try:
        command = 'grep "VERSION" ' + config.VERSION_INFO + ' | cut -d . -f 2'
        logging.debug(command)
        version = sub_process.p_open_stripped(command)
        logging.info("Image version number %s", str(version))
        return str(version)
    except Exception as exception:
        logging.exception('Error while getting the version number: %s', exception)
        return config.ERROR_MESSAGE


def get_mac_address():
    """ Returns mac address """
    for interface in os.popen('ifconfig -a').read().split('\n\n'):
        if interface.startswith('eth') or interface.startswith('wlan'):
            try:
                return re.search('HWaddr (.+?) ', interface).group(1) or ''
            except Exception as exception:
                logging.exception("Error getting network data for: %s - %s", interface.split()[0],
                                  exception)
                return config.ERROR_MESSAGE
        return config.ERROR_MESSAGE


def is_master():
    """
    Get whether is master
    :return: status
    """
    master_details = dict()

    try:
        # Check ip of the master
        get_master_ip_command = ("grep -o 'data request to master'.* "
                                 "/home/leapset/cinco/logs/moxy.log "
                                 "| tail -1 | grep -o 'http://'.* "
                                 "| cut -d '/' -f 3 | cut -d ':' -f 1")
        logging.info(get_master_ip_command)
        master_ip = sub_process.p_open_stripped(get_master_ip_command)
        logging.info('master is: %s ', master_ip)

        master_details["master.device.ip"] = master_ip

        if master_ip != '':
            if master_ip == 'localhost':
                return True
            return False

        logging.warning("master.device.ip field is empty")
        return None

    except Exception as exception:
        logging.exception("Error: Error reading master ip related data: %s", exception)
        return None
