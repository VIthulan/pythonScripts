"""
tests for moxy module
"""
# core modules
import logging
import datetime
import mock
from mock import Mock

# testing module
from pulse_agent.services.moxy import moxy

# utils
from pulse_agent.utils.config import config
from pulse_agent.services.dtos.value_desc import ValueDesc

logging.basicConfig(level=logging.INFO)


def setup_module(module):
    """
    setup test module
    :param module:
    """
    log = logging.getLogger('setup_module')
    log.info("setup_module module:%s", module.__name__)


def teardown_module(module):
    """
    teardown test module
    :param module:
    """
    log = logging.getLogger('teardown_module')
    log.info("teardown_module module:%s", module.__name__)


def setup_function(function):
    """
    setup test function
    :param function:
    """
    logging.info("setup_function function:%s", function.__name__)


def teardown_function(function):
    """
    teardown test function
    :param function:
    """
    log = logging.getLogger('teardown_function')
    log.info("teardown_function function:%s", function.__name__)


def assert_received_and_expected(received, expected):
    """
    assert all the keys of received and expected object
    :param received: actual object received from test method
    :param expected: expected objected from test method
    :return:
    """
    assert received.VALUE == expected.VALUE
    assert received.DESCRIPTION == expected.DESCRIPTION
    assert received.DATE_TIME == expected.DATE_TIME


@mock.patch('pulse_agent.utils.moxy_client.MoxyClient.get')
def test_get_moxy_state(mock_get):
    """
    test get_moxy_state()
    :param mock_get: mock call to moxy_client get
    """
    # checks whether it works as expected if the moxy return 200
    mock_moxy_response = Mock()
    mock_moxy_response.status_code = 200

    mock_get.return_value = mock_moxy_response

    assert moxy.get_moxy_state() is True
    mock_get.assert_called_with(config.CINCO_VERSION_ENDPOINT)

    # checks whether it works as expected if the moxy returns 404
    mock_moxy_response.status_code = 404
    assert moxy.get_moxy_state() is True

    # check whether it handles exceptions properly
    mock_get.side_effect = Exception
    assert moxy.get_moxy_state() is True


@mock.patch('pulse_agent.services.moxy.moxy.get_moxy_state')
def test_is_moxy_running(mock_get_moxy_state):
    """
    test is_moxy_running()
    :param mock_get_moxy_state: mock call to get_moxy_state()
    """
    # checks whether it works as expected if moxy is actually running
    mock_get_moxy_state.return_value = True
    assert moxy.is_moxy_running() == config.MOXY_IS_RUNNING

    # checks whether it works as expected if moxy isn't actually running
    mock_get_moxy_state.return_value = False
    assert moxy.is_moxy_running() == config.MOXY_IS_NOT_RUNNING


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_running_moxy_version(mock_sub_process):
    """
    test get_running_moxy_version()
    :param mock_sub_process: mock call to pulse_agent.utils.sub_process()
    """
    # checks whether it works as expected if the sub_process execute the command correctly
    mock_sub_process.return_value = '6.24.0.0'
    assert moxy.get_running_moxy_version() == '6.24.0.0'
    assert mock_sub_process.mock_calls == [
        mock.call("unzip -q -c /home/leapset/cinco/moxy.war WEB-INF/classes/version.properties"
                  " | grep moxyVersion= | cut -d '=' -f 2")]

    # check whether it handles exceptions properly
    mock_sub_process.side_effect = Exception
    assert moxy.get_running_moxy_version() is None


@mock.patch('pulse_agent.services.moxy.moxy.get_moxy_state')
def test_check_if_moxy_running_after_gdm_restart(mock_get_moxy_state):
    """
    test check_if_moxy_running_after_gdm_restart()
    :param mock_get_moxy_state: mock call to pulse_agent.services.moxy.moxy.get_moxy_state()
    """
    # checks whether it works as expected if the moxy isn't running
    mock_get_moxy_state.return_value = False
    assert moxy.check_if_moxy_running_after_gdm_restart() == config.MOXY_IS_NOT_RUNNING_AFTER_GDM_RESTART

    # checks whether it works as expected if the moxy is running
    mock_get_moxy_state.return_value = True
    assert moxy.check_if_moxy_running_after_gdm_restart() == config.MOXY_IS_RUNNING_AFTER_GDM_RESTART

    # check whether it handles exceptions properly
    mock_get_moxy_state.side_effect = Exception
    assert moxy.check_if_moxy_running_after_gdm_restart() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_moxy_corruptions_given_day(mock_sub_process):
    """
    test check_moxy_corruptions_given_day()
    :param mock_sub_process: mock call to pulse_agent.utils.sub_process()
    """
    # checks whether it works as expected if the sub_process executes the command correctly
    day = datetime.date.today() - datetime.timedelta(0)
    today_date = day.strftime("%Y-%m-%d")
    command_1 = ('zgrep "invalid entry CRC" ' + config.MOXY_LOG_FILES
                 + ' | grep "' + today_date + '"')

    mock_sub_process.return_value = 'corruption-1\ncorruption-2'
    assert moxy.check_moxy_corruptions_given_day(0) == ['corruption-1', 'corruption-2']
    assert mock_sub_process.mock_calls == [mock.call(command_1)]

    # checks whether it handles given day properly
    day = datetime.date.today() - datetime.timedelta(1)
    yesterday_date = day.strftime("%Y-%m-%d")
    command_2 = ('zgrep "invalid entry CRC" ' + config.MOXY_LOG_FILES
                 + ' | grep "' + yesterday_date + '"')

    assert moxy.check_moxy_corruptions_given_day(1) == ['corruption-1', 'corruption-2']
    assert mock_sub_process.mock_calls == [mock.call(command_1), mock.call(command_2)]

    # check whether it handles exceptions properly
    mock_sub_process.side_effect = Exception
    assert moxy.check_moxy_corruptions_given_day() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.services.moxy.moxy.check_moxy_corruptions_given_day')
def test_check_moxy_corruptions(mock_moxy_corruptions_given_day):
    """
    test check_moxy_corruptions()
    :param mock_moxy_corruptions_given_day: mock call to pulse_agent.services.moxy.check_moxy_corruptions_given_day()
    """
    # checks whether it works as expected if the caller is reboot and error found while getting corruptions
    today_corruptions = ['moxy-corruption-1:@ 24 November 2017', 'corruption-2']
    mock_moxy_corruptions_given_day.side_effect = [config.ERROR_MESSAGE, today_corruptions]
    assert_received_and_expected(moxy.check_moxy_corruptions('reboot'), ValueDesc(value=config.ERROR_MESSAGE))

    # checks whether it works as expected if caller is reboot and no error found while getting corruptions
    mock_moxy_corruptions_given_day.side_effect = [[], []]
    assert_received_and_expected(moxy.check_moxy_corruptions('reboot'), ValueDesc())

    # checks whether it works as expected if caller is on-demand
    mock_moxy_corruptions_given_day.side_effect = [today_corruptions]
    assert_received_and_expected(moxy.check_moxy_corruptions('on-demand'), ValueDesc(
        value=config.MESSAGE_MOXY_CORRUPTIONS_FOUND,
        desc=today_corruptions[0],
        date=':@ 24'
    ))

    # check whether it handles exceptions properly
    mock_moxy_corruptions_given_day.side_effect = Exception
    assert_received_and_expected(moxy.check_moxy_corruptions('on-demand'), ValueDesc(value=config.ERROR_MESSAGE))


@mock.patch('os.readlink')
@mock.patch('os.path.isfile')
@mock.patch('os.path.islink')
def test_check_moxy_war_existence(mock_islink, mock_isfile, mock_readlink):
    """
    test check_moxy_war_existence()
    :param mock_islink: mock call to os.path.islink()
    :param mock_isfile: mock call to os.path.isfile()
    :param mock_readlink: mock call to os.readlink()
    """
    # checks whether it works as expected if the moxy war exists
    mock_isfile.side_effect = [True, True]
    mock_islink.return_value = True
    mock_readlink.return_value = True
    assert_received_and_expected(moxy.check_moxy_war_existence(), ValueDesc())

    # checks whether it works as expected if the symlink is broken
    mock_isfile.side_effect = [True, True]
    mock_islink.return_value = False
    assert_received_and_expected(moxy.check_moxy_war_existence(), ValueDesc(value=config.MOXY_WAR_NOT_FOUND))

    # checks whether it works as expected if the symlink is broken
    mock_isfile.side_effect = [False, True]
    assert_received_and_expected(moxy.check_moxy_war_existence(), ValueDesc(value=config.MOXY_WAR_NOT_FOUND))

    # checks whether it works as expected if the symlink is broken
    mock_isfile.side_effect = [True, False]
    assert_received_and_expected(moxy.check_moxy_war_existence(), ValueDesc(value=config.MOXY_WAR_NOT_FOUND))

    # check whether it handles exceptions properly
    mock_isfile.side_effect = Exception
    assert_received_and_expected(moxy.check_moxy_war_existence(), ValueDesc(value=config.ERROR_MESSAGE))
