
class Response(object):
    """
    Response
    """

    def __init__(self, text=None, status_code=200):
        self.text = text
        self.status_code = status_code
