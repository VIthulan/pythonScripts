"""
Unit tests for the couch module
"""
import math
import datetime
import mock

# Test Module
from pulse_agent.services.couch import couch

from pulse_agent.utils.config import config
from pulse_agent.monitor.pos_diagnosis.dtos import ValueDesc
from pulse_agent.utils.dtos import Response


class StatInfo(object):
    """
    mock StatInfo object
    """

    def __init__(self, st_size=0):
        self.st_size = st_size
        self.st_mtime = 0


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_is_couch_running(
        mock_p_open_stripped):
    """
    Test for is_couch_running
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :return: None
    """

    # When couch is running
    mock_p_open_stripped.return_value = "RUNNING"
    assert couch.is_couch_running() == "RUNNING"

    # When couch is not running
    mock_p_open_stripped.return_value = ""
    assert couch.is_couch_running() == "NOT_RUNNING"


@mock.patch('pulse_agent.services.couch.couch.check_couch_db_compactions')
def test_is_couch_compaction_running(
        mock_check_couch_db_compactions
):
    """
    Test for is_couch_compaction_running
    :param mock_check_couch_db_compactions: magic mock object of check_couch_db_compactions method
    :param mock_now: magic mock object of datetime.now method
    :return: None
    """

    class NewDate(datetime.datetime):
        """
        mock NewDate object
        """

        @classmethod
        def now(cls):
            """
            mock now object
            """
            return cls(2017, 12, 26, 15, 53, 23, 245883)

    datetime.datetime = NewDate

    with mock.patch('datetime.datetime.now') as mock_now:
        # When now is between start time and end time and cuch compaction is running
        mock_now.return_value = datetime.datetime(2017, 12, 26, 3, 8, 22, 338768)
        mock_check_couch_db_compactions.return_value = \
            ValueDesc(value=config.MESSAGE_COMPACTION_RUNNING)

        assert couch.is_couch_compaction_running()

        # When now is between start time and end time and cuch compaction is not running
        mock_now.return_value = datetime.datetime(2017, 12, 26, 3, 8, 22, 338768)
        mock_check_couch_db_compactions.return_value = \
            ValueDesc()

        assert not couch.is_couch_compaction_running()

        # When now is not between start time and end time and cuch compaction is running
        mock_now.return_value = datetime.datetime(2017, 12, 26, 16, 8, 22, 338768)
        mock_check_couch_db_compactions.return_value = \
            ValueDesc(value=config.MESSAGE_COMPACTION_RUNNING)

        assert not couch.is_couch_compaction_running()

        # When now is not between start time and end time and cuch compaction is not running
        mock_now.return_value = datetime.datetime(2017, 12, 26, 16, 8, 22, 338768)
        mock_check_couch_db_compactions.return_value = \
            ValueDesc()

        assert not couch.is_couch_compaction_running()

@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_couch_db_compactions(mock_p_open_stripped):
    """
    Test for check_couch_db_compactions
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :return: None
    """

    # When there are compactions
    mock_p_open_stripped.return_value = 'compaction'
    assert couch.check_couch_db_compactions().VALUE == config.MESSAGE_COMPACTION_RUNNING

    # When there are no compactions
    mock_p_open_stripped.return_value = ''
    assert couch.check_couch_db_compactions().VALUE is None

    # Check if it handles exceptions
    mock_p_open_stripped.side_effect = Exception
    assert couch.check_couch_db_compactions().VALUE == config.ERROR_MESSAGE


@mock.patch('os.path.exists')
@mock.patch('pulse_agent.services.cinco_identity_hos.get_merchant_id')
@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_couch_db_size(
        mock_p_open_stripped,
        mock_get_merchant_id,
        mock_exists):
    """
    Test for get_couch_db_size
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :param mock_get_merchant_id: magic mock object of get_merchant_id method
    :return: None
    """

    # When there are compactions
    mock_p_open_stripped.return_value = 24
    mock_get_merchant_id.return_value = 'merchant_01'
    mock_exists.return_value = True

    ret_val = couch.get_couch_db_size()
    assert ret_val.get('SIZE') == 24
    assert ret_val.get('ERROR') == 'NULL'

    # When there are no compactions
    mock_p_open_stripped.return_value = 24
    mock_get_merchant_id.return_value = 'merchant_01'
    mock_exists.return_value = False

    ret_val = couch.get_couch_db_size()
    assert ret_val.get('SIZE') == 0
    assert ret_val.get('ERROR') == 'couch db file is not found'

    # Check if it handles exceptions
    mock_get_merchant_id.return_value = 'merchant_01'
    mock_p_open_stripped.side_effect = Exception
    mock_exists.return_value = True

    ret_val = couch.get_couch_db_size()
    assert ret_val.get('SIZE') == 0
    assert 'exception occurred while reading couch db size: %s' in ret_val.get('ERROR')


@mock.patch('pulse_agent.utils.rest_client.RestClient.delete')
def test_delete_couch_compact_file(
        mock_rest_client_delete
):
    """
    Test for delete_couch_compact_file
    :param mock_rest_client_delete: magic mock object of delete method
    :return: None
    """

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_delete.return_value = the_response
    assert couch.delete_couch_compact_file() == 'Compact file deleted successfully'

    # When process is unsuccessful
    failed_response = Response(data='descriptive text')
    failed_response.code = "expired"
    failed_response.error_type = "expired"
    failed_response.status_code = 400

    mock_rest_client_delete.return_value = failed_response
    assert couch.delete_couch_compact_file() == '"descriptive text"'

    # Check if it handles exception

    mock_rest_client_delete.side_effect = Exception
    assert couch.delete_couch_compact_file() == 'Error while calling moxy endpoint for partial compact file removal'


@mock.patch('pulse_agent.services.couch.couch.check_couch_corruptions_given_date')
def test_check_couch_corruptions(mock_check_couch_corruptions_given_date):
    """
    Test for check_couch_corruptions
    :param mock_check_couch_corruptions_given_date: magic mock object of check_couch_corruptions_given_date method
    :return: None
    """

    # When caller is reboot and couch curroption check is successfull
    mock_check_couch_corruptions_given_date.return_value = ['corr_01 [03:04]', 'corr_02', 'corr_03']
    ret_val = couch.check_couch_corruptions('reboot')
    mock_check_couch_corruptions_given_date.assert_called_with(time_delta=1)
    assert ret_val.VALUE == config.MESSAGE_COUCH_CORRUPTION
    assert ret_val.DESCRIPTION == 'corr_01 [03:04]'
    assert ret_val.DATE_TIME == '03:04'

    # When caller is reboot and couch curroption check is unsuccessfull
    mock_check_couch_corruptions_given_date.return_value = config.ERROR_MESSAGE
    ret_val = couch.check_couch_corruptions('reboot')
    assert ret_val.VALUE == config.ERROR_MESSAGE
    assert ret_val.DESCRIPTION == ''
    assert ret_val.DATE_TIME is None

    # When caller is on-demand and couch curroption check is successfull
    mock_check_couch_corruptions_given_date.return_value = ['corr_01 [03:04]', 'corr_02', 'corr_03']
    ret_val = couch.check_couch_corruptions('on-demand')
    assert ret_val.VALUE == config.MESSAGE_COUCH_CORRUPTION
    assert ret_val.DESCRIPTION == 'corr_01 [03:04]'
    assert ret_val.DATE_TIME == '03:04'

    # When caller is on-demand and couch curroption check is unsuccessfull
    mock_check_couch_corruptions_given_date.return_value = config.ERROR_MESSAGE
    ret_val = couch.check_couch_corruptions('on-demand')
    assert ret_val.VALUE == config.ERROR_MESSAGE
    assert ret_val.DESCRIPTION == ''
    assert ret_val.DATE_TIME is None


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_couch_corruptions_given_date(
        mock_p_open_stripped):
    """
    Test for check_couch_corruptions_given_date
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :return: None
    """

    # When couch is running
    mock_p_open_stripped.return_value = 'corr_01 [03:04]\ncorr_02\ncorr_03'

    day = datetime.date.today() - datetime.timedelta(1)
    date = day.strftime("%a, %d %b %Y")
    ret_val = couch.check_couch_corruptions_given_date(time_delta=1)
    mock_p_open_stripped.assert_called_with('zgrep "file_corruption" ' + config.COUCH_LOG_FILES +
                                            ' | grep "' + date + '" | head -1')
    assert ret_val == ['corr_01 [03:04]', 'corr_02', 'corr_03']

    # When couch is not running
    mock_p_open_stripped.return_value = ''

    day = datetime.date.today() - datetime.timedelta(1)
    date = day.strftime("%a, %d %b %Y")
    ret_val = couch.check_couch_corruptions_given_date(time_delta=1)
    mock_p_open_stripped.assert_called_with('zgrep "file_corruption" ' + config.COUCH_LOG_FILES +
                                            ' | grep "' + date + '" | head -1')
    assert ret_val == []

    # Check if it handles exceptions
    mock_p_open_stripped.side_effect = Exception

    day = datetime.date.today() - datetime.timedelta(1)
    date = day.strftime("%a, %d %b %Y")
    ret_val = couch.check_couch_corruptions_given_date(time_delta=1)
    assert ret_val == config.ERROR_MESSAGE


@mock.patch('os.stat')
@mock.patch('glob.glob')
def test_check_if_couch_log_exceeds(
        mock_glob,
        mock_stat
):
    """
    Test for check_if_couch_log_exceeds
    :param mock_glob: magic mock object of glob method
    :param mock_stat: magic mock object of stat method
    :return: None
    """

    threshold = 500 * math.pow(1024, 2)

    # when no files exist
    mock_glob.return_value = []

    statinfo = StatInfo(st_size=threshold - 1)
    mock_stat.return_value = statinfo

    ret_val = couch.check_if_couch_log_exceeds()
    mock_stat.assert_not_called()
    assert ret_val.VALUE is None
    assert ret_val.DESCRIPTION == ""
    assert ret_val.DATE_TIME is None

    # when anomalous_files exist
    mock_glob.return_value = ['file_01', 'file_02']

    statinfo = StatInfo(st_size=threshold + 1)
    mock_stat.return_value = statinfo

    ret_val = couch.check_if_couch_log_exceeds()
    assert ret_val.VALUE == config.MESSAGE_COUCH_LOG_SIZE_EXCEEDS_THRESHOLD
    assert ret_val.DESCRIPTION == "['file: file_01 size: 500.000000954 MB', 'file: file_02 size: 500.000000954 MB']"
    assert ret_val.DATE_TIME is None

    # when anomalous_files do not exist
    mock_glob.return_value = ['file_01', 'file_02']

    statinfo = StatInfo(st_size=threshold - 1)
    mock_stat.return_value = statinfo

    ret_val = couch.check_if_couch_log_exceeds()
    assert ret_val.VALUE is None
    assert ret_val.DESCRIPTION == ""
    assert ret_val.DATE_TIME is None

    # Check if it handles exceptions
    mock_glob.side_effect = Exception
    statinfo = StatInfo(st_size=threshold - 1)
    mock_stat.return_value = statinfo
    ret_val = couch.check_if_couch_log_exceeds()
    assert ret_val.VALUE == config.ERROR_MESSAGE
    assert ret_val.DESCRIPTION == ""
    assert ret_val.DATE_TIME is None
