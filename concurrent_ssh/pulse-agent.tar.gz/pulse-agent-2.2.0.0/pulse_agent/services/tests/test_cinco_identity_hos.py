"""
tests for cinco_identity module
"""
# core modules
import logging
import subprocess
import mock
from mock import Mock

# testing module
from pulse_agent.services import cinco_identity

# dtos
from pulse_agent.services.tests.dtos import Response

# helpers
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.load_pref_entries')
@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.get_preference_value')
def test_get_merchant_id(mock_get_preference_value, mock_load_pref_entries):
    """
    test get_merchant_id()
    :param mock_get_preference_value: mock call to pos_config_manager.get_preference_value()
    :param mock_load_pref_entries: mock call to pos_config_manager.load_pref_entries()
    """
    # checks whether it works as expected if no preference entries passed
    mock_load_pref_entries.return_value = []
    assert cinco_identity.get_merchant_id() == 'Error: Preference entries empty'

    # checks whether it works as expected if preference entries are found
    mock_load_pref_entries.return_value = ['merchant-id']
    mock_get_preference_value.return_value = 'merchant-1'
    assert cinco_identity.get_merchant_id() == 'merchant-1'


@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.load_pref_entries')
@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.get_preference_value')
def test_get_register_no(mock_get_preference_value, mock_load_pref_entries):
    """
    test get_merchant_id()
    :param mock_get_preference_value: mock call to pos_config_manager.get_preference_value()
    :param mock_load_pref_entries: mock call to pos_config_manager.load_pref_entries()
    """
    # checks whether it works as expected if no preference entries passed
    mock_load_pref_entries.return_value = []
    assert cinco_identity.get_register_no() == 'Error: Preference entries empty'

    # checks whether it works as expected if preference entries are found
    mock_load_pref_entries.return_value = ['station-id']
    mock_get_preference_value.return_value = 'station-1'
    assert cinco_identity.get_register_no() == 'station-1'


@mock.patch('pulse_agent.utils.moxy_client.moxy_client.get')
def test_get_merchant_name(mock_moxy_client_get):
    """
    test get_merchant_name()
    :param mock_moxy_client_get: mock call to pulse_agent.utils.moxy_client.moxy_client.get()
    """
    # checks whether it works as expected if the moxy is re-architectured
    mock_moxy_client_get.return_value = Response(text='{"rows": [{"value": {"name": "beautyB"}}]}')
    assert cinco_identity.get_merchant_name() == 'beautyB'

    # checks whether it handles exceptions properly
    mock_moxy_client_get.side_effect = Exception
    assert cinco_identity.get_merchant_name() == ''
    
    
@mock.patch('pulse_agent.services.cinco_identity.get_merchant_id')
@mock.patch('pulse_agent.services.cinco_identity.get_register_no')
@mock.patch('pulse_agent.services.cinco_identity.get_mac_address')
def test_get_device_identifier(mock_get_mac_address, mock_get_register_no, mock_get_merchant_id):
    """
    test get_device_identifier()
    :param mock_get_mac_address: mock call to cinco_identity.get_mac_address()
    :param mock_get_register_no: mock call to cinco_identity.get_register_no()
    :param mock_get_merchant_id: mock call to cinco_identity.get_merchant_id()
    """
    # checks whether it works as expected
    mock_get_merchant_id.return_value = 'merchant-1'
    mock_get_register_no.return_value = 'register-1'
    assert cinco_identity.get_device_identifier() == 'merchant-1-register-1'

    # checks whether it works as expected if merchant id or register no is ""
    mock_get_merchant_id.return_value = ''
    mock_get_mac_address.return_value = 'ww:xx:yy:zz'
    assert cinco_identity.get_device_identifier() == 'ww:xx:yy:zz'


@mock.patch('pulse_agent.utils.moxy_client.moxy_client.is_new_moxy')
@mock.patch('pulse_agent.utils.moxy_client.moxy_client.get')
@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_cinco_version(mock_p_open_stripped, mock_get, mock_is_new_moxy):
    """
    test get_cinco_version()
    :param mock_p_open_stripped: mock call to sub_process.mock_p_open_stripped()
    :param mock_get: mock call to moxy_client.get()
    :param mock_is_new_moxy: mock call to moxy_client.is_new_moxy()
    """
    # checks whether it works as expected if moxy is re-architectured
    mock_is_new_moxy.return_value = True
    mock_get.return_value = Mock(json=Mock(return_value={"moxyVersion": "6.24.0.0"}))
    assert cinco_identity.get_cinco_version() == "6.24.0.0"

    # checks whether it works as expected if moxy isn't re-architectured
    mock_is_new_moxy.return_value = False
    mock_p_open_stripped.return_value = '6.24.1.0'
    assert cinco_identity.get_cinco_version() == '6.24.1.0'

    # checks whether it handles exceptions properly
    mock_is_new_moxy.return_value = True
    mock_get.side_effect = Exception
    assert cinco_identity.get_cinco_version() == config.ERROR_MESSAGE

    mock_is_new_moxy.return_value = False
    mock_p_open_stripped.side_effect = Exception
    assert cinco_identity.get_cinco_version() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_image_version(mock_p_open_stripped):
    """
    test get_image_version()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if sub process works correctly
    mock_p_open_stripped.return_value = '24'
    assert cinco_identity.get_image_version() == '24'

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert cinco_identity.get_image_version() == config.ERROR_MESSAGE


@mock.patch('os.popen')
def test_get_mac_address(mock_popen):
    """
    test get_mac_address()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected if interface is up
    mock_popen.return_value = Mock(read=Mock(return_value='eth0 HWaddr hwadd1 HWaddr hwadd2 \n\n'))
    assert cinco_identity.get_mac_address() == 'hwadd1'

    # checks whether it works as expected if interface is not up
    mock_popen.return_value = Mock(read=Mock(return_value='inet HWaddr hwadd1 HWaddr hwadd2 \n\n'))
    assert cinco_identity.get_mac_address() == config.ERROR_MESSAGE

    # checks whether it handles exceptions properly
    mock_popen.return_value = Mock(read=Mock(return_value='eth0 HWaddr hwadd1\n\n'))
    assert cinco_identity.get_mac_address() == config.ERROR_MESSAGE
