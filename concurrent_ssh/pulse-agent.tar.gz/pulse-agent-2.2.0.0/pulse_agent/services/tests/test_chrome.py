"""
tests for chrome module
"""
# core modules
import logging
import time
import mock
from mock import Mock

# testing module
from pulse_agent.services.chrome import chrome

# utils
from pulse_agent.utils.config import config
from pulse_agent.services.dtos.value_desc import ValueDesc

logging.basicConfig(level=logging.INFO)


def setup_module(module):
    """
    setup test module
    :param module:
    """
    log = logging.getLogger('setup_module')
    log.info("setup_module module:%s", module.__name__)


def teardown_module(module):
    """
    teardown test module
    :param module:
    """
    log = logging.getLogger('teardown_module')
    log.info("teardown_module module:%s", module.__name__)


def setup_function(function):
    """
    setup test function
    :param function:
    """
    logging.info("setup_function function:%s", function.__name__)


def teardown_function(function):
    """
    teardown test function
    :param function:
    """
    log = logging.getLogger('teardown_function')
    log.info("teardown_function function:%s", function.__name__)


def assert_received_and_expected(received, expected):
    """
    assert all the keys of received and expected object
    :param received: actual object received from test method
    :param expected: expected objected from test method
    :return:
    """
    assert received.VALUE == expected.VALUE
    assert received.DESCRIPTION == expected.DESCRIPTION
    assert received.DATE_TIME == expected.DATE_TIME


@mock.patch('pulse_agent.utils.sub_process.p_open')
def test_is_chrome_running(mock_p_open):
    """
    test is_chrome_running()
    :param mock_p_open: mock call to pulse_agent.utils.sub_process.p_open()
    """
    # checks whether it works as expected if the chrome is running
    read = Mock(return_value='-kiosk chrome')
    stdout = Mock(read=read)
    chrome_running_command = Mock(stdout=stdout)

    mock_p_open.side_effect = [chrome_running_command]
    command = "ps -ef | grep chrome"

    assert chrome.is_chrome_running() == 'RUNNING'
    assert mock_p_open.mock_calls == [mock.call(command)]

    # checks whether it works as expected if the chrome isn't running
    read = Mock(return_value='-no chrome')
    stdout = Mock(read=read)
    chrome_running_command = Mock(stdout=stdout)

    mock_p_open.side_effect = [chrome_running_command]
    assert chrome.is_chrome_running() == 'NOT_RUNNING'


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_find_pattern_in_chrome_logs(mock_p_open_stripped):
    """
    test find_pattern_in_chrome_logs()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if the logs available within given time frame
    path = '/chrome_log'
    pattern = 'couch indexing time out'
    start_time = 1510460000
    end_time = 1510480000

    # 12-Nov 12:30:00 = 1510470000
    mock_p_open_stripped.return_value = '2017 11-Nov 12:30:00, 12-Nov 12:30:00'

    assert not chrome.find_pattern_in_chrome_logs(path, pattern, start_time, end_time)
    assert mock_p_open_stripped.mock_calls == [mock.call('grep "%s" %s' % (pattern, path))]

    # checks whether it works as expected if the logs aren't available within given time frame
    assert not chrome.find_pattern_in_chrome_logs(path, pattern, start_time, start_time)

    # checks whether it works as expected if the logs aren't available
    mock_p_open_stripped.return_value = ''
    assert not chrome.find_pattern_in_chrome_logs(path, pattern, start_time, start_time)

    # check whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert not chrome.find_pattern_in_chrome_logs(path, pattern, start_time, end_time)


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_failed_orders(mock_p_open_stripped):
    """
    test check_failed_orders()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if there are failed orders
    today_date = time.strftime("%d-%b")
    command = ("zgrep '" + today_date + "' " + config.CHROME_DEBUG_LOGS +
               " |grep 'TICKET_SAVING_ERROR'"
               "| cut -d ',' -f 1 | cut -d ']' -f 3 | cut -d ' ' -f  2,3")
    mock_p_open_stripped.return_value = 'failed-order-1\nfailed-order-2'

    assert_received_and_expected(chrome.check_failed_orders(), ValueDesc(
        value=config.MESSAGE_FAILED_ORDER_FOUND,
        desc=str(['failed-order-1', 'failed-order-2'])
    ))
    assert mock_p_open_stripped.mock_calls == [mock.call(command)]

    # checks whether it works as expected if there are no failed orders
    mock_p_open_stripped.return_value = ''
    assert_received_and_expected(chrome.check_failed_orders(), ValueDesc())

    # check whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert_received_and_expected(chrome.check_failed_orders(), ValueDesc(value=config.ERROR_MESSAGE))
