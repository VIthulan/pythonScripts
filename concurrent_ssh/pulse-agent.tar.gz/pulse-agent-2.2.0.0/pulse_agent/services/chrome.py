"""
Chrome related service
"""
import logging
import re
import time
import sys
from pulse_agent.utils import sub_process
from pulse_agent.utils import regex_finder
from pulse_agent.utils.config import config
from pulse_agent.services.dtos.value_desc import ValueDesc


class Chrome(object):
    """
    Chrome class with chrome related attributes and its methods
    """

    def __init__(self):
        pass

    def is_chrome_running(self):
        """
        Checks whether chrome is running
        :return: status
        """
        chrome_check_command = "ps -ef | grep chrome"
        logging.info(chrome_check_command)
        chrome_check_result = sub_process.p_open(chrome_check_command)
        chrome_check_result = chrome_check_result.stdout.read().strip(' ')

        if "-kiosk" in chrome_check_result:
            return "RUNNING"

        return "NOT_RUNNING"

    def find_pattern_in_chrome_logs(self, path, pattern, start_time=0, end_time=sys.maxint):
        """
        Find patterns in chrome logs
        :param path:
        :param pattern:
        :param start_time:
        :param end_time:
        :return:
        """
        command = 'grep "%s" %s' % (pattern, path)
        time_pattern = "%Y-%d-%b %H:%M:%S"
        try:
            results = sub_process.p_open_stripped(command)
            time_stamps = re.findall(r"\d{2}-[A-z][a-z]{2} \d{2}:\d{2}:\d{2}", results)

            if time_stamps:
                latest_timestamp = time_stamps[len(time_stamps) - 1]
                log_latest_time_epoch = int(
                    time.mktime(time.strptime('%s-%s' % (time.strftime("%Y"), latest_timestamp),
                                              time_pattern)))
                if start_time <= log_latest_time_epoch <= end_time:
                    return True
            return False
        except Exception as exception:
            logging.exception("Error while finding pattern :%s", exception)
            return False

    def check_failed_orders(self):
        """
        Get failed order from chrome debug log
        :return:
        """
        try:
            today_date = time.strftime("%d-%b")
            command = ("zgrep '" + today_date + "' " + config.CHROME_DEBUG_LOGS +
                       " |grep 'TICKET_SAVING_ERROR'"
                       "| cut -d ',' -f 1 | cut -d ']' -f 3 | cut -d ' ' -f  2,3")
            logging.debug(command)
            failed_order_timestamps = sub_process.p_open_stripped(command)
            failed_order_list = failed_order_timestamps.splitlines()

            if failed_order_timestamps:
                logging.warning('Failed order result: %s', str(failed_order_list))
                return ValueDesc(value=config.MESSAGE_FAILED_ORDER_FOUND,
                                 desc=str(failed_order_list))

            return ValueDesc()
        except Exception as exception:
            logging.exception("Error while finding failed order in chrome debug log: %s", exception)
            return ValueDesc(value=config.ERROR_MESSAGE)

    def get_self_reported_errors(self):
        """
        Get self reported errors from chrome logs
        :return: ValueDesc
        """
        try:
            regex = regex_finder.get_regex_for_time(15)
            command = ("zgrep 'ERROR_SELF_REPORT' " + config.CHROME_DEBUG_LOGS +
                       " | grep -E '" + regex + "'")
            logging.debug(command)
            time_stamps_array = sub_process.p_open_stripped(command).splitlines()

            if time_stamps_array:
                self_reported_error_list = []
                for error in time_stamps_array:

                    # Assumption : The last character of the string is a closing bracket.
                    # If the format changes, the method should be refactored.

                    if error.find("{") >= 0:
                        self_reported_error_list.append(error[error.find("{"):])

                logging.debug('result of self reported error timestamps: %s',
                              str(self_reported_error_list))
                return ValueDesc(value=config.ERROR_SELF_REPORT_FOUND,
                                 desc=self_reported_error_list)
            return ValueDesc(desc=[])
        except Exception as exception:
            logging.exception("Error while finding self reported errors in chrome debug log: %s",
                              exception)
            return ValueDesc(value=config.ERROR_MESSAGE, desc=[])


chrome = Chrome()
