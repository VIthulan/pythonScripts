"""
This is a service module that gives details about Moxy
"""
import datetime
import logging
import os
import time

from pulse_agent.services.dtos.value_desc import ValueDesc
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config
from pulse_agent.utils.decorators.accumulator import accumulator
from pulse_agent.utils.decorators.skip_upgrade_window import skip_upgrade_window
from pulse_agent.utils.moxy_client import moxy_client


class Moxy(object):
    """
    Moxy class to handle moxy related methods and attributes
    """

    def __init__(self):
        self.is_moxy_running_array = [True, True, True, True]

    def is_moxy_running(self):
        """
        Checks whether moxy is running
        :return: state
        """
        if self.get_moxy_state():
            return config.MOXY_IS_RUNNING
        return config.MOXY_IS_NOT_RUNNING

    @accumulator(threshold=30, default_response=True)
    def get_moxy_state(self):
        """
        Get current Moxy state
        :return:  true/false
        """
        try:
            response = moxy_client.get(config.CINCO_VERSION_ENDPOINT)
            status_code = response.status_code
            if status_code == 200:
                logging.debug("moxy is running.")
                return True
            return False
        except Exception as exception:
            logging.exception("Error while getting moxy state : %s", exception)
            return False

    def check_moxy_corruptions(self, caller):
        """
        Checks moxy corruptions
        :param caller: on-demand/ reboot
        :return: status
        """
        moxy_corruptions_list = []
        try:

            if caller == 'reboot':
                yesterday_corruptions = self.check_moxy_corruptions_given_day(timedelta=1)
                today_corruptions = self.check_moxy_corruptions_given_day(timedelta=0)
                if yesterday_corruptions == config.ERROR_MESSAGE or today_corruptions == config.ERROR_MESSAGE:
                    return ValueDesc(value=config.ERROR_MESSAGE)
                moxy_corruptions_list = yesterday_corruptions + today_corruptions
            elif caller == 'on-demand':
                today_corruptions = self.check_moxy_corruptions_given_day(timedelta=0)
                if today_corruptions == config.ERROR_MESSAGE:
                    return ValueDesc(value=config.ERROR_MESSAGE)
                moxy_corruptions_list = today_corruptions

            moxy_corruptions_count = len(moxy_corruptions_list)
            if moxy_corruptions_count == 0:
                logging.debug('No moxy CRC check error Success')
                return ValueDesc()

            logging.warning('Moxy Corruptions is found')

            # Getting date_time for the first occurance of yesterday and today
            moxy_corruption = moxy_corruptions_list[0]
            moxy_corruption_splitted = moxy_corruption.split(' ')
            moxy_corruption_date_time = \
                (moxy_corruption_splitted[0] + ' ' + moxy_corruption_splitted[1]).split(',')[0]
            moxy_corruption_date_time = moxy_corruption_date_time.replace(
                moxy_corruption_date_time.split(':')[0], '')

            return ValueDesc(value=config.MESSAGE_MOXY_CORRUPTIONS_FOUND,
                             desc=moxy_corruptions_list[0], date=moxy_corruption_date_time)
        except Exception as exception:
            logging.exception('Error while checking moxy corruptions: %s', exception)
            return ValueDesc(value=config.ERROR_MESSAGE)

    def check_moxy_corruptions_given_day(self, timedelta=0):
        """
        Checks moxy corruption today / yesterday
        :param timedelta: today : 0, yesterday : 1
        :return: status
        """

        try:
            day = datetime.date.today() - datetime.timedelta(timedelta)
            day_date = day.strftime("%Y-%m-%d")
            command = ('zgrep "invalid entry CRC" ' + config.MOXY_LOG_FILES
                       + ' | grep "' + day_date + '"')
            logging.debug('moxy crp command : %s', command)
            moxycrp_list = sub_process.p_open_stripped(command).splitlines()
            logging.debug('Moxy Corruptions: %s', moxycrp_list)
            return moxycrp_list

        except Exception as exception:
            logging.exception('Error while getting moxy corruptions for given day: %s', exception)
            return config.ERROR_MESSAGE

    def get_running_moxy_version(self):
        """
        Get running moxy version
        :return: version
        """
        try:
            command = ("unzip -q -c /home/leapset/cinco/moxy.war WEB-INF/classes/version.properties"
                       " | grep moxyVersion= | cut -d '=' -f 2")

            running_moxy_version = sub_process.p_open_stripped(command)
            logging.info("Running moxy version captured: %s", running_moxy_version)
            return running_moxy_version

        except Exception as exception:
            logging.exception("Error while capturing running moxy version: %s", exception)

    @skip_upgrade_window()
    def check_moxy_war_existence(self):
        """
        Checks whether moxy.war file exists
        :return: Status
        """
        try:
            if (os.path.isfile(config.MOXY_WAR_PATH) is True) \
                    and (os.path.islink(config.MOXY_WAR_PATH) is True):
                if os.path.isfile(os.readlink(config.MOXY_WAR_PATH)) is True:
                    return ValueDesc()
            return ValueDesc(value=config.MOXY_WAR_NOT_FOUND)
        except Exception as exception:
            logging.exception('Error while checking moxy.war existence: %s', exception)
            return ValueDesc(value=config.ERROR_MESSAGE)

    def check_if_moxy_running_after_gdm_restart(self):
        """
        check_if_moxy_running_after_gdm_restart
        :return: status
        """
        try:
            success_message = self.get_moxy_state()
            if not success_message:
                return config.MOXY_IS_NOT_RUNNING_AFTER_GDM_RESTART
            return config.MOXY_IS_RUNNING_AFTER_GDM_RESTART
        except Exception as exception:
            logging.exception('Error while checking moxy state after gdm restart: %s', exception)
            return config.ERROR_MESSAGE

    def is_time_not_synchronized(self):
        """
        Checks pos time and actual time with moxy
        Compare pos time and actual time
        :return:
        """
        time_not_synced = False
        description = ""
        delta = 5

        try:
            start_time = float(time.time())

            response = moxy_client.get(config.ACTUAL_TIME_END_POINT)
            logging.debug(
                "[POS TIME AND ACTUAL TIME] MOXY response: %s", response)
            if int(response.status_code) == 200:
                server_time = float(int(response.json().get("actualTime")) / 1000)
                end_time = float(time.time())

                logging.debug(
                    "[POS TIME AND ACTUAL TIME] start_time: %s, server_time: %s, end_time: %s",
                    start_time - delta,
                    server_time,
                    end_time + delta
                )

                if server_time < 0:
                    return time_not_synced, description

                if not start_time - delta <= server_time <= end_time + delta:
                    description = "%s. request initiated at: %s, server_time: %s, response received at: %s" % (
                        config.TIME_NOT_SYNCED_DESC,
                        start_time - delta,
                        server_time,
                        end_time + delta
                    )
                    time_not_synced = True
        except Exception as exception:
            logging.exception('Error while comparing POS time and actual time: %s', exception)

        logging.info(
            "[POS TIME AND ACTUAL TIME] END CHECKING. is time out of sync: %s, description: %s",
            time_not_synced, description
        )
        return time_not_synced, description


moxy = Moxy()
