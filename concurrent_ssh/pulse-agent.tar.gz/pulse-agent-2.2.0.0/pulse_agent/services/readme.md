##### Notes
1. The `_hos` suffix is used to indicate higher order service. HOS modules are allowed to import other non
HOS services. Non HOS modules are not supposed to import any other service modules.