"""
This module contains all DTOS that are being used by services classes
"""


# pylint: skip-file
# Pylint warns All Caps variables are not invalid

class ValueDesc(object):
    """
    ValueDesc
    """

    def __init__(self, value=None, desc='', date=None):
        self.VALUE = value
        self.DESCRIPTION = desc
        self.DATE_TIME = date
