"""
32bit to 64bit image upgrade facade layer
"""

import logging
from pulse_agent.actuator.image_upgrade import image_upgrader
from pulse_agent.monitor.system_stats.system_stats import system_stats
from pulse_agent.utils.config import config
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils import json_utils


class ImageUpgradeFacade(object):
    """
    Image upgrade process facade
    """

    def __init__(self):
        self.prev_flag = image_upgrader.get_latest_flag()
        self.processor_architecture = system_stats.get_processor_architecture()
        self.upgrade_checkups = True

    def insert_flag(self, flag):
        """
        Insert a flag into image_upgrade directory
        :param flag: flag name
        """
        logging.warning('Received request to insert upgrade flag: %s', flag)
        if not image_upgrader.is_upgrade_initiated() and image_upgrader.get_flag_score(flag) == 1:
            image_upgrader.initiate_upgrade_process()
            image_upgrader.insert_flag(flag)

        latest_flag = image_upgrader.get_latest_flag()
        # Do not insert latter flag if previous flags are not completed
        if image_upgrader.get_flag_score(flag) > image_upgrader.get_flag_score(latest_flag):
            image_upgrader.insert_flag(flag)
            latest_flag = image_upgrader.get_latest_flag()
            image_upgrade_response = dict(
                FLAG=latest_flag,
                DESCRIPTION='null'
            )

            logging.debug('Sending latest flag after inserting new flag to API: %s',
                          json_utils.get_json_dump(image_upgrade_response))

            pulse_client.post(config.IMAGE_UPGRADE_FLAG_END_POINT, body=image_upgrade_response)
        else:
            logging.debug(
                'Not inserting requested flag since current latest flag: %s, received flag: %s',
                latest_flag, flag)
            image_upgrade_response = dict(
                FLAG=latest_flag,
                DESCRIPTION='Not inserting requested flag since current '
                            'latest flag: %s, received flag: %s' % (latest_flag, flag)
            )

            logging.debug('Sending latest flag to API: %s',
                          json_utils.get_json_dump(image_upgrade_response))

            pulse_client.post(config.IMAGE_UPGRADE_FLAG_END_POINT, body=image_upgrade_response)

    def image_upgrade_routine(self):
        """
        Image upgrade checkups routine
        """
        latest_flag = image_upgrader.get_latest_flag()
        if latest_flag is None:
            return True
        if latest_flag != self.prev_flag:
            logging.debug('Image upgrade Flag change detected, Previous: %s, Latest: %s',
                          self.prev_flag,
                          latest_flag)

            image_upgrade_response = dict(
                FLAG=latest_flag,
                DESCRIPTION='null'
            )

            logging.debug('Sending latest flag change detection to API: %s',
                          json_utils.get_json_dump(image_upgrade_response))

            pulse_client.post(config.IMAGE_UPGRADE_FLAG_END_POINT, body=image_upgrade_response)
            self.prev_flag = latest_flag

        flag_score = image_upgrader.get_flag_score(latest_flag)
        # If the flag score is even number, then according to scores map the flag
        # should've been set by the SWAT team which will be activated in restart time.
        # Thus no need of routine checkups
        if flag_score != 0 and flag_score % 2 == 0:
            logging.debug(
                'Latest flag: %s, Hence stopping flag change detection routine till next restart',
                latest_flag)
            image_upgrade_response = dict(
                FLAG=latest_flag,
                DESCRIPTION='null'
            )
            pulse_client.post(config.IMAGE_UPGRADE_FLAG_END_POINT, body=image_upgrade_response)
            return False
        return True

    def upgrade_checkup_warden(self):
        """
        Upgrade checkups warden
        """
        if self.processor_architecture != config.PROCESSOR_32_BIT and not image_upgrader.is_upgrade_initiated():
            logging.debug('Processor architecture: %s and image_upgrade directory is not available.'
                          'Hence, no need of upgrade routine checkups', self.processor_architecture)
            return False

        if image_upgrader.is_upgrade_initiated():
            logging.debug('32bit to 64bit image upgrade process is activated')
            if self.upgrade_checkups is True:
                self.upgrade_checkups = self.image_upgrade_routine()

        return self.upgrade_checkups

    def upgrade_flag_status(self):
        """
        Sync latest flag details with API
        :return: Latest flag
        """
        latest_flag = image_upgrader.get_latest_flag()
        image_upgrade_response = dict(
            FLAG=latest_flag,
            DESCRIPTION='null'
        )
        logging.debug('Sending latest flag change detection to API: %s',
                      json_utils.get_json_dump(image_upgrade_response))
        pulse_client.post(config.IMAGE_UPGRADE_FLAG_END_POINT, body=image_upgrade_response)


image_upgrader_facade = ImageUpgradeFacade()
