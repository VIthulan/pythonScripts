"""
This module will contain functions related to do 32bit to 64bit image upgrade procedure
"""
import os
import logging
from pulse_agent.utils.config import config

# Scores map
# User initiated actions will have flags score in odd numbers
# POS initiated actions will have scores in even numbers
# Any error flags should have scores >= 10

SCORES_MAP = {
    'download.flag': 1,
    'download_success.flag': 2,
    'upgrade.flag': 3,
    'upgrade_success.flag': 4,
    'download_failed.flag': 10,
    'upgrade_failed.flag': 30,
    'upgrade_verification_failed.flag': 32
}

UPGRADE_FLAGS_LIST = ['download.flag', 'upgrade.flag']


def is_upgrade_initiated():
    """
    Checks if 32bit to 64bit image upgrade initiated
    :return: True/False
    """
    try:
        return os.path.isdir(config.IMAGE_UPGRADE_FLAG_PATH)
    except Exception as exception:
        logging.exception(
            'Exception occurred while checking 32bit - 64bit OS upgrade activation: %s', exception)
        return False


def initiate_upgrade_process():
    """
    Initiate upgrade process by creating upgrade directory
    """
    try:
        os.makedirs(config.IMAGE_UPGRADE_FLAG_PATH, 0755)
    except Exception as exception:
        logging.exception('Exception while creating directory: %s : %s',
                          config.IMAGE_UPGRADE_FLAG_PATH, exception)


def insert_flag(flag):
    """
    Insert flag into upgrade flag directory
    :param flag: flag name
    """
    try:
        if os.path.exists(config.IMAGE_UPGRADE_FLAG_PATH) and flag in UPGRADE_FLAGS_LIST:
            logging.warning('Inserting upgrade flag: %s', flag)
            os.mknod(config.IMAGE_UPGRADE_FLAG_PATH + '/' + flag)
            return True

        logging.error('%s path does not exists or flag %s is not valid',
                      config.IMAGE_UPGRADE_FLAG_PATH, flag)
        return False
    except Exception as exception:
        logging.exception('Exception while inserting the flag: %s', exception)
        return False


def get_latest_flag():
    """
    Checks the latest flag is set based on the scores map context
    :return: Latest flag, None if unexpected things occurred
    """
    try:
        if not os.path.exists(config.IMAGE_UPGRADE_FLAG_PATH):
            return None

        flags_list = os.listdir(config.IMAGE_UPGRADE_FLAG_PATH)
        if not flags_list:
            return None

        max_flag = None
        for flag in flags_list:
            if max_flag is None:
                max_flag = flag
                continue
            if SCORES_MAP.get(flag) is not None:
                if SCORES_MAP.get(max_flag) < SCORES_MAP.get(flag):
                    max_flag = flag
        logging.debug('Latest upgrade flag: %s', max_flag)
        return max_flag
    except Exception as exception:
        logging.exception('Exception while getting the latest image upgrade flag: %s', exception)
        return None


def get_flag_score(flag):
    """
    Get flag score for given flag
    :param flag: flag name
    :return: score
    """
    try:
        if flag is None:
            return 0
        if SCORES_MAP.get(flag) is not None:
            return SCORES_MAP.get(flag)
        return 0
    except Exception as exception:
        logging.exception('Exception getting the flag: %s score: %s', flag, exception)
        return 0
