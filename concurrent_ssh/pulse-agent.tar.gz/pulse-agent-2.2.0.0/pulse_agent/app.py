"""
    This module contains App class, Threads and Worker classes
"""
from Queue import Queue
from threading import Thread
import logging
from time import sleep
from pulse_agent.monitor import job_manager
from pulse_agent.utils.config import config
from pulse_agent.websocket.ws_manager import WSManager


class Worker(Thread):
    """ Thread executing tasks from a given tasks queue """

    def __init__(self, tasks):
        Thread.__init__(self)
        self.tasks = tasks
        self.daemon = True
        self.start()

    def run(self):
        while True:
            func, args, kargs = self.tasks.get()
            try:
                if kargs['name']:
                    self.setName(kargs['name'])
                    del kargs['name']
                func(*args, **kargs)
            except Exception as exception:
                # An exception happened in this thread
                logging.exception(exception)

            finally:
                # Mark this task as done, whether an exception happened or not
                self.tasks.task_done()


class ThreadPool(object):
    """ Pool of threads consuming tasks from a queue """

    def __init__(self, num_threads):
        self.tasks = Queue(num_threads)
        for _ in range(num_threads):
            Worker(self.tasks)

    def add_task(self, func, *args, **kargs):
        """ Add a task to the queue """
        self.tasks.put((func, args, kargs))

    def map(self, func, args_list):
        """ Add a list of tasks to the queue """
        for args in args_list:
            self.add_task(func, args)

    def wait_completion(self):
        """ Wait for completion of all the tasks in the queue """
        self.tasks.join()


class App(object):
    """ Coordinator """

    def __init__(self):
        self.pool = ThreadPool(config.THREAD_POOL_SIZE)
        self.pulse_job_manager = None

    def initialize(self):
        """
        Initialize App
        :return:
        """
        dedicated_socket_manager = WSManager(config.DEDICATED)
        dev_socket_manager = WSManager(config.DEV)

        self.pool.add_task(dedicated_socket_manager.start_job, name='Dedicated-WS')
        self.pool.add_task(dev_socket_manager.start_job, name='Dev-WS')

        # initiate worker jobs
        self.pulse_job_manager = job_manager.JobManager(dedicated_socket_manager.get_client(),
                                                        dev_socket_manager.get_client())
        sleep(2)

        job_manager.process_initial_tasks()

    def start_all_interval_jobs(self):
        """
        This will start all worker threads of pulse agent with given interval
        :return:
        """

        self.pool.add_task(self.pulse_job_manager.send_system_stats_update, config.UPDATER_INTERVAL,
                           name='Heartbeat')
        self.pool.add_task(self.pulse_job_manager.send_diagnosis_update,
                           config.RESTART_UPDATER_INTERVAL,
                           name='Diagnosis')
        self.pool.add_task(self.pulse_job_manager.every_quarter_checkups,
                           config.INTERCONNECTIVITY_UPDATER_INTERVAL, name='Storm')
        self.pool.add_task(self.pulse_job_manager.every_min_checkups,
                           config.EVERY_MIN_THREAD_INTERVAL,
                           name='Flash')
        self.pool.add_task(self.pulse_job_manager.first_quarter_checkups,
                           config.FIRST_QUARTER_TIMEOUT,
                           name='FirstQuarterChecks')
        self.pool.add_task(self.pulse_job_manager.check_couch_partial_compact,
                           config.PARTIAL_COUCH_COMPACTION_CHECK_INTERVAL, name='CouchCompaction')
        self.pool.add_task(self.pulse_job_manager.detect_anomalies,
                           config.ANOMALY_DETECTION_TIMEOUT,
                           name='AnomalyDetection')

        self.pool.wait_completion()

    def start(self):
        """
        This will start all threads
        :return:
        """
        self.initialize()
        self.start_all_interval_jobs()
