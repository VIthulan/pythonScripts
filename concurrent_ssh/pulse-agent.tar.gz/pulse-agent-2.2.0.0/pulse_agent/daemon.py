"""
Daemon module to initialize prerequisites
"""
import sys

from pulse_agent.utils import deps_installing_util  # Import this first to install dependencies
from pulse_agent.utils.logger import Logger

from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.services import cinco_identity


def init_prerequisites(debug):
    """
    initialize prerequisites
    :param debug: debug option
    :return:
    """
    try:
        Logger.initialize_logger(debug)

        # Install dependencies
        deps_installing_util.no_ops()

        # Initialize Logger

        # Init Pulse Client with device Id
        pulse_client.setup_identity(
            device_id=cinco_identity.get_device_identifier(),
            merchant_id=cinco_identity.get_merchant_id(),
            register_no=cinco_identity.get_register_no()
        )
    except Exception as exception:
        sys.stdout.write('Exception occurred in daemon')
        sys.stdout.write(exception)
