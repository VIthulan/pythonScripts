"""
Network protocol related module
"""
import logging
from scapy.all import sniff, socket


class ProtocolChecks(object):
    """
    Protocol related methods and attributes
    """

    def __init__(self):
        self.received_count = 0

    def begin_sniffing(self, interface='eth0', filter_pattern='udp port 18770', timeout=15, count=20):
        """
        begin_sniffing
        :param interface: Interface
        :param filter_pattern: Pattern
        :param timeout: timeout
        :param count: Count
        :return:
        """
        try:
            self.received_count = 0
            sniff(iface=interface, prn=self.pkt_callback, filter=filter_pattern, store=0, timeout=timeout, count=count)
            logging.info('total packets captured in sniffing: %s', self.received_count)
            return {
                'RECEIVED': self.received_count,
                'TOTAL': 10
            }
        except Exception as exception:
            logging.exception("Error while performing packet sniffing: %s", exception)

    def pkt_callback(self, pkt):
        """
        pkt_callback
        :param pkt: Packet
        :return:
        """
        try:
            if 'UDP' in pkt:
                pkt_len = pkt['UDP'].len
                logging.debug('packet length: %s', pkt_len)
            if 'IP' in pkt:
                pkt_src = pkt['IP'].src
                logging.debug('packet source: %s', pkt_src)
            if 'Raw' in pkt:
                pkt_load = pkt['Raw'].load
                logging.debug('packet load: %s', pkt_load)
                logging.debug('real packet length: %s', len(pkt_load))
                if pkt_load.startswith('PULSE_UDP_PACKET'):
                    logging.info('OK Captured PULSE_UDP_PACKET')
                    self.received_count += 1

        except Exception as exception:
            logging.exception("Error in packet sniffing callback method: %s", exception)

    def send_predefined_number_of_UDP_packets(self, ip_address, port, number_of_packets):
        """
        send_predefined_number_of_UDP_packets
        :param ip_address: IP
        :param port: Port
        :param number_of_packets: number of packets
        :return:
        """
        try:
            for _ in range(number_of_packets):
                self.send_udp_packet(ip_address, port)
        except Exception as exception:
            logging.exception("Error in sending predefined number of UDP packets: %s", exception)

    def send_udp_packet(self, ip_address, port):
        """
        send_udp_packet
        :param ip_address: IP
        :param port: Port
        :return:
        """
        try:
            MESSAGE_PREFIX = "PULSE_UDP_PACKET"
            MESSAGE_SUFFIX_LENGTH = 1000

            # Construct a message with a known prefix to variate the byte size.
            message = MESSAGE_PREFIX
            for _ in range(MESSAGE_SUFFIX_LENGTH):
                message += '1'

            logging.debug('[SEND_UDP_PACKET] UDP target IP: %s', ip_address)
            logging.debug('[SEND_UDP_PACKET] UDP target port: %s', port)
            logging.debug('[SEND_UDP_PACKET] message: %s', message)
            logging.debug('[SEND_UDP_PACKET] message length: %s', len(message))

            sock = socket.socket(socket.AF_INET,  # Internet
                                 socket.SOCK_DGRAM)  # UDP
            sock.sendto(message, (ip_address, port))

        except Exception as exception:
            logging.exception("Error in sending UDP packets: %s", exception)


protocol_checks = ProtocolChecks()
