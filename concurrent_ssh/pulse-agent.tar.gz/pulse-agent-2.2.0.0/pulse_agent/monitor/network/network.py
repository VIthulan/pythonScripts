"""
This module has details about all common network functions
This should not depend on any other network package modules since this is the low level module
"""
import os
import re
import logging
import pickle
import ast
import subprocess as subproc
from pulse_agent.utils import json_utils
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config


def get_network_data(code):
    """ returns an array of the machine's network interfaces. """

    # loop through each interface returned by ifconfig and look for any eth* interfaces.
    # These are physical interfaces
    # that should be parsed
    for interface in os.popen('ifconfig -a').read().split('\n\n'):
        if interface.startswith('eth') or interface.startswith('wlan'):
            try:
                if code == 'name':
                    return re.search('eth[0-9]', interface).group()
                elif code == 'ip':
                    return re.search('inet addr:(.+?) ', interface).group(1)
                elif code == 'mask':
                    return re.search('Mask:(.+?)\n', interface).group(1)
                elif code == 'mac':
                    return re.search('HWaddr (.+?) ', interface).group(1)
                elif code == 'rx':
                    return re.search('RX bytes:(.+?) \((.+?)\)', interface).group(2)
                elif code == 'tx':
                    return re.search('TX bytes:(.+?) \((.+?)\)', interface).group(2)

            except Exception as exception:
                logging.exception("Error getting network data for: %s - %s", interface.split()[0],
                                  exception)
                return ''


def get_network_interfaces():
    """ returns an array of the machine's network interfaces. """
    interfaces = []

    # loop through each interface returned by ifconfig and look for any eth* interfaces.
    # These are physical interfaces that should be parsed
    for interface in os.popen('ifconfig -a').read().split('\n\n'):
        if interface.startswith('eth') or interface.startswith('wlan'):
            try:
                interfaces.append(dict(
                    name=re.search('eth[0-9]', interface).group(),
                    ip=re.search('inet addr:(.+?) ', interface).group(1),
                    mask=re.search('Mask:(.+?)\n', interface).group(1),
                    mac=re.search('HWaddr (.+?) ', interface).group(1),
                    rx=re.search('RX bytes:(.+?) \((.+?)\)', interface).group(2),
                    tx=re.search('TX bytes:(.+?) \((.+?)\)', interface).group(2)
                ))
            except Exception as exception:
                logging.exception("Error appending network data for: %s - %s", interface.split()[0],
                                  exception)

    return interfaces


def get_hostname():
    """ returns the machine's hostname. """
    return os.popen('hostname').read().strip()


def get_default_gateway():
    """ returns the IP address of the machine's default gateway (router). """
    for line in os.popen('ip route').read().split('\n'):
        if line.startswith('default'):
            return re.search('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', line).group()

    return None


def get_public_ip():
    """ get public IP of POS using DNS commands"""
    try:
        command = "dig TXT +short o-o.myaddr.l.google.com @ns1.google.com"
        process = sub_process.p_open_default(command.split(), stdout=subproc.PIPE)
        public_ip, err = process.communicate()

        if err:
            logging.error('Error while getting public IP: %s', err)

        ip_regex_pattern = ('^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}'
                            '([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')
        public_ip = public_ip.split("\"")[1]

        if re.match(ip_regex_pattern, public_ip):
            return public_ip

        return ''
    except Exception as exception:
        logging.exception("Error while getting public IP: %s", exception)
        return ''


def get_connectivity_data_from_end_point():
    """ get data from pulse """
    try:
        response = pulse_client.dedicated_client.post(config.NETWORK_INTERCONNECTIVITY_END_POINT)
        if response.status_code == 200:
            result = str(response.text)
            logging.debug('retrieved json for inter-connectivity check: %s', result)
            with open(config.NETWORK_INTERCONNECTIVITY_IP_LIST_FILE, "wb") as output_file:
                pickle.dump(ast.literal_eval(result), output_file)
    except Exception as exception:
        logging.exception('Error while processing connectivity data: %s', exception)


def is_ethtool_installed():
    """
    is_ethtool_installed
    :return: true/false
    """
    try:
        command = "dpkg -s ethtool 2>&1 | grep 'ok installed'"
        ethtool = sub_process.p_open_stripped(command)
        if ethtool == '':
            return False
        return True
    except Exception as exception:
        logging.error("Error in checking whether ethtool is installed: %s", exception)
        return False


def get_max_isp_speed():
    """
    Get max ISP speed
    :return:
    """
    try:
        command = "speedtest-cli --share|grep -e \"Share\\|Testing from\""
        max_isp_speed = sub_process.p_open_stripped(command).split('\n')

        isp = max_isp_speed[0].split('Testing from ', 1)[1].split(' (', 1)[0]
        max_isp_speed_url = max_isp_speed[1].split(': ', 1)[1]

        return {
            'payload': {
                'MAX_ISP_NAME': isp,
                'MAX_ISP_VALUE': max_isp_speed_url
            }
        }

    except Exception as exception:
        logging.exception('Error while checking max ISP Speed: %s', exception)


def get_mtr_result(target):
    """
    Get mtr results
    :param target: remote host
    :return: results
    """
    try:
        logging.info("executing mtr full result for target: %s" % target)

        mtr_full_result = []
        mtr_full_result_command = (
            "mtr --no-dns --report --report-cycles 20 " + target +
            " |grep -A 20 'HOST'|awk '{if(NR>1)print}'|awk -F'--'  "
            "'{print $2}'|awk '{print $1,\";\",$2,\";\",$3,\";\",$4,"
            "\";\",$5,\";\",$6,\";\",$7,\";\",$8}'"
        )
        results = sub_process.p_open_stripped(mtr_full_result_command).splitlines()

        for element in results:
            result_tokens = element.split(';')

            mtr_full_result.append({
                'IP': result_tokens[0].strip(),
                'LOSS': result_tokens[1].strip(),
                'SNT': result_tokens[2].strip(),
                'LAST': result_tokens[3].strip(),
                'AVG': result_tokens[4].strip(),
                'BEST': result_tokens[5].strip(),
                'WRST': result_tokens[6].strip(),
                'STDEV': result_tokens[7].strip()
            })
        logging.debug('Full MTR results for %s: %s', target,
                      json_utils.get_json_dump(mtr_full_result))
        return mtr_full_result
    except Exception as exception:
        logging.exception("Error in getting mtr result: %s", exception)
        return config.ERROR_MESSAGE
