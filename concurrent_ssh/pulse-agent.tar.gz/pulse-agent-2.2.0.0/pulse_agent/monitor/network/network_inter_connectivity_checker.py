"""
Network inter connectivity checker that checks connected devices
"""
import logging
import pickle
import os
import re
import datetime
import time
from scapy.all import srp, Ether, ARP, conf  # pylint: disable=no-name-in-module

from pulse_agent.monitor.network import network
from pulse_agent.monitor.network.dtos import DEVICE
from pulse_agent.monitor.network.dtos import Report
from pulse_agent.monitor.network.dtos import STATE
from pulse_agent.services import cinco_identity
from pulse_agent.utils.moxy_client import moxy_client
from pulse_agent.utils import json_utils
from pulse_agent.utils.config import config
from pulse_agent.utils import sub_process
from pulse_agent.utils.pulse_client import pulse_client


class NetworkICChecker(object):
    """
    NetworkICChecker class, methods and attributes related to it.
    """

    def __init__(self):
        self.COUCH_IP_LIST = []
        self.DEVICES = []
        self.POS_IP = None
        self.SUBNET_MASK = 24
        self.CRADLE_POINT_IP = '10.10.10.1'
        self.REMOTE_HOST = 'google.com'
        self.unreachable_devices = {'count': 0}
        self.is_couch_sync_requested = False

    def check_inter_connectivity(self):
        """
        Main method: Check inter connectivity
        :return: Generated report
        """
        try:
            logging.info("Initiating inter-connectivity checks")
            if self.is_couch_sync_requested:
                network.get_connectivity_data_from_end_point()
                self.is_couch_sync_requested = False
                self.COUCH_IP_LIST = []
                self.DEVICES = []

            self.POS_IP = self.get_local_ip()
            report = Report()
            if not self.COUCH_IP_LIST:
                self.process_network_data_file()

            logging.debug('Devices connected according to couch: %s',
                          json_utils.get_pretty_json(self.DEVICES))
            logging.debug('Couch IP list: %s', json_utils.get_pretty_json(self.COUCH_IP_LIST))

            logging.debug("check whether interface is up ")
            if self.is_network_interface_up(config.ETH0_NETWORK_INTERFACE):
                report.NETWORK_INTERFACE_UP = STATE(status=True)
            else:
                report.NETWORK_INTERFACE_UP = STATE(status=False)
                logging.error('DEVICE NOT CONNECTED: eth0 not up')
                return

            logging.debug("check whether data link is connected")
            if network.is_ethtool_installed():
                if self.is_link_connected_to_interface(config.ETH0_NETWORK_INTERFACE):
                    report.CABLE_CONNECTED = STATE(status=True)
                else:
                    report.CABLE_CONNECTED = STATE(status=False)
                    logging.error('DEVICE NOT CONNECTED: link is not connected')
                    return
            else:
                report.CABLE_CONNECTED = STATE(status=False, results='NO_ETHTOOL')
                logging.error('ETHTOOL IS NOT INSTALLED')

            arp_result_array = self.get_arp_scan_result_ips()
            report.ARP = STATE(results=arp_result_array)

            logging.debug("check whether cradle point is detected")
            if self.is_cradlepoint_in_list(arp_result_array):
                report.CONNECTED_TO_CP = STATE(status=True)
            else:
                report.CONNECTED_TO_CP = STATE(status=False)

            logging.debug("checking whether network is active")
            if self.is_network_active():
                report.IS_NETWORK_ACTIVE = STATE(status=True)
            else:
                report.IS_NETWORK_ACTIVE = STATE(status=False)

            logging.debug("get traceroute result")
            report.TRACE_ROUTE = STATE(results=self.get_traceroute_results())

            logging.debug("get traceroute result array")
            traceroute_result_array = self.get_traceroute_result_ips()
            logging.debug("checking whether cradle point belongs to traceroute result")
            if self.is_cradlepoint_in_list(traceroute_result_array):
                report.CP_BELONGS_TO_TRACEROUTE = STATE(status=True)

            unreachable_devices_array = self.finalize_unreachable_devices()

            if unreachable_devices_array:
                # Sending popup message to pos front end
                self.send_pop_message_to_devices(unreachable_devices_array, threshold_secs=3 * 3600)

            logging.debug("checking for any unreachable devices")
            report.UNREACHABLE_DEVICE_IP_LIST = STATE(
                results=self.get_devices_which_really_problematic(unreachable_devices_array,
                                                                  self.DEVICES))

            logging.debug("checking any excess devices")
            # remove Cradlepoint IP from arp result
            if self.CRADLE_POINT_IP in arp_result_array:
                arp_result_array.remove(self.CRADLE_POINT_IP)

            # remove self IP from COUCH IP LIST
            if self.POS_IP in self.COUCH_IP_LIST:
                self.COUCH_IP_LIST.remove(self.POS_IP)

            report.UNKNOWN_DEVICES_IP_LIST = STATE(
                results=self.find_exess_devices(self.COUCH_IP_LIST, arp_result_array))

            logging.debug("getting packet losses per each device in arp list")
            results = self.get_packet_loss_for_devices(
                list(set(arp_result_array) - set(report.UNKNOWN_DEVICES_IP_LIST.RESULTS)))
            report.DEVICE_PACKET_LOSS = STATE(results=results)

            return report
        except Exception as exception:
            logging.error("Error in check_inter_connectivity method: %s", exception)
            return config.ERROR_MESSAGE

    def process_network_data_file(self):
        """
        Process network data pickle file and get connected devices from couch
        :return: Couch IP List
        """
        try:
            with open(config.NETWORK_INTERCONNECTIVITY_IP_LIST_FILE, "rb") as input_file:
                stored_interconnectivity_data = pickle.load(input_file)

            COUCH_IP_LIST = []
            for device in stored_interconnectivity_data:
                if device['DEVICE_NAME'] == 'CRADLE POINT':
                    CRADLE_POINT_IP = device['LOCAL_IP']  # TODO: Not used variable
                    continue
                if device['LOCAL_IP'] == self.POS_IP:
                    continue

                COUCH_IP_LIST.append(device['LOCAL_IP'])

                logging.debug(json_utils.get_pretty_json(device))

                self.DEVICES.append(
                    DEVICE(
                        ip=device['LOCAL_IP'],
                        name=device['DEVICE_NAME'],
                        device=device['DEVICE_TYPE'],
                        registers=device['CONNECTED_REGISTER']
                    )
                )

            self.COUCH_IP_LIST = list(set(COUCH_IP_LIST))
        except Exception as exception:
            logging.exception("Error in reading meta data from file: %s", exception)

    def get_local_ip(self):
        """
        Get local IP of the device
        :return: IP address
        """
        try:
            for interface in os.popen('ifconfig -a').read().split('\n\n'):
                if interface.startswith(config.ETH0_NETWORK_INTERFACE):
                    return re.search('inet addr:(.+?) ', interface).group(1)
        except Exception as exception:
            logging.exception('Error getting local ip: %s', exception)
            return config.ERROR_MESSAGE

    def is_network_interface_up(self, interface):
        """
        Checks whether network interface is up or not
        :param interface: Eth0
        :return: True/False
        """
        try:
            logging.info("checking network interface status")
            status_command = "cat /sys/class/net/" + interface + "/operstate"
            logging.debug(status_command)
            status = sub_process.p_open_stripped(status_command)
            logging.debug('is network interface up: %s', status)
            if status == 'up':
                return True
            return False
        except Exception as exception:
            logging.exception("Error in checking network interface status: %s", exception)
            return False

    def is_link_connected_to_interface(self, interface):
        """
        Checks whether link is connected to interface
        :param interface: Eth0
        :return: True/False
        """
        try:
            logging.debug("checking link connectivity")
            status_command = "ethtool " + interface + "|grep 'Link detected'|cut -d ' ' -f 3"
            logging.debug(status_command)
            status = sub_process.p_open_stripped(status_command)
            logging.debug('is_link_connected_to_interface: %s', status)
            if status == 'yes':
                return True
            return False
        except Exception as exception:
            logging.exception("Error in checking link connectivity: %s", exception)
            return False

    def get_arp_scan_result_ips(self):
        """
        Do a Arp scan and get the connected devices
        :return: Results Array
        """
        try:
            result_array = []
            logging.debug("arp scanning...")
            conf.verb = 0
            ans, unans = srp(
                Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(
                    pdst=str(self.POS_IP) + '/' + str(self.SUBNET_MASK)),
                timeout=2)
            for snd, rcv in ans:
                mac_ip = rcv.sprintf(r"%Ether.src%,%ARP.psrc%")
                ip = mac_ip.split(',')[1]
                result_array.append(ip)
            return result_array
        except Exception as exception:
            logging.exception("Error in arp scanning: %s", exception)
            return []

    def is_cradlepoint_in_list(self, given_list):
        """
        checks if an IP in given list is cradle point IP
        :param given_list: given list
        :return: True/False
        """
        try:
            for ip in given_list:
                if ip == self.CRADLE_POINT_IP:
                    return True
            return False
        except Exception as exception:
            logging.exception("Error in checking cp in arp list: %s", exception)
            return False

    def is_network_active(self):
        """
        Checks if network is active
        :return: True/False
        """
        try:
            response = os.system("ping -c 1 " + self.REMOTE_HOST)
            if response == 0:
                return True
            return False
        except Exception as exception:
            logging.exception("Error checking whether network is active: %s", exception)
            return False

    def get_traceroute_results(self, host='google.com'):
        """
        Get trace route results from remote host
        :return: results
        """
        try:
            traceroute_command = "traceroute  -m 10 " + host
            logging.debug(traceroute_command)
            traceroute_result = sub_process.p_open_stripped(traceroute_command)
            return traceroute_result
        except Exception as exception:
            logging.exception("Error in traceroute: %s", exception)
            return ''

    def get_traceroute_result_ips(self):
        """
        Get trace route result IPs
        :return: list
        """
        try:
            traceroute_command = ("traceroute  -m 10 " + self.REMOTE_HOST +
                                  "|tail -n +2|awk '{print $2}'")
            logging.info(traceroute_command)
            traceroute_result_array = sub_process.p_open_stripped(traceroute_command).splitlines()
            return traceroute_result_array
        except Exception as exception:
            logging.exception("Error in getting traceroute results: %s", exception)
            return []

    def process_arp_accumulation(self):
        """
        Process Arp scan accumulation
        """
        logging.debug('Performing arp scan accumulation')

        self.process_network_data_file()
        couch_list = self.COUCH_IP_LIST
        arp_results = self.get_arp_scan_result_ips()
        pos_ip = self.get_local_ip()
        is_suspect = False

        logging.debug('Responded devices for arp ping now: %s', arp_results)

        # remove Cradlepoint IP from arp result
        if self.CRADLE_POINT_IP in arp_results:
            arp_results.remove(self.CRADLE_POINT_IP)

        # remove self IP from COUCH IP LIST
        if pos_ip in couch_list:
            couch_list.remove(pos_ip)

        unreachable_devices_list = self.find_devices_not_connected(couch_list=couch_list,
                                                                   arp_list=arp_results)
        logging.debug('Not responded devices for arp ping now: %s', unreachable_devices_list)

        count = self.unreachable_devices.get('count') or 0
        count = count + 1

        unreachable_devices = {}
        for device in unreachable_devices_list:
            occurrences = self.unreachable_devices.get(device) or 0
            occurrences = occurrences + 1
            if occurrences >= 10 and count >= 10:
                is_suspect = True
            unreachable_devices[device] = occurrences

        unreachable_devices['count'] = count
        self.unreachable_devices = unreachable_devices

        logging.debug('Unreachable devices accumulation: %s',
                      json_utils.get_json_dump(self.unreachable_devices))

        if is_suspect and self.is_couch_sync_requested is False and self.is_couch_sync_required():
            logging.info('Unreachable device suspects found. Hence requesting API for Couch Sync')
            pulse_client.dedicated_client.post(config.ON_DEMAND_COUCH_SYNC)
            self.is_couch_sync_requested = True

    def is_couch_sync_required(self):
        """
        Checks whether couch sync in API side is required
        :return: True/False
        """
        register_no = cinco_identity.get_register_no()
        unreachable_device_list = []
        for ip in self.unreachable_devices:
            for device in self.DEVICES:
                if ip == device.IP:
                    if device.TYPE == 'PRINTER' and register_no == device.CONNECTED_REGISTER:
                        unreachable_device_list.append({
                            'DEVICE': device.NAME,
                            'TYPE': 'Printer'
                        })
                    elif device.TYPE == 'DESKTOP' and cinco_identity.is_master():
                        unreachable_device_list.append({
                            'DEVICE': device.NAME,
                            'TYPE': 'Desktop'
                        })

        if not unreachable_device_list:
            logging.debug(
                'Unreachable device is not connected to this register, '
                'thus no need of couch sync for this register: %s', unreachable_device_list)
            return False

        # If user notified within a given time interval avoid sending message to that device
        for msg_element in unreachable_device_list:
            if not self.is_user_notified(msg_element["DEVICE"], 3 * 3600):
                logging.debug(
                    '%s disconnection is not notified to user, thus couch sync is required',
                    msg_element["DEVICE"])
                return True

        logging.debug(
            'Unreachable devices are notified to user within 3 hours, thus no need of couch sync')
        return False

    def finalize_unreachable_devices(self):
        """
        Finalize unreachable devices
        :return: Finalized unreachable devices
        """
        try:
            logging.info('Accumulated results of Unreachable devices: %s',
                         json_utils.get_json_dump(self.unreachable_devices))
            del self.unreachable_devices['count']

            cont_unreachable_devices = []
            for device, occurrences in self.unreachable_devices.iteritems():
                if occurrences >= 10 and device in self.COUCH_IP_LIST:
                    cont_unreachable_devices.append(device)
            logging.debug('Finalized unreachable devices: %s', cont_unreachable_devices)
            return cont_unreachable_devices
        except Exception as exception:
            logging.exception('Exception while finalizing unreachable devices: %s', exception)
            return []

    def find_devices_not_connected(self, couch_list, arp_list):
        """
        Find devices that are not connected
        :param couch_list: Couch LIST
        :param arp_list: IPS from ARP scan
        :return:
        """
        try:
            return self.list_comparison(couch_list, arp_list)
        except Exception as exception:
            logging.exception("Error in comparing couch list and arp list: %s", exception)

    def list_comparison(self, a, b):
        """
        To  take elements which are in list A but not in list B
        """
        try:
            b = set(b)
            return [aa for aa in a if aa not in b]
        except Exception as exception:
            logging.exception("Error in list comparison: %s", exception)

    def send_pop_message_to_devices(self, unreachable_device_array, threshold_secs=3 * 3600):
        """
        Send pop message to merchant
        :param unreachable_device_array: Unreachable devices
        :param threshold_secs: Message threshold
        """
        try:
            unreachable_device_list = []
            unreachable_device_list_considering_user_response = []
            register_no = cinco_identity.get_register_no()

            # Create a list of unreachable device names
            for ip in unreachable_device_array:
                for device in self.DEVICES:
                    if ip == device.IP:
                        if device.TYPE == 'PRINTER' and register_no == device.CONNECTED_REGISTER:
                            unreachable_device_list.append({
                                'DEVICE': device.NAME,
                                'TYPE': 'Printer',
                                'HEADER': 'We cannot detect your ' + device.NAME + ' printer.',
                                'BODY': 'Did you turn off the device?'
                            })
                        elif device.TYPE == 'DESKTOP' and cinco_identity.is_master():
                            unreachable_device_list.append({
                                'DEVICE': device.NAME,
                                'TYPE': 'Desktop',
                                'HEADER': 'We cannot detect your ' + device.NAME + '.',
                                'BODY': 'Did you turn off the device?'
                            })

            # If user notified within a given time interval avoid sending message to that device
            for msg_element in unreachable_device_list:
                if not self.is_user_notified(msg_element["DEVICE"], threshold_secs):
                    unreachable_device_list_considering_user_response.append(msg_element)
            logging.debug('Notifying operator for unreachable device: %s',
                          unreachable_device_list_considering_user_response)
            # Call the moxy endpoint to generate popup message
            response = moxy_client.post(
                path=config.MOXY_NETWORK_ENDPOINT,
                body=unreachable_device_list_considering_user_response)
            logging.warning(
                "[Interconnectivity-Checker] popup message gave result %s" % str(response.text))
        except Exception as exception:
            logging.exception("Error in sending pop message to devices: %s", exception)

    def is_user_notified(self, device_name, time_gap_secs):
        """
        Checks if user is notified between 1 day gap about unreachable device
        :param device_name: device name
        :param time_gap_secs: time_gap
        :return:
        """
        try:
            grep_time_upper = datetime.date.today() - datetime.timedelta(1)
            grep_time_upper = grep_time_upper.strftime("%Y-%m-%d")
            grep_time_lower = datetime.date.today()
            grep_time_lower = grep_time_lower.strftime("%Y-%m-%d")

            logging.debug("[Interconnectivity-Checker] grep upper bound time: %s", grep_time_upper)
            logging.debug("[Interconnectivity-Checker] grep lower bound time: %s", grep_time_lower)

            # Get all occurrences within 1 Day period match with device name(Note:bothe Receipt1 and
            #  Receipt comes as matches for Receipt)
            command = ("grep -e '" + grep_time_upper + "' -e '" + grep_time_lower + "' "
                       + config.NETWORK_LOG + "| grep " + device_name + "|cut -d ' ' -f 1,2,5")

            status_array = sub_process.p_open_stripped(command).splitlines()

            user_notified_array = []
            for device in status_array:
                user_notified_array.append({
                    'NAME': device.split(' ')[2].split(':')[1],
                    'FEEDBACK': device.split(' ')[2].split(':')[2],
                    'TIME': device.split(' ')[0] + ' ' + device.split(' ')[1].split(',')[0]
                })

            logging.warning("[Interconnectivity-Checker] user notified array %s",
                            user_notified_array)

            # By the below check we get exact matches by device name
            if user_notified_array:
                # Traverse in reverse order to get latest occurrence in the HEAD
                for element in reversed(user_notified_array):
                    if element.get('NAME') == device_name:
                        if int(element.get('FEEDBACK')) == 1:
                            current_time = int(time.time())
                            last_notified_time = int(
                                time.mktime(
                                    datetime.datetime.strptime(element.get('TIME'),
                                                               "%Y-%m-%d  %H:%M:%S").timetuple()))
                            return (current_time - last_notified_time) < time_gap_secs
                        return False
            return False
        except Exception as exception:
            logging.exception('Error checking in user notified method: %s', exception)
            return False

    def get_devices_which_really_problematic(self, unreachable_device_array, devices_array):
        """
        Get devices that are problematic
        :param unreachable_device_array: un-reachable devices
        :param devices_array: devices array
        :return: array
        """
        try:
            unreachable_device_names = []
            resultant_unreachable_devices = []
            register_no = cinco_identity.get_register_no()

            # Create a list of unreachable device names
            for ip in unreachable_device_array:
                for device in devices_array:
                    if ip == device.IP and register_no == device.CONNECTED_REGISTER:
                        unreachable_device_names.append(device.NAME)

            # Remove devices which received user response as switched off
            for name in unreachable_device_names:

                user_response = self.get_latest_user_response(name)

                if user_response == 'off':
                    unreachable_device_status = 'FORCEFULLY TURNED OFF'
                elif user_response == 'on':
                    unreachable_device_status = 'ERROR'
                else:
                    unreachable_device_status = 'PENDING'

                resultant_unreachable_devices.append({
                    'NAME': name,
                    'STATUS': unreachable_device_status
                })

            # Again interpret the name array as ip array
            for element in resultant_unreachable_devices:
                for device in devices_array:
                    if element.get('NAME') == device.NAME:
                        element['IP'] = device.IP

            logging.warning("[Interconnectivity-Checker] Unreachable ip list %s",
                            resultant_unreachable_devices)
            return resultant_unreachable_devices
        except Exception as exception:
            logging.exception("Error in finding really problematic devices: %s", exception)

    def get_latest_user_response(self, device_name):
        """
        Get latest user response from pulse network log
        :param device_name: device name
        :return: On/Off
        """
        try:
            logging.debug("getting latest user response for device %s", device_name)
            grep_time_upper = datetime.datetime.now() - datetime.timedelta(minutes=60)
            grep_time_upper = grep_time_upper.strftime("%Y-%m-%d %H")
            grep_time_lower = datetime.datetime.now()
            grep_time_lower = grep_time_lower.strftime("%Y-%m-%d %H")
            logging.debug("[Interconnectivity-Checker] grep upper bound time: %s", grep_time_upper)
            logging.debug("[Interconnectivity-Checker] grep lower bound time: %s", grep_time_lower)

            # Get all occurances within 1 Day period match with device name(Note:bothe Receipt1
            # and Receipt comes as matches for Receipt)
            command = ("grep -e '" + grep_time_upper + "' -e '" + grep_time_lower + "' "
                       + config.NETWORK_LOG + "| grep " + device_name
                       + "|cut -d ' ' -f 5|cut -d ':' -f 2,3")
            logging.debug(command)
            status_array = sub_process.p_open_stripped(command).splitlines()

            user_response_array = []
            for device in status_array:
                user_response_array.append({
                    'NAME': device.split(':')[0],
                    'STATUS': device.split(':')[1]
                })

            # Reverse the array in order to get latest occurrence in the HEAD
            user_response_array.reverse()

            logging.debug("[Interconnectivity-Checker] user response array %s", user_response_array)

            # By the following check we get the exact matches with target device name
            if user_response_array:
                for element in user_response_array:
                    if element.get('NAME') == device_name:
                        if element.get('STATUS') == '1':
                            return 'off'
                        return 'on'
            return 'pending'
        except Exception as exception:
            logging.error("[Interconnectivity-Checker] Error in checking last user response: %s",
                          exception)
            return 'pending'

    def find_exess_devices(self, couch_list, arp_list):
        """
        Find exess devices
        :param couch_list: couch list
        :param arp_list: arp list
        :return: exess devices
        """
        try:
            return self.list_comparison(arp_list, couch_list)
        except Exception as exception:
            logging.exception("Error in comparing arp list and couch list: %s", exception)

    def get_packet_loss_for_devices(self, ip_array):
        """
        Get packet loss for devices
        :param ip_array: IP Array
        :return: result
        """
        try:
            result = []
            for ip in ip_array:
                mtr_result_array = network.get_mtr_result(ip)
                for hop in mtr_result_array:
                    if hop.get('IP') == ip:
                        result.append({
                            str(ip): {
                                'loss': str(hop.get('LOSS')),
                                'snt': str(hop.get('SNT')),
                                'last': str(hop.get('LAST')),
                                'avg': str(hop.get('AVG')),
                                'best': str(hop.get('BEST')),
                                'wrst': str(hop.get('WRST')),
                                'stdev': str(hop.get('STDEV'))
                            }
                        })
            return result
        except Exception as exception:
            logging.exception("Error getting packet loss for devices: %s", exception)
            return []


network_ic_checker = NetworkICChecker()
