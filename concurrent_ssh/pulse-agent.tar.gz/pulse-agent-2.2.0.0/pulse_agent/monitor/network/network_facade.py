"""
Network Facade
"""
import logging

from pulse_agent.monitor.network import network
from pulse_agent.monitor.network import advanced_network_checkup
from pulse_agent.monitor.network.network_inter_connectivity_checker import network_ic_checker
from pulse_agent.monitor.network.network_protocol_checks import protocol_checks
from pulse_agent.utils import json_utils
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils.config import config


class NetworkFacade(object):
    """
    Network facade class, attributes and methods related to it
    """

    def __init__(self):
        pass

    def process_connectivity_checks(self):
        """ start network interconnectivity checking"""
        try:
            network.get_connectivity_data_from_end_point()
            self.do_advanced_check()
        except Exception as exception:
            logging.exception('Error while starting inter-connectivity checking: %s', exception)

    def process_inter_connection_check(self):
        """
        Process inter-connectivity check and respond to pulse API
        """
        report = network_ic_checker.check_inter_connectivity()

        logging.info('Sending Network inter-connectivity report: %s',
                     json_utils.get_pretty_json(report))

        pulse_client.post(config.NETWORK_INTERCONNECTIVITY_RESULT_END_POINT, body={
            'REPORT': report
        })

    def do_advanced_check(self, env=None):
        """
        Do advanced network check
        :param env: Environment
        :return: rest call
        """
        advanced_network_checkup.do_advanced_check(env)

    def send_tracerout_results(self, env=None, host=None):
        """
        send_tracerout_results
        :param env: Environment
        :param host: Host to do tracerout
        :return: rest call
        """

        trace_route_result = network_ic_checker.get_traceroute_results(host=host)

        logging.info('Sending trace route results: %s', trace_route_result)

        pulse_client.get_client(env).post(
            config.NETWORK_INTERCONNECTIVITY_TRACE_ROUTE_END_POINT,
            body={
                'REPORT': trace_route_result
            }
        )

    def perform_sniffing(self, env=None):
        """
        Perform sniffing
        :param env: Environment
        :return: rest call
        """
        pulse_client.get_client(env).post(
            config.NETWORK_INTERCONNECTIVITY_UDP_LOSS_FINDER_RESULT_END_POINT,
            body={
                'REPORT': protocol_checks.begin_sniffing()
            }
        )

    def send_udp_packets(self, ip_address, port=18770, number_of_packets=10):
        """
        Send UDP packets
        :param ip_address: IP
        :param port: Port
        :param number_of_packets: No of packets
        :return: Rest call
        """
        protocol_checks.send_predefined_number_of_UDP_packets(ip_address, port, number_of_packets)
        logging.info('Sending UDP packets on demand test is completed')

    def send_max_isp_speed(self):
        """
        Send max ISP speed
        :return: Rest call
        """
        response = network.get_max_isp_speed()
        response_body = json_utils.get_json_dump(response)
        logging.info('Sending max isp speed: %s', response_body)
        pulse_client.post(config.ISP_SPEED_URL_END_POINT, body=response)

    def perform_arp_scan_accumulation(self):
        try:
            network_ic_checker.process_arp_accumulation()
        except Exception as exception:
            logging.exception('Exception while performing arp scan: %s', exception)


network_facade = NetworkFacade()
