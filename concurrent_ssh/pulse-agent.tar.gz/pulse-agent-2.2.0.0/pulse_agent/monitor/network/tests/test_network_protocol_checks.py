"""
tests for protocol_checks module
"""
# core modules
import logging
import subprocess
import mock
from mock import Mock

# testing module
from pulse_agent.monitor.network.network_protocol_checks import protocol_checks

# dto
from pulse_agent.monitor.network.tests.dtos import PACKET

logging.basicConfig(level=logging.INFO)


@mock.patch('scapy.all.socket.socket')
def test_send_udp_packet(mock_socket):
    """
    test send_udp_packet()
    :param mock_socket: mock call to scapy.all.socket.socket()
    """
    # checks whether it works as expected
    mock_send = Mock(return_value=None)
    mock_response = Mock(sendto=mock_send)
    mock_socket.return_value = mock_response

    message = "PULSE_UDP_PACKET"
    for _ in range(1000):
        message += '1'

    ip = '10.10.10.1'
    port = '18770'
    assert protocol_checks.send_udp_packet(ip, port) is None
    assert mock_send.mock_calls == [mock.call(message, (ip, port))]

    # checks whether it handles exceptions properly
    mock_socket.side_effect = Exception
    assert protocol_checks.send_udp_packet(ip, port) is None


@mock.patch('pulse_agent.monitor.network.network_protocol_checks.protocol_checks.send_udp_packet')
def test_send_predefined_number_of_UDP_packets(mock_send_udp_packet):
    """
    test send_predefined_number_of_UDP_packets()
    :param mock_send_udp_packet: 
    mock call to pulse_agent.monitor.network.network.network_protocol_checks.protocol_checks.send_udp_packet()
    """
    # checks whether it works as expected if 
    mock_send_udp_packet.return_value = None
    ip = '10.10.10.1'
    port = '18770'
    number_of_packets = 2
    assert protocol_checks.send_predefined_number_of_UDP_packets(ip, port, number_of_packets) is None
    assert mock_send_udp_packet.mock_calls == [mock.call(ip, port), mock.call(ip, port)]

    # checks whether it handles exceptions properly
    mock_send_udp_packet.side_effect = Exception
    assert protocol_checks.send_predefined_number_of_UDP_packets(ip, port, number_of_packets) is None


def test_pkt_callback(monkeypatch):
    """
    test pkt_callback()
    :param monkeypatch: mock test class variables
    """
    # checks whether it works as expected
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_protocol_checks.protocol_checks.received_count',
        0
    )
    packet = {
        'UDP': PACKET(len=''),
        'IP': PACKET(src=''),
        'Raw': PACKET(load='PULSE_UDP_PACKET_SENT')
    }
    protocol_checks.pkt_callback(packet)
    assert protocol_checks.received_count == 1

    # checks whether it handles exceptions properly
    assert protocol_checks.pkt_callback(None) is None