class PACKET(object):
    def __init__(self, len=None, src=None, load=None):
        self.len = len
        self.src = src
        self.load = load
