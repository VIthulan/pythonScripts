"""
tests for network module
"""
# core modules
import logging
import subprocess
import mock
from mock import Mock

# testing module
from pulse_agent.monitor.network import network

# helper
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


@mock.patch('os.popen')
def test_get_network_data(mock_popen):
    """
    test get_network_data()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected if
    mock_popen.return_value = Mock(
        read=Mock(return_value='eth0 inet addr:xxxxx inet addr:yyyyy Mask:mask1\nMask:mask2\n'
                               'HWaddr hwadd1 HWaddr hwadd2 RX bytes: (1) RX bytes: (2) RX bytes: (3) '
                               'TX bytes: (1) TX bytes: (2) TX bytes:(3)\n\n'))

    assert network.get_network_data('name') == 'eth0'
    assert network.get_network_data('ip') == 'xxxxx'
    assert network.get_network_data('mask') == 'mask1'
    assert network.get_network_data('mac') == 'hwadd1'
    assert network.get_network_data('rx') == '2'
    assert network.get_network_data('tx') == '2'

    # checks whether it handles exceptions
    mock_popen.return_value = Mock(
        read=Mock(return_value='eth \n\n'))
    try:
        network.get_network_data('rx')
        assert False
    except Exception:
        assert True


@mock.patch('os.popen')
def test_get_network_interfaces(mock_popen):
    """
    test get_network_interfaces()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(
        read=Mock(return_value='eth0 inet addr:xxxxx inet addr:yyyyy Mask:mask1\nMask:mask2\n'
                               'HWaddr hwadd1 HWaddr hwadd2 RX bytes: (1) RX bytes: (2) RX bytes: (3) '
                               'TX bytes: (1) TX bytes: (2) TX bytes:(3)\n\n'
                               'wlan eth1 inet addr:xxxxx inet addr:yyyyy Mask:mask1\nMask:mask2\n'
                               'HWaddr hwadd1 HWaddr hwadd2 RX bytes: (1) RX bytes: (2) RX bytes: (3) '
                               'TX bytes: (1) TX bytes: (2) TX bytes:(3)\n\n'
                  ))
    assert network.get_network_interfaces() == [
        {
            'name': 'eth0',
            'ip': 'xxxxx',
            'mask': 'mask1',
            'mac': 'hwadd1',
            'rx': '2',
            'tx': '2'
        },
        {
            'name': 'eth1',
            'ip': 'xxxxx',
            'mask': 'mask1',
            'mac': 'hwadd1',
            'rx': '2',
            'tx': '2'
        }
    ]

    # checks whether it handles exceptions properly
    mock_popen.return_value = Mock(read=Mock(return_value='eth \n\n'))
    assert network.get_network_interfaces() == []


@mock.patch('os.popen')
def test_get_hostname(mock_popen):
    """
    test get_hostname()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(read=Mock(return_value='localhost'))
    assert network.get_hostname() == 'localhost'


@mock.patch('os.popen')
def test_get_default_gateway(mock_popen):
    """
    test get_default_gateway()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(read=Mock(return_value='default 10.10.10.10'))
    assert network.get_default_gateway() == '10.10.10.10'

    mock_popen.return_value = Mock(read=Mock(return_value='10.10.10.10'))
    assert network.get_default_gateway() is None


@mock.patch('pulse_agent.utils.sub_process.p_open_default')
def test_get_public_ip(mock_p_open_default):
    """
    test get_public_ip()
    :param mock_p_open_default: mock call to pulse_agent.utils.sub_process.p_open_default()
    """
    # checks whether it works as expected if error occurs
    mock_p_open_default.return_value = Mock(communicate=Mock(return_value=('ip\"120.120.120.120', 'some error')))
    assert network.get_public_ip() == '120.120.120.120'

    # checks whether it works as expected if no error occurs
    mock_p_open_default.return_value = Mock(communicate=Mock(return_value=('no ip', None)))
    assert network.get_public_ip() == ''

    # checks whether it handles exceptions properly
    mock_p_open_default.side_effect = Exception
    assert network.get_public_ip() == ''


@mock.patch('pulse_agent.utils.pulse_client.pulse_client.dedicated_client.post')
@mock.patch('__builtin__.open')
@mock.patch('pickle.dump')
def test_get_connectivity_data_from_end_point(mock_dump, mock_open, mock_post):
    """
    test get_connectivity_data_from_end_point()
    :param mock_dump: mock call to pickle.dump()
    :param mock_open: mock call to open()
    :param mock_post: mock call to pulse_client.dedicated_client.post()
    """
    # checks whether it works as expected
    mock_post.return_value = ''
    mock_open.return_value = ''
    mock_dump.return_value = ''

    network.get_connectivity_data_from_end_point()
    assert True

    # checks whether it handles exceptions
    mock_post.side_effect = Exception
    try:
        network.get_connectivity_data_from_end_point()
        assert False
    except Exception:
        assert True


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_is_ethtool_installed(mock_p_open_stripped):
    """
    test is_ethtool_installed()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if ethtool isn't installed
    mock_p_open_stripped.return_value = ''
    assert not network.is_ethtool_installed()

    # checks whether it works as expected if
    mock_p_open_stripped.return_value = 'installed'
    assert network.is_ethtool_installed()

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert not network.is_ethtool_installed()


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_max_isp_speed(mock_p_open_stripped):
    """
    test get_max_isp_speed()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if
    mock_p_open_stripped.return_value = 'Testing from AT&T ()\nspeed: C+'
    assert network.get_max_isp_speed() == {
        'payload': {
            'MAX_ISP_NAME': 'AT&T',
            'MAX_ISP_VALUE': 'C+'
        }
    }

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    try:
        network.get_max_isp_speed()
        assert False
    except Exception:
        assert True


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_mtr_result(mock_p_open_stripped):
    """
    test get_mtr_result()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if
    mock_p_open_stripped.return_value = 'ip-1;loss-1;snt-1;last-1;avg-1;best-1;wrst-1;stdev-1\n' \
                                        'ip-2;loss-2;snt-2;last-2;avg-2;best-2;wrst-2;stdev-2'
    assert network.get_mtr_result('google.com') == [
        {
            'IP': 'ip-1',
            'LOSS': 'loss-1',
            'SNT': 'snt-1',
            'LAST': 'last-1',
            'AVG': 'avg-1',
            'BEST': 'best-1',
            'WRST': 'wrst-1',
            'STDEV': 'stdev-1'
        },
        {
            'IP': 'ip-2',
            'LOSS': 'loss-2',
            'SNT': 'snt-2',
            'LAST': 'last-2',
            'AVG': 'avg-2',
            'BEST': 'best-2',
            'WRST': 'wrst-2',
            'STDEV': 'stdev-2'
        }
    ]

    # # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert network.get_mtr_result('google.com') == config.ERROR_MESSAGE
