"""
tests for network_ic_checker module
"""
# core modules
import logging
import datetime
import mock
from mock import Mock

# testing module
from pulse_agent.monitor.network.network_inter_connectivity_checker import network_ic_checker

# dto
from pulse_agent.monitor.network.dtos import DEVICE

# helpers
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


@mock.patch('pulse_agent.monitor.network.network.get_connectivity_data_from_end_point')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_local_ip')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.process_network_data_file')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.is_network_interface_up')
@mock.patch('pulse_agent.monitor.network.network.is_ethtool_installed')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.is_link_connected_to_interface')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_arp_scan_result_ips')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.is_cradlepoint_in_list')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.is_network_active')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_traceroute_results')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_traceroute_result_ips')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.finalize_unreachable_devices')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.send_pop_message_to_devices')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_devices_which_really_problematic')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.find_exess_devices')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_packet_loss_for_devices')
def test_check_inter_connectivity(mock_get_packet_loss_for_devices, mock_find_exess_devices,
                                  mock_get_devices_which_really_problematic, mock_send_pop_message_to_devices,
                                  mock_finalize_unreachable_devices,
                                  mock_get_traceroute_result_ips, mock_get_traceroute_results, mock_is_network_active,
                                  mock_is_cradlepoint_in_list,
                                  mock_get_arp_scan_result_ips, mock_is_link_connected_to_interface,
                                  mock_is_ethtool_installed, mock_is_network_interface_up,
                                  mock_process_network_data_file,
                                  mock_get_local_ip,
                                  mock_get_connectivity_data_from_end_point, monkeypatch):
    """
    test check_inter_connectivity()
    :param mock_get_packet_loss_for_devices: mock call to network_ic_checker.get_packet_loss_for_devices()
    :param mock_find_exess_devices: mock call to network_ic_checker.find_exess_devices()
    :param mock_get_devices_which_really_problematic: mock call to network_ic_checker.get_devices_which_really_problematic()
    :param mock_send_pop_message_to_devices: mock call to network_ic_checker.send_pop_message_to_devices()
    :param mock_finalize_unreachable_devices: mock call to network_ic_checker.finalize_unreachable_devices()
    :param mock_get_traceroute_result_ips: mock call to network_ic_checker.get_traceroute_result_ips()
    :param mock_get_traceroute_results: mock call to network_ic_checker.get_traceroute_results()
    :param mock_is_network_active: mock call to network_ic_checker.is_network_active()
    :param mock_is_cradlepoint_in_list: mock call to network_ic_checker.is_cradlepoint_in_list()
    :param mock_get_arp_scan_result_ips: mock call to network_ic_checker.get_arp_scan_result_ips()
    :param mock_is_link_connected_to_interface: mock call to network_ic_checker.is_link_connected_to_interface()
    :param mock_is_ethtool_installed: mock call to network.is_ethtool_installed()
    :param mock_is_network_interface_up: mock call to network_ic_checker.is_network_interface_up()
    :param mock_process_network_data_file: mock call to network_ic_checker.process_network_data_file()
    :param mock_get_local_ip: mock call to network_ic_checker.get_local_ip()
    :param mock_get_connectivity_data_from_end_point: mock call to network.get_connectivity_data_from_end_point()
    :param monkeypatch: use to patch class variables
    """
    # checks whether it works as expected
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.is_couch_sync_requested',
        True
    )

    mock_get_connectivity_data_from_end_point.return_value = None
    mock_get_local_ip.return_value = '10:10:10:10'
    mock_process_network_data_file.return_value = None
    mock_is_network_interface_up.return_value = True
    mock_is_ethtool_installed.return_value = True
    mock_is_link_connected_to_interface.return_value = True
    mock_get_arp_scan_result_ips.return_value = ['10:10:10:10', '10:10:10:20']
    mock_is_cradlepoint_in_list.side_effect = [True, True]
    mock_is_network_active.return_value = True
    mock_get_traceroute_results.return_value = 'traceroute results'
    mock_get_traceroute_result_ips.return_value = ['10:10:10:10', '10:10:10:20']
    mock_finalize_unreachable_devices.return_value = ['10:10:10:20']
    mock_send_pop_message_to_devices.return_value = None
    mock_get_devices_which_really_problematic.return_value = ['10:10:10:20']
    mock_find_exess_devices.return_value = ['10:10:10:20']
    mock_get_packet_loss_for_devices.return_value = 'packet losses'

    report = network_ic_checker.check_inter_connectivity()

    assert report.NETWORK_INTERFACE_UP.STATUS
    assert report.CABLE_CONNECTED.STATUS
    assert report.ARP.RESULTS == ['10:10:10:10', '10:10:10:20']
    assert report.CONNECTED_TO_CP.STATUS
    assert report.IS_NETWORK_ACTIVE.STATUS
    assert report.CABLE_CONNECTED.STATUS
    assert report.TRACE_ROUTE.RESULTS == 'traceroute results'
    assert report.CP_BELONGS_TO_TRACEROUTE.STATUS
    assert report.UNREACHABLE_DEVICE_IP_LIST.RESULTS == ['10:10:10:20']
    assert report.UNKNOWN_DEVICES_IP_LIST.RESULTS == ['10:10:10:20']
    assert report.DEVICE_PACKET_LOSS.RESULTS == 'packet losses'

    # checks whether it handles exceptions properly
    mock_get_connectivity_data_from_end_point.side_effect = Exception
    mock_get_local_ip.return_value = ''
    assert network_ic_checker.check_inter_connectivity() == config.ERROR_MESSAGE


@mock.patch('os.popen')
def test_get_local_ip(mock_popen):
    """
    test get_local_ip()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected if the eth0 is up
    popen_read = Mock(return_value='eth0 inet addr:0 inet addr:1\n\neth3 inet addr:3')
    mock_popen.return_value = Mock(read=popen_read)
    assert network_ic_checker.get_local_ip() == '0'

    # checks whether it handles exceptions properly
    mock_popen.side_effect = Exception
    assert network_ic_checker.get_local_ip() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_is_network_interface_up(mock_p_open_stripped):
    """
    test is_network_interface_up()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if the interface is up
    interface = 'eth0'
    mock_p_open_stripped.return_value = 'up'
    assert network_ic_checker.is_network_interface_up(interface)
    assert mock_p_open_stripped.mock_calls == [mock.call('cat /sys/class/net/eth0/operstate')]

    # checks whether it works as expected if the interface is down
    mock_p_open_stripped.return_value = 'down'
    assert not network_ic_checker.is_network_interface_up(interface)

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert not network_ic_checker.is_network_interface_up(interface)


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_is_link_connected_to_interface(mock_p_open_stripped):
    """
    test is_link_connected_to_interface()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if link is connected
    interface = 'eth0'
    mock_p_open_stripped.return_value = 'yes'
    assert network_ic_checker.is_link_connected_to_interface(interface)
    assert mock_p_open_stripped.mock_calls == [mock.call("ethtool eth0|grep 'Link detected'|cut -d ' ' -f 3")]

    # checks whether it works as expected if link is disconnected
    mock_p_open_stripped.return_value = 'no'
    assert not network_ic_checker.is_link_connected_to_interface(interface)

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert not network_ic_checker.is_link_connected_to_interface(interface)


def test_is_cradlepoint_in_list():
    """
    test is_cradlepoint_in_list()
    """
    # checks whether it works as expected if the CP IP is listed
    assert network_ic_checker.is_cradlepoint_in_list(['10.10.10.2', '10.10.10.1'])

    # checks whether it works as expected if the CP IP isn't listed
    assert not network_ic_checker.is_cradlepoint_in_list([])

    # checks whether it handles exceptions properly
    assert not network_ic_checker.is_cradlepoint_in_list(1)


@mock.patch('os.system')
def test_is_network_active(mock_system):
    """
    test is_network_active()
    :param mock_system: mock call to .os.system()
    """
    # checks whether it works as expected if network is active
    mock_system.return_value = 0
    assert network_ic_checker.is_network_active()
    assert mock_system.mock_calls == [mock.call("ping -c 1 google.com")]

    # checks whether it works as expected if network isn't active
    mock_system.return_value = -1
    assert not network_ic_checker.is_network_active()

    # # checks whether it handles exceptions properly
    mock_system.side_effect = Exception
    assert not network_ic_checker.is_network_active()


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_traceroute_results(mock_p_open_stripped):
    """
    test get_traceroute_results()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected with no provided host
    mock_p_open_stripped.return_value = 'traceroute results to google'
    assert network_ic_checker.get_traceroute_results() == 'traceroute results to google'
    assert mock_p_open_stripped.mock_calls == [mock.call("traceroute  -m 10 google.com")]

    # checks whether it works as expected with provided host
    mock_p_open_stripped.reset_mock()
    mock_p_open_stripped.return_value = 'traceroute results to facebook'
    assert network_ic_checker.get_traceroute_results(host="facebook.com") == 'traceroute results to facebook'
    assert mock_p_open_stripped.mock_calls == [mock.call("traceroute  -m 10 facebook.com")]

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert network_ic_checker.get_traceroute_results() == ''


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_traceroute_result_ips(mock_p_open_stripped):
    """
    test get_traceroute_result_ips()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if
    mock_p_open_stripped.return_value = '10.10.10.10\n10.10.10.20'
    assert network_ic_checker.get_traceroute_result_ips() == ['10.10.10.10', '10.10.10.20']
    assert mock_p_open_stripped.mock_calls == [mock.call("traceroute  -m 10 google.com|tail -n +2|awk '{print $2}'")]

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert network_ic_checker.get_traceroute_result_ips() == []


@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.process_network_data_file')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_arp_scan_result_ips')
@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_local_ip')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.find_devices_not_connected')
@mock.patch('pulse_agent.utils.pulse_client.pulse_client.dedicated_client.post')
def test_process_arp_accumulation(mock_post, mock_find_devices_not_connected, mock_get_local_ip,
                                  mock_get_arp_scan_result_ips, mock_process_network_data_file, monkeypatch):
    """
    test process_arp_accumulation()
    :param mock_post: mock call to pulse_client.dedicated_client.post()
    :param mock_find_devices_not_connected: mock call to network_ic_checker.find_devices_not_connected()
    :param mock_get_local_ip: mock call to network_ic_checker.get_local_ip()
    :param mock_get_arp_scan_result_ips: mock call to network_ic_checker.get_arp_scan_result_ips()
    :param mock_process_network_data_file: mock call to network_ic_checker.process_network_data_file()
    :param monkeypatch: use to patch class variables
    """
    # checks whether it works as expected
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.COUCH_IP_LIST',
        ['10.10.10.10', '10.10.10.20', '10.10.10.30']
    )
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.unreachable_devices',
        {
            '10.10.10.30': 10
        }
    )

    mock_post.return_value = None
    mock_find_devices_not_connected.return_value = ['10.10.10.30']
    mock_get_local_ip.return_value = '10.10.10.10'
    mock_process_network_data_file.return_value = None
    mock_get_arp_scan_result_ips.return_value = ['10.10.10.20', '10.10.10.1']
    network_ic_checker.process_arp_accumulation()
    assert network_ic_checker.unreachable_devices == {
        'count': 1,
        '10.10.10.30': 11
    }
    assert mock_find_devices_not_connected.mock_calls == [
        mock.call(couch_list=['10.10.10.20', '10.10.10.30'], arp_list=['10.10.10.20'])
    ]
    assert mock_post.mock_calls == []


@mock.patch('pulse_agent.utils.json_utils.get_json_dump')
def test_finalize_unreachable_devices(mock_get_json_dump, monkeypatch):
    """
    test finalize_unreachable_devices()
    :param mock_get_json_dump: mock call to pulse_agent.utils.json_utils.get_json_dump()
    :param monkeypatch: use to patch class variables
    """
    # checks whether it works as expected if
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.COUCH_IP_LIST',
        ['10.10.10.10', '10.10.10.20'])
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.unreachable_devices',
        {
            'count': 0,
            '10.10.10.10': 9,
            '10.10.10.20': 20,
            '10.10.10.30': 30
        })
    mock_get_json_dump.return_value = {}
    assert network_ic_checker.finalize_unreachable_devices() == ['10.10.10.20']

    # # checks whether it handles exceptions properly
    mock_get_json_dump.side_effect = Exception
    assert network_ic_checker.finalize_unreachable_devices() == []


def test_list_comparison():
    """
    test list_comparison()
    """
    # checks whether it works as expected
    list_a = ['a', 'b', 'c', 'd']
    list_b = ['b', 'b', 'd']
    list_c = ['a', 'c']
    assert network_ic_checker.list_comparison(list_a, list_b) == list_c

    # checks whether it handles exceptions properly
    assert network_ic_checker.list_comparison(list_a, 1) is None


@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.list_comparison')
def test_find_devices_not_connected(mock_list_comparison):
    """
    test find_devices_not_connected()
    :param mock_list_comparison: mock call to pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.list_comparison()
    """
    # checks whether it works as expected if there are disconnected device
    couch_list = ['10.10.10.10', '10.10.10.20']
    arp_list = ['10.10.10.10']
    mock_list_comparison.return_value = ['10.10.10.20']
    assert network_ic_checker.find_devices_not_connected(couch_list, arp_list) == ['10.10.10.20']

    # checks whether it handles exceptions properly
    mock_list_comparison.side_effect = Exception
    assert network_ic_checker.find_devices_not_connected(couch_list, arp_list) is None


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_is_user_notified(mock_p_open_stripped):
    """
    test is_user_notified()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if time gap has not elapsed
    grep_time_upper = datetime.date.today() - datetime.timedelta(1)
    grep_time_upper = grep_time_upper.strftime("%Y-%m-%d")
    grep_time_lower = datetime.date.today()
    grep_time_lower = grep_time_lower.strftime("%Y-%m-%d")
    device_name = 'reg-1'
    time_gap_secs = 1000

    today = datetime.date.today().strftime("%Y-%m-%d")
    now = datetime.datetime.now().strftime("%H:%M:%S")
    mock_p_open_stripped.return_value = '2017-12-10 10:10:10,notification device:reg-2:2\n' \
                                        '%s %s,notification device:reg-1:1' % (today, now)

    assert network_ic_checker.is_user_notified(device_name, time_gap_secs)
    assert mock_p_open_stripped.mock_calls == [
        mock.call("grep -e '" + grep_time_upper + "' -e '" + grep_time_lower + "' "
                  + config.NETWORK_LOG + "| grep " + device_name + "|cut -d ' ' -f 1,2,5")]

    # checks whether it works as expected if time gap has elapsed
    mock_p_open_stripped.return_value = ''
    assert not network_ic_checker.is_user_notified(device_name, 0)

    # checks whether it works as expected if feedback is not 1
    mock_p_open_stripped.return_value = '2017-12-10 10:10:10,notification device:reg-2:2\n' \
                                        '%s %s,notification device:reg-1:2' % (today, now)
    assert not network_ic_checker.is_user_notified(device_name, time_gap_secs)

    # checks whether it works as expected if device is not available
    mock_p_open_stripped.return_value = '2017-12-10 10:10:10,notification device:reg-2:2\n' \
                                        '%s %s,notification device:reg-3:2' % (today, now)
    assert not network_ic_checker.is_user_notified(device_name, time_gap_secs)

    # checks whether it works as expected if no greps found
    mock_p_open_stripped.return_value = ''
    assert not network_ic_checker.is_user_notified(device_name, time_gap_secs)

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert not network_ic_checker.is_user_notified(device_name, time_gap_secs)


@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.is_user_notified')
@mock.patch('pulse_agent.services.cinco_identity_hos.get_register_no')
def test_send_pop_message_to_devices(mock_get_register_no, mock_is_user_notified,
                                     monkeypatch):
    """
    test send_pop_message_to_devices()
    :param mock_get_register_no: mock call to cinco_identity_hos.get_register_no()
    :param mock_is_user_notified: mock call to network_ic_checker.is_user_notified()
    :param monkeypatch: use to patch class variables
    """
    # checks whether it works as expected
    unreachable_device_array = ['10:10:10:10', '10:10:10:20']
    mock_is_user_notified.return_value = False
    mock_get_register_no.return_value = 2
    monkeypatch.setattr(
        'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.DEVICES',
        [
            DEVICE(ip="10:10:10:10", name="Printer-1", device="PRINTER", registers=2),
            DEVICE(ip="10:10:10:20", name="Desktop-1", device="DESKTOP", registers=2)
        ]
    )
    assert network_ic_checker.send_pop_message_to_devices(unreachable_device_array) is None

    # checks whether it handles exceptions properly
    mock_is_user_notified.side_effect = Exception
    assert network_ic_checker.send_pop_message_to_devices(unreachable_device_array) is None


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_latest_user_response(mock_p_open_stripped):
    """
    test is_user_notified()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if device is off
    grep_time_upper = datetime.datetime.now() - datetime.timedelta(minutes=60)
    grep_time_upper = grep_time_upper.strftime("%Y-%m-%d %H")
    grep_time_lower = datetime.datetime.now()
    grep_time_lower = grep_time_lower.strftime("%Y-%m-%d %H")
    device_name = 'reg-1'

    mock_p_open_stripped.return_value = 'reg-1:1\nreg-2:0'

    assert network_ic_checker.get_latest_user_response(device_name) == 'off'
    assert mock_p_open_stripped.mock_calls == [
        mock.call("grep -e '" + grep_time_upper + "' -e '" + grep_time_lower + "' "
                  + config.NETWORK_LOG + "| grep " + device_name
                  + "|cut -d ' ' -f 5|cut -d ':' -f 2,3")]

    # checks whether it works as expected if device is on
    mock_p_open_stripped.return_value = 'reg-1:0\nreg-2:0'
    assert network_ic_checker.get_latest_user_response(device_name) == 'on'

    # checks whether it works as expected if device is not available
    mock_p_open_stripped.return_value = 'reg-3:0\nreg-2:0'
    assert network_ic_checker.get_latest_user_response(device_name) == 'pending'

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert network_ic_checker.get_latest_user_response(device_name) == 'pending'


@mock.patch('pulse_agent.services.cinco_identity.get_register_no')
@mock.patch(
    'pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.get_latest_user_response')
def test_get_devices_which_really_problematic(mock_get_latest_user_response, mock_get_register_no):
    """
    test get_devices_which_really_problematic()
    :param mock_get_latest_user_response: mock call to pulse_agent.services.cinco_identity.get_latest_user_response()
    :param mock_get_register_no: mock call to pulse_agent.services.cinco_identity_hos.get_register_no()
    """
    # checks whether it works as expected if
    unreachable_device_array = ['10:10:10:10', '10:10:10:20', '10:10:10:30']
    devices_array = [
        DEVICE(ip="10:10:10:10", name="Printer-1", device="PRINTER", registers=2),
        DEVICE(ip="10:10:10:20", name="Desktop-1", device="DESKTOP", registers=2),
        DEVICE(ip="10:10:10:30", name="Desktop-2", device="DESKTOP", registers=2)
    ]
    mock_get_register_no.return_value = 2
    mock_get_latest_user_response.side_effect = ['on', 'off', 'pending']
    expected = [
        {"STATUS": "ERROR", "IP": "10:10:10:10", "NAME": "Printer-1"},
        {"STATUS": "FORCEFULLY TURNED OFF", "IP": "10:10:10:20", "NAME": "Desktop-1"}
    ]
    received = network_ic_checker.get_devices_which_really_problematic(unreachable_device_array, devices_array)
    for i in range(0, len(received) - 1):
        assert received[i]["STATUS"] == expected[i]["STATUS"]
        assert received[i]["IP"] == expected[i]["IP"]
        assert received[i]["NAME"] == expected[i]["NAME"]

    assert mock_get_latest_user_response.mock_calls == [
        mock.call("Printer-1"),
        mock.call("Desktop-1"),
        mock.call("Desktop-2"),
    ]

    # checks whether it handles exceptions properly
    mock_get_register_no.side_effect = Exception
    assert network_ic_checker.get_devices_which_really_problematic(unreachable_device_array, devices_array) is None


@mock.patch('pulse_agent.monitor.network.network_inter_connectivity_checker.network_ic_checker.list_comparison')
def test_find_exess_devices(mock_list_comparison):
    """
    test find_devices_not_connected()
    :param mock_list_comparison: mock call to network_ic_checker.list_comparison()
    """
    # checks whether it works as expected if there are disconnected device
    couch_list = ['10.10.10.10', '10.10.10.20']
    arp_list = ['10.10.10.10', '10:10:10:30']
    mock_list_comparison.return_value = ['10.10.10.30']
    assert network_ic_checker.find_exess_devices(couch_list, arp_list) == ['10.10.10.30']

    # checks whether it handles exceptions properly
    mock_list_comparison.side_effect = Exception
    assert network_ic_checker.find_exess_devices(couch_list, arp_list) is None


@mock.patch('pulse_agent.monitor.network.network.get_mtr_result')
def test_get_packet_loss_for_devices(mock_get_mtr_result):
    """
    test get_packet_loss_for_devices()
    :param mock_get_mtr_result: mock call to pulse_agent.monitor.network.network.get_mtr_result()
    """
    # checks whether it works as expected if
    ip_array = ['10:10:10:100', '10:10:10:200']
    mock_get_mtr_result.side_effect = [
        [
            {
                'IP': '10:10:10:100',
                'LOSS': '5%',
                'SNT': 'SNT',
                'LAST': 'LAST',
                'AVG': '2.0',
                'BEST': '0.5',
                'WRST': '4',
                'STDEV': '1.5'
            },
            {
                'IP': '10:10:10:200',
                'LOSS': '5%',
                'SNT': 'SNT',
                'LAST': 'LAST',
                'AVG': '2.0',
                'BEST': '0.5',
                'WRST': '4',
                'STDEV': '1.5'
            }
        ],
        [
            {
                'IP': '10:10:10:100',
                'LOSS': '5%',
                'SNT': 'SNT',
                'LAST': 'LAST',
                'AVG': '2.0',
                'BEST': '0.5',
                'WRST': '4',
                'STDEV': '1.5'
            },
            {
                'IP': '10:10:10:200',
                'LOSS': '5%',
                'SNT': 'SNT',
                'LAST': 'LAST',
                'AVG': '2.0',
                'BEST': '0.5',
                'WRST': '4',
                'STDEV': '1.5'
            }
        ]
    ]
    assert network_ic_checker.get_packet_loss_for_devices(ip_array) == [
        {
            '10:10:10:100': {
                'loss': '5%',
                'snt': 'SNT',
                'last': 'LAST',
                'avg': '2.0',
                'best': '0.5',
                'wrst': '4',
                'stdev': '1.5'
            }
        },
        {
            '10:10:10:200': {
                'loss': '5%',
                'snt': 'SNT',
                'last': 'LAST',
                'avg': '2.0',
                'best': '0.5',
                'wrst': '4',
                'stdev': '1.5'
            }
        }
    ]
    assert mock_get_mtr_result.mock_calls == [
        mock.call("10:10:10:100"),
        mock.call("10:10:10:200")
    ]

    # checks whether it handles exceptions properly
    mock_get_mtr_result.side_effect = Exception
    assert network_ic_checker.get_packet_loss_for_devices(ip_array) == []
