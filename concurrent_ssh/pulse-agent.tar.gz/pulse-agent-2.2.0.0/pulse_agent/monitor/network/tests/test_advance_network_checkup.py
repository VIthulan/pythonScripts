"""
tests for advance_network_checkup module
"""
# core modules
import logging
import mock

# testing module
from pulse_agent.monitor.network import advanced_network_checkup

# helpers
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


def setup_module(module):
    """
    setup test module
    :param module:
    """
    log = logging.getLogger('setup_module')
    log.info("setup_module module:%s", module.__name__)


def teardown_module(module):
    """
    teardown test module
    :param module:
    """
    log = logging.getLogger('teardown_module')
    log.info("teardown_module module:%s", module.__name__)


def setup_function(function):
    """
    setup test function
    :param function:
    """
    logging.info("setup_function function:%s", function.__name__)


def teardown_function(function):
    """
    teardown test function
    :param function:
    """
    log = logging.getLogger('teardown_function')
    log.info("teardown_function function:%s", function.__name__)


def test_check_for_packet_loss():
    """
    test check_for_packet_loss()
    """
    # checks whether it works as expected with empty mtr results
    assert advanced_network_checkup.check_for_packet_loss([]) == config.ERROR_MESSAGE

    # checks whether it works as expected with 1 loss hop count at LAN
    mtr_results = [
        {'LOSS': '5%', 'IP': '10.10.10.1'},
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    assert advanced_network_checkup.check_for_packet_loss(
        mtr_results) == 'Packet loss only occurred in local network with the amount of 5%'

    # checks whether it works as expected with 1 loss hop count outside LAN
    mtr_results = [
        {'LOSS': '5%', 'IP': '120.10.10.1'},
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    assert advanced_network_checkup.check_for_packet_loss(
        mtr_results) == 'Single hop shows a packet loss, possible reason could be an ICMP limiting'

    # checks whether it works as expected with many loss hop count at LAN
    mtr_results = [
        {'LOSS': '5%', 'IP': '10.10.10.1'},
        {'LOSS': '10%', 'IP': '10.10.10.2'},
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    assert advanced_network_checkup.check_for_packet_loss(
        mtr_results) == 'Packet loss propagates from local network with the final amount of 10%'

    # checks whether it works as expected with many loss hop count outside LAN
    mtr_results = [
        {'LOSS': '5%', 'IP': '10.10.10.1'},
        {'LOSS': '10%', 'IP': '120.10.10.2'},
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    assert advanced_network_checkup.check_for_packet_loss(
        mtr_results) == 'Packet loss propagates from remote network with the final amount of 10%'

    # checks whether it works as expected with no loss
    mtr_results = [
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    assert advanced_network_checkup.check_for_packet_loss(
        mtr_results) == 'No packet loss occurred'


def test_check_mtr_for_duplicates():
    """
    test check_mtr_for_duplicates()
    """
    # checks whether it works as expected with empty mtr result
    assert not advanced_network_checkup.check_mtr_for_duplicates([])

    # checks whether it works as expected if there are duplicates
    mtr_results = [
        {'LOSS': '5%', 'IP': '10.10.10.1'},
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    assert advanced_network_checkup.check_mtr_for_duplicates(mtr_results)

    # checks whether it works as expected if there are no duplicates
    mtr_results = [
        {'LOSS': '5%', 'IP': '10.10.10.1'},
        {'LOSS': '0%', 'IP': '10.10.10.2'}
    ]
    assert not advanced_network_checkup.check_mtr_for_duplicates(mtr_results)

    # checks whether it handles exceptions properly
    assert not advanced_network_checkup.check_mtr_for_duplicates("")


@mock.patch('pulse_agent.monitor.network.network.is_ethtool_installed')
@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_network_interface_stats(mock_p_open_stripped, mock_is_ethtool_installed):
    """
    test get_network_interface_stats()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    :param mock_is_ethtool_installed: mock call to pulse_agent.monitor.network.network.is_ethtool_installed()
    """
    # checks whether it works as expected if ethtool is installed
    mock_is_ethtool_installed.return_value = True
    mock_p_open_stripped.return_value = 'eth0 is connected'
    assert advanced_network_checkup.get_network_interface_stats(
        config.ETH0_NETWORK_INTERFACE) == mock_p_open_stripped.return_value
    assert mock_p_open_stripped.mock_calls == [mock.call("ethtool -S " + config.ETH0_NETWORK_INTERFACE)]

    # checks whether it works as expected if ethtool is not installed
    mock_is_ethtool_installed.return_value = False
    assert advanced_network_checkup.get_network_interface_stats(
        config.ETH0_NETWORK_INTERFACE) == 'Eth0 is not installed'

    # checks whether it handles exceptions properly
    mock_is_ethtool_installed.side_effect = Exception
    assert advanced_network_checkup.get_network_interface_stats(config.ETH0_NETWORK_INTERFACE) == config.ERROR_MESSAGE


def test_is_packet_loss_problematic():
    """
    test is_packet_loss_problematic()
    """
    # checks whether it works as expected if problematic
    packet_loss = 'packet loss only occured in local with amount 10%'
    assert advanced_network_checkup.is_packet_loss_problematic(packet_loss)

    # checks whether it works as expected if problematic
    packet_loss = 'packet loss initially occured in LAN'
    assert advanced_network_checkup.is_packet_loss_problematic(packet_loss)

    # checks whether it works as expected if not problematic
    assert not advanced_network_checkup.is_packet_loss_problematic("")

    # checks whether it handles exceptions properly
    assert not advanced_network_checkup.is_packet_loss_problematic(None)


@mock.patch('pulse_agent.monitor.network.network.get_mtr_result')
@mock.patch('pulse_agent.monitor.network.advanced_network_checkup.check_mtr_for_duplicates')
@mock.patch('pulse_agent.monitor.network.advanced_network_checkup.check_for_packet_loss')
@mock.patch('pulse_agent.monitor.network.advanced_network_checkup.is_packet_loss_problematic')
@mock.patch('pulse_agent.monitor.network.advanced_network_checkup.get_network_interface_stats')
@mock.patch('pulse_agent.utils.pulse_client.pulse_client.post')
def test_do_advanced_check(mock_post, mock_get_network_interface_stats, mock_is_packet_loss_problematic,
                           mock_check_for_packet_loss, mock_check_mtr_for_duplicates, mock_get_mtr_result):
    """
    test do_advanced_check()
    :param mock_post: mock call to pulse_agent.utils.pulse_client.pulse_client.post()
    :param mock_get_network_interface_stats:
    mock call to pulse_agent.monitor.network.advanced_network_checkup.get_network_interface_stats()
    :param mock_check_for_packet_loss:
    mock call to pulse_agent.monitor.network.advanced_network_checkup.check_for_packet_loss()
    :param mock_is_packet_loss_problematic:
    mock call to pulse_agent.monitor.network.advanced_network_checkup.is_packet_loss_problematic()
    :param mock_check_mtr_for_duplicates:
    mock call to pulse_agent.monitor.network.advanced_network_checkup.check_mtr_for_duplicates()
    :param mock_get_mtr_result: mock call to pulse_agent.monitor.network.network.get_mtr_result()
    """
    # checks whether it works as expected if
    mock_get_mtr_result.return_value = [
        {'LOSS': '5%', 'IP': '10.10.10.1'},
        {'LOSS': '10%', 'IP': '10.10.10.1'},
        {'LOSS': '0%', 'IP': '10.10.10.1'}
    ]
    mock_check_mtr_for_duplicates.return_value = ''
    mock_check_for_packet_loss.return_value = ''
    mock_is_packet_loss_problematic.return_value = ''
    mock_get_network_interface_stats.return_value = ''
    mock_post.return_value = True
    assert advanced_network_checkup.do_advanced_check() is None

    # checks whether it handles exceptions properly
    mock_get_mtr_result.side_effect = Exception
    assert advanced_network_checkup.do_advanced_check() is None
