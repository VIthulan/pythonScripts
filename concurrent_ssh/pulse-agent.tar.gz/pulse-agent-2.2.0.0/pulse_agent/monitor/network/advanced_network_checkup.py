"""
This module contains functions related to advanced checkups
"""
import logging
from pulse_agent.monitor.network import network
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config
from pulse_agent.utils.pulse_client import pulse_client


def do_advanced_check(env=None):
    """
    Do Advanced checkup
    :return:
    """
    try:
        # Get mtr result
        mtr_result = network.get_mtr_result('google.com')

        # Check for network loops using mtr result
        suspect_loops = None
        if check_mtr_for_duplicates(mtr_result):
            suspect_loops = True

        # Check for packet loss using mtr result
        packet_loss_results = check_for_packet_loss(mtr_result)

        response = {
            'REPORT': {
                'MTR_FULL_RESULT': {
                    'RESULTS': mtr_result
                },
                'PACKET_LOSS': {
                    'RESULTS': packet_loss_results,
                    'STATUS': is_packet_loss_problematic(packet_loss_results)
                },
                'SUSPECT_LOOPS': {
                    'STATUS': suspect_loops
                },
                'INTERFACE_STATS': {
                    'RESULTS': get_network_interface_stats(config.ETH0_NETWORK_INTERFACE)
                }
            }
        }

        if env is None:
            pulse_client.post(config.NETWORK_ADVANCED_CHECK_RESULT_END_POINT, body=response)
        else:
            pulse_client.get_client(env).post(config.NETWORK_ADVANCED_CHECK_RESULT_END_POINT,
                                              body=response)

    except Exception as exception:
        logging.exception("Error in getting network interface stats: %s", exception)


def is_packet_loss_problematic(packet_loss_result):
    """
    is_packet_loss_problematic
    :param packet_loss_result:
    :return:
    """
    try:
        return packet_loss_result.startswith('packet loss only occured in local with amount') \
               or packet_loss_result.startswith('packet loss initially occured in')

    except Exception as exception:
        logging.exception("Error in checking whether packet loss is problematic: %s", exception)
        return False


def get_network_interface_stats(interface):
    """
    get_network_interface_stats
    :param interface:
    :return:
    """
    try:
        if network.is_ethtool_installed():
            command = "ethtool -S " + interface
            logging.debug(command)
            result = sub_process.p_open_stripped(command)
            logging.debug('ethtool to get interface stats: %s', result)
            return result
        return 'Eth0 is not installed'
    except Exception as exception:
        logging.exception("Error in getting network interface stats: %s", exception)
        return config.ERROR_MESSAGE


def check_mtr_for_duplicates(mtr_result):
    """
    check_mtr_for_duplicates
    :param mtr_result:
    :return:
    """
    try:
        ip_list = []
        for hop in mtr_result:
            hop_ip = hop.get('IP')
            if not hop_ip.startswith('?'):
                ip_list.append(hop_ip)
        return len(ip_list) != len(set(ip_list))
    except Exception as exception:
        logging.exception("Error in checking for duplicate entries in mtr: %s", exception)
        return False


def check_for_packet_loss(mtr_result):
    """
    check_for_packet_loss
    :param mtr_result:
    :return:
    """
    try:
        loss_list = []
        occurred_hop_count = 0
        initial_occurred_hop = -1
        final_occurred_hop = 0
        for hop in mtr_result:
            loss_list.append(hop.get('LOSS'))

        for i in range(len(loss_list)):
            if loss_list[i] and float(str(loss_list[i])[:-1]) > 0:
                occurred_hop_count = occurred_hop_count + 1
                if initial_occurred_hop < 0:
                    initial_occurred_hop = i
                final_occurred_hop = i

        final_occurred_hop_loss = mtr_result[final_occurred_hop].get('LOSS')
        final_occurred_hop_ip = mtr_result[final_occurred_hop].get('IP')

        if occurred_hop_count == 1:
            if str(final_occurred_hop_ip).startswith('10.'):
                return 'Packet loss only occurred in local network with the amount of ' + final_occurred_hop_loss
            return 'Single hop shows a packet loss, possible reason could be an ICMP limiting'

        elif occurred_hop_count > 1:
            logging.debug('Initial occurred hops: %s', initial_occurred_hop)
            logging.debug('Initial occurred hops IP: %s', str(final_occurred_hop_ip))
            if str(final_occurred_hop_ip).startswith('10.'):
                return 'Packet loss propagates from local network with the final amount of %s' % final_occurred_hop_loss
            return 'Packet loss propagates from remote network with the final amount of %s' % final_occurred_hop_loss

        return 'No packet loss occurred'

    except Exception as exception:
        logging.exception("Error in checking packet loss in mtr: %s", exception)
        return config.ERROR_MESSAGE
