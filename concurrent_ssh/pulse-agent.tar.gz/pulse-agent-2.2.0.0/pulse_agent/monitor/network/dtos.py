"""
DTOS related to network aspect
"""


# pylint: skip-file
# Pylint warns All Caps variables are not invalid

class STATE(object):
    def __init__(self, status=False, results=None):
        if results is None:
            results = []
        self.STATUS = status
        self.RESULTS = results


class DEVICE(object):
    def __init__(self, ip=None, name=None, device=None, registers=None):
        self.IP = ip
        self.NAME = name
        self.TYPE = device
        self.CONNECTED_REGISTER = registers


class Report(object):
    NETWORK_INTERFACE_UP = None
    CABLE_CONNECTED = None
    CONNECTED_TO_CP = None
    CONNECTED_TO_INTERNET = None
    UNREACHABLE_DEVICE_IP_LIST = None
    UNKNOWN_DEVICES_IP_LIST = None
    ARP = None
    TRACE_ROUTE = None
    CP_BELONGS_TO_TRACEROUTE = None
    DEVICE_PACKET_LOSS = None
