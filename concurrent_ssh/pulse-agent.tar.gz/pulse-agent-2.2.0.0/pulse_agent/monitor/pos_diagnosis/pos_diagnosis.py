"""
This module contains functions that analyzes COMMON pos diagnosis.
Special analyses can be moved into separate modules
"""
import logging
import subprocess
import time
import os
import pickle
import re
import datetime
from pulse_agent.utils import json_utils
from pulse_agent.monitor.pos_diagnosis.dtos import ValueDesc
from pulse_agent.utils.config_managers import pos_config_manager
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config


def check_xrog_crashes_given_day(day='today'):
    """
    check_xrog_crashes_given_day
    :param day: today/yesterday
    :return: status
    """
    commands = {
        'today': {
            'day': 'date  +"%-d"', 'month': 'date +"%b"', 'year': 'date  +"%Y"'
        },
        'yesterday': {
            'day': 'date --date="1 days ago" +"%-d"',
            'month': 'date --date="1 days ago" +"%b"',
            'year': 'date --date="1 days ago" +"%Y"'
        }
    }

    try:
        grep_month = sub_process.p_open_stripped(commands.get(day).get('month'))
        grep_day = sub_process.p_open_stripped(commands.get(day).get('day'))

        if int(grep_day) < 10:  # get grep argument in required format 'May  8'
            space = '  '
        else:  # get grep argument in required format 'May 18'
            space = ' '

        grep_day_month = grep_month + space + grep_day
        command = 'zgrep -i "Xorg Tainted:" /var/log/syslog* | grep "' + grep_day_month + '"'
        logging.debug(command)
        xorg_crashes = sub_process.p_open(command)
        xorg_crashes_list = xorg_crashes.stdout.read().rstrip().splitlines()

        logging.debug("Xorg Crashes for %s: %s", day, xorg_crashes_list)

        return xorg_crashes_list

    except Exception as exception:
        logging.exception('Error in getting XorgCrashes for yesterday: %s', exception)
        return config.ERROR_MESSAGE


def check_xrog_crashes(caller):
    """
    check_xrog_crashes
    :param caller: on-demand/reboot
    :return: status
    """
    try:
        total_xorg_crashes_list = []
        if caller == 'reboot':
            today_status = check_xrog_crashes_given_day(day='today')
            yesterday_status = check_xrog_crashes_given_day(day='yesterday')
            if today_status == config.ERROR_MESSAGE or yesterday_status == config.ERROR_MESSAGE:
                return config.ERROR_MESSAGE
            total_xorg_crashes_list = yesterday_status + today_status
        elif caller == 'on-demand':
            if check_xrog_crashes_given_day(day='today') == config.ERROR_MESSAGE:
                return config.ERROR_MESSAGE
            total_xorg_crashes_list = check_xrog_crashes_given_day(day='today')

        total_xorg_crashes_count = len(total_xorg_crashes_list)

        if total_xorg_crashes_count == 0:
            logging.debug("Xorg has not been Tainted Success")
            return ValueDesc()

        logging.warning("Xorg has been Tainted Error")

        # Getting the date_time for the first Xorg crash occurance yesterday and today
        xorg_crash = total_xorg_crashes_list[0]
        xorg_crash_splitted = xorg_crash.split(' ')
        xorg_crash_date_time = (xorg_crash_splitted[0] + ' ' + xorg_crash_splitted[1] + ' ' +
                                xorg_crash_splitted[2])
        xorg_crash_date_time = xorg_crash_date_time.replace(xorg_crash_date_time.split(':')[0], '')

        return ValueDesc(value=config.MESSAGE_XORG_TAINTED, desc=str(total_xorg_crashes_list[0]),
                         date=xorg_crash_date_time)
    except Exception as exception:
        logging.exception('Error while calculating xorg crashes: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def check_touch_fixes():
    """
    check_touch_fixes
    :return:
    """
    try:
        command = "dpkg -s lp-touch 2>&1 | grep 'ok installed'"
        touch_fixes = sub_process.p_open_stripped(command)
        logging.debug("Touch Fixes: " + touch_fixes)
        if touch_fixes == '':
            logging.warning('Touch fixes are not applied Error')
            return ValueDesc(value=config.MESSAGE_TOUCH_FIXES_NOT_APPLIED)

        logging.debug('Touch fixes are applied Success')
        return ValueDesc()

    except Exception as exception:
        logging.exception('Error while checking touch fixes: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def check_touch_drivers():
    """
    Check Touch Driver error for later cinco version
    Code assumes that data within one year is available in syslog
    :return:
    """

    try:
        (grep_month, err) = sub_process.p_open_default(['date', '+%b'], stdout=subprocess.PIPE,
                                                       universal_newlines=True).communicate()
        if err is not None:
            logging.error(err)
        grep_month = grep_month.rstrip()
        (grep_day, err) = sub_process.p_open_default(['date', '+%-d'], stdout=subprocess.PIPE,
                                                     universal_newlines=True).communicate()
        if err is not None:
            logging.error(err)
        grep_day = grep_day.rstrip()
        if int(grep_day) < 10:  # get grep argument in required format 'May  8'
            space = '  '
        else:  # get grep argument in required format 'May 18'
            space = ' '

        grep_day_month = grep_month + space + grep_day
        command = ('grep "' + grep_day_month + '" ' + config.SYS_LOG_PATH +
                   ' | grep "lp-touch: unable to find device" | head -1 | cut -d : -f 4')
        logging.debug(command)
        touch_driver_error = sub_process.p_open_stripped(command)
        logging.debug('touch drivers number of error logs: %s', touch_driver_error)

        if touch_driver_error == '':
            logging.debug('Touch driver configuration succeeded')
            return ValueDesc()

        logging.warning('Touch driver configuration error')
        return ValueDesc(value=config.MESSAGE_TOUCH_DRIVER_CONFIG_ERROR,
                         desc=touch_driver_error,
                         date=time.strftime("%a, %d %b %Y"))

    except Exception as exception:
        logging.exception('Error while checking touch drivers: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


# Check Hard Disk bad sectors
def check_hard_disk_bad_sectors():
    """
    check_hard_disk_bad_sectors
    :return:
    """
    try:
        value_desc = ValueDesc()
        error_string = ''
        is_smart_enabled = sub_process.p_open_stripped(
            "dpkg --get-selections| grep 'smartmontools'")

        if is_smart_enabled == '':
            logging.error('smartmon tool is not installed')
            value_desc.VALUE = config.ERROR_MESSAGE
            value_desc.DESCRIPTION = ''
            value_desc.DATE_TIME = 'NULL'
            return ValueDesc(value=config.ERROR_MESSAGE)

        logging.info('OK smartmon tool is installed')

        # ATT_NAME|VALUE|WORST|THRESH|TYPE|RAW_VALUE
        hd_bad_sectors_command = ("smartctl -A /dev/sda | grep -e 'Current_Pending_Sector' -e "
                                  "'Offline_Uncorrectable' -e 'Reallocated_Sector_Ct'"
                                  "| awk '{print $2\";\"$4\";\"$5\";\"$6\";\"$7\";\"$10}'")

        hd_bad_sectors = sub_process.p_open_stripped(hd_bad_sectors_command)
        bad_sector_lines = hd_bad_sectors.splitlines()

        for line, _ in enumerate(bad_sector_lines):
            error_string = str(error_string) + '' + str(bad_sector_lines[line]) + '  '

        logging.debug("Hard Disk Bad Sectors: %s", hd_bad_sectors)
        bad_sector_check_result = is_having_bad_sector(bad_sector_lines)

        if bad_sector_check_result is False:
            return ValueDesc(desc=error_string)

        return ValueDesc(value=config.MESSAGE_HD_FAILURES_FOUND, desc=error_string)

    except Exception as exception:
        logging.exception("Error while checking HD bad sectors: %s", exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def is_having_bad_sector(bad_sector_lines):
    """
    is_having_bad_sector
    :param bad_sector_lines: bad sector list
    :return:
    """
    for line in bad_sector_lines:
        line_content = line.split(';')
        raw_count = int(line_content[-1])

        logging.debug("Bad sector status: %s", (line_content[1] != line_content[2]))

        if (raw_count > 0) or (line_content[1] != line_content[2]):
            logging.warning("Has Bad Sectors Method Resulted: True")
            return True

    logging.debug("Has Bad Sectors Method Resulted: False")
    return False


def check_syslog_hd_status(caller):
    """
    check_syslog_hd_status
    :param caller: on-demand/reboot
    :return:
    """
    sys_log_hd_status_list = []

    try:
        if caller == 'reboot':

            today_status = check_syslog_hd_status_for_day(checking_day='today')
            yesterday_status = check_syslog_hd_status_for_day(checking_day='yesterday')

            if today_status == config.ERROR_MESSAGE or yesterday_status == config.ERROR_MESSAGE:
                return config.ERROR_MESSAGE

            sys_log_hd_status_list = yesterday_status + today_status

        elif caller == 'on-demand':
            today_status = check_syslog_hd_status_for_day(checking_day='today')

            if today_status == config.ERROR_MESSAGE:
                return config.ERROR_MESSAGE

            sys_log_hd_status_list = check_syslog_hd_status_for_day(checking_day='today')

        if not sys_log_hd_status_list:
            return ValueDesc()

        # Getting the date_time for the first occurance of yesterday and today
        sys_log_hd_status = sys_log_hd_status_list[0]
        sys_log_hd_status_splitted = sys_log_hd_status.split(' ')
        sys_log_hd_status_date_time = (sys_log_hd_status_splitted[0] + ' '
                                       + sys_log_hd_status_splitted[1] + ' '
                                       + sys_log_hd_status_splitted[2])
        sys_log_hd_status_date_time = sys_log_hd_status_date_time.replace(
            sys_log_hd_status_date_time.split(':')[0], '')

        return ValueDesc(value=config.MESSAGE_KERNEL_DISK_READ_FAILURES_FOUND,
                         desc=sys_log_hd_status_list[0], date=sys_log_hd_status_date_time)
    except Exception as exception:
        logging.exception('Error while checking syslog hd status: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def check_syslog_hd_status_for_day(checking_day='today'):
    """
    check_sys_log_hd_status_given_day
    :param checking_day: today/yesterday
    :return: status
    """
    commands = {
        'today': {
            'day': 'date  +"%-d"',
            'month': 'date +"%b"'
        },
        'yesterday': {
            'day': 'date --date="1 days ago" +"%-d"',
            'month': 'date --date="1 days ago" +"%b"'
        }
    }

    try:
        grep_month = sub_process.p_open_stripped(commands.get(checking_day).get('month'))

        grep_day = sub_process.p_open_stripped(commands.get(checking_day).get('day'))

        if int(grep_day) < 10:
            space = '  '
        else:
            space = ' '

        grep_day_month = grep_month + space + grep_day
        command = 'zgrep "Unrecovered read error" /var/log/syslog* | grep "' + grep_day_month + '"'
        logging.debug(command)
        sys_log_status_list = sub_process.p_open_stripped(command).splitlines()

        logging.info('System log hd status %s', sys_log_status_list)
        return sys_log_status_list
    except Exception as exception:
        logging.exception('Error while getting sys log status for %s: %s', checking_day, exception)
        return config.ERROR_MESSAGE


def check_stuck_on_loading():
    """
    get_stuck_on_loading_from_frontend_log
    :return:
    """
    # [WebPOS LOADING ERROR] Exceed more than 5 minutes to load the app : Sat Oct 31 2015
    try:
        today_date = time.strftime("%a %b %d %Y")
        command = ("grep '" + today_date + "' " + config.FRONT_END_LOG_PATH +
                   " | grep 'WebPOS LOADING ERROR"
                   "'| grep 'Exceed more than 5 minutes to load the app' | cut -d ',' -f 1")
        logging.debug(command)
        stuck_on_loading_last_occurred = sub_process.p_open_stripped(command)

        if stuck_on_loading_last_occurred == '':
            logging.debug('Stuck on loading is not detected')
            return ValueDesc()

        logging.warning('result for stuck on loading: %s', stuck_on_loading_last_occurred)

        return ValueDesc(value=config.MESSAGE_STUCK_ON_LOADING_FOUND,
                         desc=stuck_on_loading_last_occurred)

    except Exception as exception:
        logging.exception("Error while finding stuck on loading in frontend log: %s", exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def get_smartctl_self_assessment():
    """
    get_smartctl_self_assessment
    :return:
    """
    try:
        command = ("smartctl -H /dev/sda | grep "
                   "'SMART overall-health self-assessment test result'|cut -d ':' -f 2")
        logging.debug(command)
        smartctl_self_assessment_result = sub_process.p_open_stripped(command)

        if smartctl_self_assessment_result == 'PASSED':
            return ValueDesc()

        elif smartctl_self_assessment_result == 'FAILED!':
            return ValueDesc(value=config.MESSAGE_SAMRTMON_SELF_ASSESSMENT_FAILED,
                             desc='SMART overall-health self-assessment test result : FAILED!')

        return ValueDesc(value=config.ERROR_MESSAGE)

    except Exception as exception:
        logging.exception('Error while getting smartctl self assessment result: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def check_eth0_connectivity():
    """

    :return:
    """
    try:
        logging.debug("checking eth0 availability")
        if os.path.exists(config.ETH0_FILE_PATH):
            status_command = "grep -e up -e down /sys/class/net/eth0/operstate"
            logging.debug(status_command)
            status = sub_process.p_open_stripped(status_command)
            logging.debug(status)
            if status == 'down':
                return ValueDesc(value=config.ETH_0_NOT_AVAILABLE)
            elif status == 'up':
                today_date = time.strftime("%Y-%m-%d")
                moxyerr_command = ('zgrep -e "bind_interface" ' + config.MOXY_LOG_FILES +
                                   ' | grep -e "eth0" | grep -e "null" ' + ' | grep "'
                                   + today_date + '"')
                logging.debug('moxy err command for eth0 test : %s', moxyerr_command)
                moxyerr_list = sub_process.p_open_stripped(moxyerr_command).splitlines()

                if moxyerr_list:
                    return ValueDesc(value=config.ETH_0_NOT_AVAILABLE)
            return ValueDesc()
        else:
            return ValueDesc(value=config.ETH_0_NOT_AVAILABLE)
    except Exception as exception:
        logging.exception('Error while checking eth0 availability: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def is_pulse_version_changed():
    """
    is_pulse_version_changed
    :return: true/false
    """
    try:
        preference_entries = pos_config_manager.load_pref_entries(config.PREFS_FILE)
        if not preference_entries:
            logging.error("Error: Preference entries empty")
            return 'Error: Preference entries empty'
        pulse_version = pos_config_manager.get_preference_value(preference_entries,
                                                                config.CLIENT_VERSION)

        logging.info(
            "[PULSE-VERSION-CHECK]pulse version in the version conf is :" + pulse_version)

        if not os.path.exists(config.CINCO_VERSION_PKL_FILE):
            with open(config.CINCO_VERSION_PKL_FILE, "wb") as output_file:
                pickle.dump('', output_file)

        with open(config.CINCO_VERSION_PKL_FILE, "rb") as input_file:
            pulse_version_in_file = pickle.load(input_file)
            logging.info(
                "[PULSE-VERSION-CHECK]pulse version in the file is :" + pulse_version_in_file)

        if not pulse_version_in_file:
            with open(config.CINCO_VERSION_PKL_FILE, "wb") as output_file:
                pickle.dump(pulse_version, output_file)
            logging.info('[PULSE-VERSION-CHECK]-------empty--------False')
            return False
        elif pulse_version_in_file != pulse_version:
            with open(config.CINCO_VERSION_PKL_FILE, "wb") as output_file:
                pickle.dump(pulse_version, output_file)
            logging.info('[PULSE-VERSION-CHECK]-------version changed--------True')
            return True

        logging.info('[PULSE-VERSION-CHECK]-------version not changed--------False')
        return False

    except Exception as exception:
        logging.exception("Error while checking pulse version changed: %s", exception)
        return False


def get_payment_cube_firmware_upgrade_info():
    """
    This method gets information regarding payment cube firmware upgrade from dm_devices.log
    :param self:
    :return:
    """
    try:
        today_date = time.strftime("%Y-%m-%d")
        command = ("zgrep --with-filename 'PULSE' " + config.DM_DEVICES_LOG + " | grep '" + today_date
                   + "'|grep  '\[PULSE\].*\[FWU\].*\[[A-Za-z]*\].*\[[0-9]*\].*\[.*\]'") # pylint: disable=W1401
        logging.debug(command)
        firmware_upgrade_info = sub_process.p_open(command)
        firmware_upgrade_info = firmware_upgrade_info.stdout.readlines()
        logging.debug('result for payment cube firmware upgrade failure info: %s',
                      firmware_upgrade_info)

        if firmware_upgrade_info:
            firmware_upgrade_info_list = []
            for line in firmware_upgrade_info:
                splitted_line = line.rstrip().lstrip()

                # Find the date in unix
                date = splitted_line.split(':', 1)[1].split(',')[0].rstrip().lstrip()
                unix_time = time.mktime(
                    datetime.datetime.strptime(date, "%Y-%m-%d %H:%M:%S").timetuple())

                # Find the type,code and message
                match_line = re.findall('\[PULSE\].\[FWU\].\[[\w]*\].\[[\w]*\].\[.*\]',# pylint: disable=W1401
                                        splitted_line)[0]

                splitted_match_line = re.findall("\[(.*?)\]", match_line) # pylint: disable=W1401

                firmware_upgrade_info_list.append(
                    {"time": unix_time, "type": splitted_match_line[2].strip('[]'),
                     "code": splitted_match_line[3].strip('[]'),
                     "message": splitted_match_line[4].strip('[]')})

            return firmware_upgrade_info_list
        return None
    except Exception as exception:
        logging.exception('Error while getting firmware upgrade info: %s', exception)
        return None


def get_payment_cube_firmware_upgrade_failure():
    """
    This method filters details on payment cube firmware upgrade
    :param self:
    :return:
    """
    try:
        info_list = get_payment_cube_firmware_upgrade_info()
        if info_list is not None and info_list:
            upgrade_failure_list = []
            for info in info_list:
                if info.get('type') == 'ERR':
                    upgrade_failure_list.append(info)

            if upgrade_failure_list:
                return ValueDesc(value=config.FIRMWARE_UPGRADE_FAIL,
                                 desc=json_utils.get_json_dump(upgrade_failure_list))

        return ValueDesc()
    except Exception as exception:
        logging.exception('Error while getting firmware upgrade failure: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)
