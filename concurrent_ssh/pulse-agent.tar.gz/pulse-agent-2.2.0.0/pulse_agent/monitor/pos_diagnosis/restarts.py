"""
This module contains functions related to diagnosis about restarts
"""
import logging
import datetime
import os
import pickle

from pulse_agent.monitor.pos_diagnosis.dtos import ValueDesc
from pulse_agent.utils import sub_process
from pulse_agent.utils import time_utils
from pulse_agent.utils.config import config


def reboot_count_between_restarts(restart_time, caller):
    """
    reboot_count_between_restarts
    :param restart_time: start time
    :param caller: on-demand/reboot
    :return: counts
    """
    try:
        full_reboot_list = []
        result_list = []
        unix_time_reboot_list = []
        result_string_in_date = ''

        del unix_time_reboot_list[:]
        del result_list[:]
        del full_reboot_list[:]

        logging.debug('After deleting result list %s', result_list)

        # Merge two reboot lists of today(begins 00.00.00) and yesterday (begins 00.00.00)
        if caller == 'reboot':
            full_reboot_list = get_restart_log(day='today') + get_restart_log(day='yesterday')
            logging.debug('Restarts for today and yesterday %s', str(full_reboot_list))
        elif caller == 'on-demand':
            full_reboot_list = get_restart_log(day='today')
            logging.debug('Restarts for today %s', str(full_reboot_list))

        # Store all time stamps in unix time inside the list unix_time_reboot_list
        for reboot_time in full_reboot_list:
            unix_time_reboot_list.append(time_utils.date_to_unix(reboot_time))
        logging.debug('Restarts for today and yesterday in unix ' + str(unix_time_reboot_list))

        # Get the today date in unix time
        today_in_normal = sub_process.p_open_stripped('date  +"%b  %d ' + restart_time + ' %Y"')
        logging.debug('Today is %s', str(today_in_normal))
        today_in_unix = time_utils.date_to_unix(today_in_normal)
        logging.debug('Today unix time is: %s', str(today_in_unix))

        # Get the tomorrow date in unix time
        yesterday_in_normal = sub_process.p_open_stripped(
            'date --date="1 days ago" +"%b  %d   ' + restart_time + ' %Y"')
        logging.debug('Yesterday is %s', str(yesterday_in_normal))
        yesterday_in_unix = time_utils.date_to_unix(yesterday_in_normal)
        logging.debug('Yesterday unix time is is %s', str(yesterday_in_unix))

        # Find how many restarts within current and previous restart
        for reboot_time in unix_time_reboot_list:
            if today_in_unix >= reboot_time >= yesterday_in_unix:
                result_list.append(reboot_time)

        logging.info('Reboots between yesterday restart and today restarts: %s', result_list)
        # find the reboot count
        reboot_count = len(result_list)

        num_of_seperators = 0

        if result_list:
            for unix_date in result_list:
                result_string_in_date = result_string_in_date + '' + str(
                    time_utils.unix_to_date(unix_date))
                if num_of_seperators < len(result_list) - 1:
                    result_string_in_date = result_string_in_date + ','
                    num_of_seperators = num_of_seperators + 1

        logging.info('REBOOT COUNT IS: %s', str(len(result_list)))

        return ValueDesc(value=reboot_count, desc=result_string_in_date)

    except Exception as exception:
        logging.exception('Error while calculating restart counts: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def get_restart_log(day='today'):
    """
    This method greps all the restarts within today and stores them inside a list
    and returns that list
    """
    commands = {'today': {'day': 'date  +"%-d"', 'month': 'date +"%b"', 'year': 'date  +"%Y"'},
                'yesterday': {'day': 'date --date="1 days ago" +"%-d"',
                              'month': 'date --date="1 days ago" +"%b"',
                              'year': 'date --date="1 days ago" +"%Y"'}}
    try:
        grep_month = sub_process.p_open_stripped(commands.get(day).get('month'))
        grep_day = sub_process.p_open_stripped(commands.get(day).get('day'))
        grep_year = sub_process.p_open_stripped(commands.get(day).get('year'))

        if int(grep_day) < 10:  # get grep argument in required format 'May  8..........2015 -'
            space = '  '
        else:  # get grep argument in required format 'May 18..........2015 -'
            space = ' '

        grep_command = grep_month + space + grep_day + '..........' + grep_year + ' -'

        # get command to be executed which outputs in format 'Jun  15   15:30:00 2015'
        command = ("last reboot -F|grep  '" + grep_command.rstrip() +
                   "' | tr -s ' ' |cut -d ' ' -f 6,7,8,9 ")

        # execute the command
        reboot_list = sub_process.p_open_stripped(command).splitlines()

        logging.info('Today reboots %s', str(reboot_list))
        return reboot_list

    except Exception as exception:
        logging.exception('Error while calculating restarts: %s', exception)
        raise Exception


def list_comparison(a, b):
    """
    To  take elements which are in list A but not in list B
    """
    b = set(b)
    return [aa for aa in a if aa not in b]


def restart_cause(unix_date):
    """
    Restart cause
    :param unix_date: time
    :return: cause
    """
    try:

        if pwrf_within_given_minutes(unix_date, 0) == "" and pwrf_within_given_minutes(
                unix_date, 1) == "" and pwrf_within_given_minutes(unix_date, 2) == "":
            return 'Automatic'

        return 'Forceful'
    except Exception as exception:
        logging.exception("Error while getting restart cause: %s", exception)


def pwrf_within_given_minutes(unix_date, before_time_minutes):
    """
    Sep  6 21:00:51 cincopos acpid: procfs received event "button/power PWRF 00000080 00000001"
    grep 'Sep  6 21:00' /var/log/syslog|grep 'button/power PWRF'
    :param unix_date: time
    :param before_time_minutes: before time
    :return:
    """
    try:
        unix_date_before_given_mins = unix_date - before_time_minutes * 60

        time_stamp_within_frame = datetime.datetime.fromtimestamp(
            unix_date_before_given_mins).strftime('%b  %-d %H:%M:')

        power_button_event_command = ('grep "' + time_stamp_within_frame +
                                      '" /var/log/syslog|grep "button/power PWRF"')
        logging.debug("[RESTARTS SENDER] Restart State Command " + power_button_event_command)
        power_button_event = sub_process.p_open_stripped(power_button_event_command)
        logging.debug("[RESTARTS SENDER] Restart State " + power_button_event)
        return power_button_event
    except Exception as exception:
        logging.exception("Error while getting restarts within given minute: %s", exception)


def gather_new_restarts():
    """
    Gather new restarts
    :return:
    """
    try:
        current_unix_time_reboot_list = []

        if not os.path.exists(config.RESTART_DATA_PKL_FILE):
            with open(config.RESTART_DATA_PKL_FILE, "wb") as output_file:
                pickle.dump([], output_file)

        with open(config.RESTART_DATA_PKL_FILE, "rb") as input_file:
            stored_restarts_list = pickle.load(input_file)

        logging.info("[RESTARTS SENDER] Stored restarts list" + str(stored_restarts_list))

        # check and get if restarts times are between 6hrs and remove other
        already_known_restarts = time_utils.get_unix_time_list_within_frame(stored_restarts_list, 6)

        logging.info(
            "[RESTARTS SENDER] Already known restarts within 6 hours" + str(already_known_restarts))

        current_reboot_list = get_restart_log(day='today') + get_restart_log(day='yesterday')
        logging.debug("[RESTARTS SENDER] Current reboot list" + str(current_reboot_list))
        for reboot_time in current_reboot_list:
            current_unix_time_reboot_list.append(time_utils.date_to_unix(reboot_time))

        logging.info(
            "[RESTARTS SENDER] Current unix time reboot list" + str(current_unix_time_reboot_list))

        # Here restarts are collected within 5hours up to now
        up_to_now_restarts = time_utils.get_unix_time_list_within_frame(
            current_unix_time_reboot_list, 5)

        logging.info(
            "[RESTARTS SENDER] Up to now  reboot list within 5 hour" + str(up_to_now_restarts))

        # Get list which contains restarts in up_to_now_restarts but not in already_known_restarts

        newly_captured_restarts = list_comparison(up_to_now_restarts, already_known_restarts)

        logging.info("[RESTARTS SENDER] Newly captured reboot list" + str(up_to_now_restarts))

        list_to_save_again = already_known_restarts + newly_captured_restarts

        with open(config.RESTART_DATA_PKL_FILE, "wb") as output_file:
            pickle.dump(list_to_save_again, output_file)

        readable_restarts_list = []

        # Convert time into human readable format
        if newly_captured_restarts:
            for unix_date in newly_captured_restarts:
                readable_restarts_list.append(str(unix_date) + ':' + restart_cause(unix_date))
        logging.info("[RESTARTS SENDER] Final Sending reboot list" + str(readable_restarts_list))
        return readable_restarts_list

    except Exception as exception:
        logging.exception("Error while gathering newly occured restarts: %s", exception)
        return config.ERROR_MESSAGE


def get_reboot_time():
    """
    Get last reboot time
    :return: time
    """
    try:
        command = "crontab -l | grep 'shutdown' | cut -d ' ' -f 1,2,3,4,5"
        logging.debug(command)
        reboot_time = sub_process.p_open_stripped(command)
        hour = reboot_time.split(' ')[1].rstrip()
        minute = reboot_time.split(' ')[0].rstrip()
        reboot_time_string = hour + ':' + minute
        return reboot_time_string
    except Exception as exception:
        logging.exception('Error while reboot time: %s', exception)
        return config.ERROR_MESSAGE
