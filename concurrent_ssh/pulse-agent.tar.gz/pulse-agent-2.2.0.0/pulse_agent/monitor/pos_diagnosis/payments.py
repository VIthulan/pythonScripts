"""
This module contains functions related to payments diagnosis
"""
import logging
import time
import json
import datetime
from pulse_agent.utils import sub_process
from pulse_agent.utils import log_utils
from pulse_agent.services.dtos.value_desc import ValueDesc
from pulse_agent.utils.config import config
from pulse_agent.utils.decorators.try_except import try_except
from pulse_agent.utils import json_utils


def check_swiper_connected():
    """
    # check whether swiper is connected
    :return:
    """
    try:
        command = "lsusb|grep -e 'MagTek' -e 'ID Tech'"
        logging.debug(command)
        is_swiper_connected = sub_process.p_open_stripped(command)
        logging.debug('Here is the first line: %s', is_swiper_connected)
        if is_swiper_connected == '':
            return ValueDesc(value=config.MESSAGE_CARD_READER_NOT_FOUND)

        return ValueDesc()
    except Exception as exception:
        logging.exception('Error while checking swiper connected: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def check_decrypt_error_within_current_hour():
    """
    check_decrypt_error_within_current_hour
    :return:
    """
    try:
        TOTAL_PAYMENTS_THRESHOLD = 10
        RATIO_THRESHOLD = 0.5
        unsuccess_ratio = 0

        success_payments_num = float(get_success_payments_within_current_hour())
        decrypt_error_payments_num = float(get_decrypt_error_payments_within_current_hour())

        total_payments_in_hour = success_payments_num + decrypt_error_payments_num

        if decrypt_error_payments_num != 0 and total_payments_in_hour != 0:
            unsuccess_ratio = decrypt_error_payments_num / total_payments_in_hour

        logging.info("total payments " + str(total_payments_in_hour))
        logging.warning("unsuccess ratio " + str(unsuccess_ratio))

        if total_payments_in_hour > TOTAL_PAYMENTS_THRESHOLD and unsuccess_ratio > RATIO_THRESHOLD:
            return ValueDesc(value=config.MESSAGE_PAYMENT_DECRYPT_ERROR)

        return ValueDesc()
    except Exception as exception:
        logging.exception('Error checking decrypt error payments within current hour: %s',
                          exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def get_success_payments_within_current_hour():
    """
    get_success_payments_within_current_hour
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'AS2'|grep -c 'success=.true.'")
        logging.debug(command)
        success_payment_count_this_hour = sub_process.p_open_stripped(command)
        logging.info(success_payment_count_this_hour)
        return success_payment_count_this_hour
    except Exception as exception:
        logging.exception('Error getting success payments within current hour: %s', exception)
        return "ERROR"


def get_decrypt_error_payments_within_current_hour():
    """
    get_decrypt_error_payments_within_current_hour
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'AS2'|grep 'success=.false.'|grep -c 'Track data could not be decrypted'")
        logging.debug(command)
        decrypt_error_count_this_hour = sub_process.p_open_stripped(command)
        logging.warning(decrypt_error_count_this_hour)
        return decrypt_error_count_this_hour
    except Exception as exception:
        logging.exception('Error getting decrypt error payments within current hour: %s', exception)
        return "ERROR"


def fetch_msr_related_issues():
    """
    fetch_msr_related_issues
    :return:
    """
    try:
        descriptions = []

        authorization_network_error = check_authorizing_declined_transactions()
        if authorization_network_error != '':
            descriptions.append(
                create_payment_error_desc_obj(config.AUTHORIZING_NETWORK_DECLINED_THE_TRANSACTION,
                                              "20007", authorization_network_error))

        msr_is_not_swiping_cards_error = check_msr_swipings()
        if msr_is_not_swiping_cards_error != '':
            descriptions.append(
                create_payment_error_desc_obj(config.MSR_IS_NOT_SWIPING_CARDS, "20134",
                                              msr_is_not_swiping_cards_error))

        ksn_has_incorrect_format_error = check_ksn_format()
        if ksn_has_incorrect_format_error != '':
            descriptions.append(
                create_payment_error_desc_obj(config.KSN_HAS_INCORRECT_FORMAT, "21186",
                                              ksn_has_incorrect_format_error))

        msr_set_bad_data_error = check_msr_bad_data()
        if msr_set_bad_data_error != '':
            descriptions.append(create_payment_error_desc_obj(config.MSR_SENDS_BAD_DATA, "21514",
                                                              msr_set_bad_data_error))

        msr_burned_error = check_whether_burned_msr()
        if msr_burned_error != '':
            descriptions.append(
                create_payment_error_desc_obj(config.BURNED_MSR, "", msr_burned_error))

        msr_or_cable_broken_error = check_msr_damage()
        if msr_or_cable_broken_error != '':
            descriptions.append(
                create_payment_error_desc_obj(config.MSR_IS_BURNED_OR_CABLE_MAY_BE_BROKEN,
                                              "LIBUSB_ERROR_TIMEOUT", msr_or_cable_broken_error))

        ksn_validation_issue_error = check_ksn_validation_issues()
        if ksn_validation_issue_error != '':
            descriptions.append(create_payment_error_desc_obj(config.KSN_INVALID_, "KSN INVALID",
                                                              ksn_validation_issue_error))

        if not descriptions:
            return ValueDesc()

        return ValueDesc(value=config.MSR_ISSUE_DETECTED, desc=json.dumps(descriptions))

    except Exception as exception:
        logging.exception('Error fetching msr related issues: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def check_authorizing_declined_transactions():
    """
    # Authorizing network declined the transaction
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'ErrorCode.code: 20007 ErrorCode.message: "
                   "Authorizing network declined the transaction'")
        logging.debug(command)
        authorizing_network_declined_transaction_error_this_hour = sub_process.p_open_stripped(
            command)
        logging.debug(authorizing_network_declined_transaction_error_this_hour)
        return authorizing_network_declined_transaction_error_this_hour
    except Exception as exception:
        logging.exception(
            'Error getting authorizing network declined the transaction within current hour: %s',
            exception)
        return "ERROR"


def create_payment_error_desc_obj(title, code, desc):
    """
    create_payment_error_desc_obj
    :param title: title
    :param code: code
    :param desc: desc
    :return:
    """

    return {"TITLE": title, "CODE": code, "DESCRIPTION": desc}


def check_msr_swipings():
    """
    # MSR is not swiping cards
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'ErrorCode.code: 20134 ErrorCode.message: Card reader not found'")
        logging.debug(command)
        msr_is_not_swiping_cards_this_hour = sub_process.p_open_stripped(command)
        logging.debug(msr_is_not_swiping_cards_this_hour)
        return msr_is_not_swiping_cards_this_hour
    except Exception as exception:
        logging.exception('Error getting MSR is not swiping cards: %s', exception)
        return "ERROR"


def check_ksn_format():
    """
    # KSN has incorrect format
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'ErrorCode.code: 21186 ErrorCode.message: KSN has incorrect format'")
        logging.debug(command)
        ksn_has_incorrect_format_this_hour = sub_process.p_open_stripped(command)
        logging.debug(ksn_has_incorrect_format_this_hour)
        return ksn_has_incorrect_format_this_hour
    except Exception as exception:
        logging.exception('Error getting KSN has incorrect format: %s', exception)
        return "ERROR"


def check_whether_burned_msr():
    """
    # Burned MSR
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'ErrorCode.code: n/a ErrorCode.message: device not detected'")
        logging.debug(command)
        burned_msr_this_hour = sub_process.p_open_stripped(command)
        logging.debug(burned_msr_this_hour)
        return burned_msr_this_hour
    except Exception as exception:
        logging.exception('Error getting burned MSR: %s', exception)
        return "ERROR"


def check_msr_damage():
    """
    # MSR is burned or cable may be broken.
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'UsbCardReader:onCardSwipeError "
                   "com.leapset.usb.driver.UsbAccessException: LIBUSB_ERROR_TIMEOUT'")
        logging.debug(command)
        msr_is_burned_or_cable_may_be_broken_this_hour = sub_process.p_open_stripped(command)
        logging.debug(msr_is_burned_or_cable_may_be_broken_this_hour)
        return msr_is_burned_or_cable_may_be_broken_this_hour
    except Exception as exception:
        logging.exception('Error getting MSR is burned or cable may be broken: %s', exception)
        return "ERROR"


def check_ksn_validation_issues():
    """
    # KSN validation issues
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "| grep -A 1 '\[KSN INVALID\]'")
        logging.debug(command)
        ksn_invalid = sub_process.p_open_stripped(command)
        logging.debug(ksn_invalid)
        return ksn_invalid
    except Exception as exception:
        logging.exception('Error getting MSR is burned or cable may be broken: %s', exception)
        return "ERROR"


def check_msr_bad_data():
    """
    # MSR sends bad data
    :return:
    """
    try:
        current_hour = time.strftime("%Y-%m-%d %H")
        command = ("grep '" + current_hour + "' " + config.PAYMENTS_LOG_PATH +
                   "|grep 'ErrorCode.code: 21514 ErrorCode.message: Card swipe failed. "
                   "Please key in the card details'")
        logging.debug(command)
        msr_sends_bad_data_this_hour = sub_process.p_open_stripped(command)
        logging.debug(msr_sends_bad_data_this_hour)
        return msr_sends_bad_data_this_hour
    except Exception as exception:
        logging.exception('Error getting MSR sends bad data: %s', exception)
        return "ERROR"


def get_swipe_status_within_today():
    """
    # get swipes and who did them
    :return:
    """
    try:
        today = datetime.date.today()
        success_swipes = get_successful_swipes(today)
        bad_swipes = get_bad_swipes(today)
        manual_swipes = get_manual_swipes(today)

        data = dict(
            SUCCESS=process_swipes_to_item_count_form(success_swipes),
            BAD=process_swipes_to_item_count_form(bad_swipes),
            MANUAL=process_swipes_to_item_count_form(manual_swipes)
        )
        return data
    except Exception as exception:
        logging.exception('Error while getting swipe status: %s', exception)
        return "ERROR"


def get_successful_swipes(today):
    """
    # get successful swipes
    :param today: datetime
    :return:
    """
    try:
        date_emp_array = []
        command = "grep -a -i -e 'Charge from swiped credit card was successful' %s |  grep -a -e %s | " \
                  "cut -d ' ' -f 1,2,3" % (config.PAYMENTS_LOG_PATH, str(today))
        logging.debug(command)
        grep_result = sub_process.p_open_stripped(command).splitlines()
        for keyword in grep_result:
            date_part = keyword.split(',')[0]
            employee_part = keyword.split(',')[1].split(' ')[1].split(']')[0][1:]
            date_emp_array.append(date_part + ';' + employee_part)
        return date_emp_array
    except Exception as exception:
        logging.exception('Error while getting successful swipes: %s', exception)
        return []


def get_bad_swipes(today):
    """
    # get bad swipes
    :param today: datetime
    :return:
    """
    try:
        yesterday = today - datetime.timedelta(1)
        date_emp_array = []
        command = "zgrep --no-filename -a -e 'Bad swipe' %s | grep -a -e %s | cut -d ',' -f 1" % \
                  (config.MOXY_LOG_FILES, str(today))
        bad_swipes = sub_process.p_open_stripped(command).splitlines()

        command = "zgrep --no-filename -a -E 'Authentication for the user .+ was successful' %s | egrep -a -e '(%s|%s)'" % \
                  (config.MOXY_LOG_FILES, str(today), str(yesterday))
        employee_logins = sub_process.p_open_stripped(command).splitlines()

        if len(employee_logins) > 0:
            iterator = 0
            employee_login = employee_logins[iterator]
            login_time = datetime.datetime.strptime(employee_login.split(',')[0],
                                                    "%Y-%m-%d %H:%M:%S")

            for bad_swipe in bad_swipes:
                bad_swipe_time = datetime.datetime.strptime(bad_swipe, "%Y-%m-%d %H:%M:%S")

                if login_time > bad_swipe_time:
                    date_emp_array.append(str(bad_swipe_time) + ';' +
                                          employee_logins[iterator - 1].split(',')[1].split('.')[
                                              5].split(' ')[4])

                else:
                    while login_time < bad_swipe_time and iterator < len(employee_logins) - 1:
                        iterator += 1
                        employee_login = employee_logins[iterator]
                        login_time = datetime.datetime.strptime(employee_login.split(',')[0],
                                                                "%Y-%m-%d %H:%M:%S")

                    date_emp_array.append(str(bad_swipe_time) + ';' +
                                          employee_logins[iterator - 1].split(',')[1].split('.')[
                                              5].split(' ')[4])
        return date_emp_array
    except Exception as exception:
        logging.exception('Error while getting bad swipes: %s', exception)
        return []


def get_manual_swipes(today):
    """
    # get manual swipes
    :param today: datetime
    :return:
    """
    try:
        date_emp_array = []
        command = "grep -a -e 'AM2' %s | grep -e %s | cut -d ' ' -f 1,2,3" % (
            config.PAYMENTS_LOG_PATH, str(today))
        logging.debug(command)
        grep_result = sub_process.p_open_stripped(command).splitlines()
        for keyword in grep_result:
            date_part = keyword.split(',')[0]
            employee_part = keyword.split(',')[1].split(' ')[1].split(']')[0][1:]
            date_emp_array.append(date_part + ';' + employee_part)
        return date_emp_array
    except Exception as exception:
        logging.exception('Error while getting manual swipes: %s', exception)
        return []


def process_swipes_to_item_count_form(swipes_list):
    """
    # Get swipes count against employee
    :param swipes_list:
    :return:
    """
    processed_list = []
    for i in range(0, len(swipes_list)):
        processed_list.append(swipes_list[i].split(';')[1])
    return dict((x, processed_list.count(x)) for x in set(processed_list))


def get_close_cash_timestamp_list_today():
    """
    # get close cash time stamps
    :return:
    """
    try:
        today_date = time.strftime("%Y-%m-%d")
        command = ("grep " + today_date + " " + config.PAYMENTS_LOG_PATH +
                   "|grep 'Close cash batch success after retrying'"
                   "|cut -d ' ' -f 1,2|cut -d ',' -f 1")
        logging.debug(command)
        close_cash_list = sub_process.p_open_stripped(command).splitlines()
        return close_cash_list
    except Exception as exception:
        logging.exception('Error while getting closed cash timestamp list: %s', exception)
        return "ERROR"


@try_except(level='exception', default="NULL")
def get_average_transaction_time():
    """
    Get average transaction time of payments
    :return: Average transaction time if available else NULL
    """
    yesterday = (datetime.date.today() - datetime.timedelta(1)).strftime('%Y-%m-%d')
    yesterday_logs_grep = 'grep "%s" %s | grep "\[AS" ' % (yesterday, config.PAYMENTS_LOG_PATH)
    logging.debug(yesterday_logs_grep)
    logs = sub_process.p_open(yesterday_logs_grep).stdout.read().splitlines()

    aggregated_time = []
    as1_log_time = None
    for log_line in logs:
        log_time = " ".join(log_line.split(' ', 2)[:2])
        unix_log_time = time.mktime(
            datetime.datetime.strptime(log_time, "%Y-%m-%d %H:%M:%S,%f").timetuple())
        if '[AS1]' in log_line:
            as1_log_time = unix_log_time
            continue

        if as1_log_time is not None and ('[AS2]' in log_line or '[AS3]' in log_line):
            aggregated_time.append(unix_log_time - as1_log_time)
            as1_log_time = None
    if aggregated_time:
        logging.debug('Payment transaction time aggregation: %s', aggregated_time)
        average_time = reduce(lambda x, y: x + y, aggregated_time) / len(aggregated_time)
        logging.debug('Average transaction time : %s', average_time)
        return average_time
    return "NULL"


@try_except(level='exception', default=[])
def get_payment_cube_failure_data():
    """
    Get payment cube failure data
    :return: Array with message
    """
    failure_data = []
    yesterday = (datetime.date.today() - datetime.timedelta(1)).strftime('%Y-%m-%d')
    unexpected_failure_logs = log_utils.grep_switch_logs(config.CPM_ALL_LOGS_PATH, 'PAYMENT',
                                                         '20000',
                                                         date=yesterday)
    unexpected_failures = log_utils.get_switch_message(unexpected_failure_logs,
                                                       '[PULSE][PAYMENT][20000]')
    if unexpected_failures:
        failure_data.append({'Issue': 'Unexpected Failure Payment', 'Message': unexpected_failures})

    sign_in_logs = log_utils.grep_switch_logs(config.CPM_ALL_LOGS_PATH, 'SIGN', '20000',
                                              date=yesterday)
    sign_in_messages = log_utils.get_switch_message(sign_in_logs,
                                                    '[PULSE][SIGN][20000]')
    if sign_in_messages:
        failure_data.append({'Issue': 'SignIn', 'Message': sign_in_messages})

    gift_card_problems = log_utils.grep_switch_logs(config.CPM_ALL_LOGS_PATH, 'GIFT', '20000',
                                                    date=yesterday)
    gift_card_message = log_utils.get_switch_message(gift_card_problems,
                                                     '[PULSE][GIFT][20000]')

    if gift_card_message:
        failure_data.append({'Issue': 'GiftCard', 'Message': gift_card_message})

    logging.debug('Payment cube failure data: %s', json_utils.get_json_dump(failure_data))

    return failure_data


@try_except(level='exception', default=[])
def get_cpm_bad_swipes():
    """
    Get cpm bad swipes data
    :return: Array of messages
    """
    failure_data = []
    yesterday = (datetime.date.today() - datetime.timedelta(1)).strftime('%Y-%m-%d')

    payment_error = log_utils.grep_switch_logs(config.CPM_ALL_LOGS_PATH, 'PAYMENT',
                                               '20097',
                                               date=yesterday)
    payment_failures = log_utils.get_switch_message(payment_error,
                                                    '[PULSE][PAYMENT][20097]')
    if payment_failures:
        failure_data.append({'Issue': 'Payment bad swipe', 'Message': payment_failures})

    sign_in_logs = log_utils.grep_switch_logs(config.CPM_ALL_LOGS_PATH, 'SIGN', '20097',
                                              date=yesterday)
    sign_in_messages = log_utils.get_switch_message(sign_in_logs,
                                                    '[PULSE][SIGN][20097]')
    if sign_in_messages:
        failure_data.append({'Issue': 'SignIn bad swipe', 'Message': sign_in_messages})

    gift_card_problems = log_utils.grep_switch_logs(config.CPM_ALL_LOGS_PATH, 'GIFT', '20097',
                                                    date=yesterday)
    gift_card_message = log_utils.get_switch_message(gift_card_problems,
                                                     '[PULSE][GIFT][20097]')

    if gift_card_message:
        failure_data.append({'Issue': 'GiftCard bad swipe', 'Message': gift_card_message})

    logging.debug('CPM Bad swipe data: %s', json_utils.get_json_dump(failure_data))

    return failure_data


@try_except(level='exception', default=[])
def get_device_connection_logs():
    connection_data = []

    yesterday = (datetime.date.today() - datetime.timedelta(1)).strftime('%Y-%m-%d')

    device_connection_logs = log_utils.grep_switch_logs(config.DM_DEVICES_LOG, 'DEVICE',
                                                        date=yesterday)
    for log_line in device_connection_logs:
        if '[CONNECT]' in log_line:
            connection_data.append(log_line)

    return connection_data
