"""
tests for payments module
"""
# core modules
import logging
import mock
import datetime

# testing module
from pulse_agent.monitor.pos_diagnosis import payments

logging.basicConfig(level=logging.INFO)


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_bad_swipes(mock_p_open_stripped):
    """
    test get_bad_swipes()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    today_date = datetime.date.today()
    # checks whether it works as expected if there are multiple operator logins
    employee_logins = '2017-11-18 11:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Nathan  at Thu Sep 21 11:42:20 EDT 2017 was successful' \
                      '\n2017-11-18 12:44:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Lyon  at Thu Sep 21 12:42:20 EDT 2017 was successful' \
                      '\n2017-11-18 14:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Starc  at Thu Sep 21 14:42:20 EDT 2017 was successful'
    bad_swipes = '2017-11-18 11:44:14' \
                 '\n2017-11-18 12:34:56' \
                 '\n2017-11-18 12:50:14' \
                 '\n2017-11-18 13:34:56'
    mock_p_open_stripped.side_effect = [bad_swipes, employee_logins]
    assert payments.get_bad_swipes(today_date) == ['2017-11-18 11:44:14;Nathan', '2017-11-18 12:34:56;Nathan', '2017-11-18 12:50:14;Lyon', '2017-11-18 13:34:56;Lyon']

    employee_logins = '2017-11-18 11:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Nathan  at Thu Sep 21 11:42:20 EDT 2017 was successful' \
                      '\n2017-11-18 12:44:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Lyon  at Thu Sep 21 12:42:20 EDT 2017 was successful' \
                      '\n2017-11-18 14:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Starc  at Thu Sep 21 14:42:20 EDT 2017 was successful' \
                      '\n2017-11-18 16:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Starc  at Thu Sep 21 14:42:20 EDT 2017 was successful'
    bad_swipes = '2017-11-18 11:44:14' \
                 '\n2017-11-18 12:34:56' \
                 '\n2017-11-18 12:50:14' \
                 '\n2017-11-18 13:34:56'
    mock_p_open_stripped.side_effect = [bad_swipes, employee_logins]
    assert payments.get_bad_swipes(today_date) == ['2017-11-18 11:44:14;Nathan', '2017-11-18 12:34:56;Nathan', '2017-11-18 12:50:14;Lyon',
                                                   '2017-11-18 13:34:56;Lyon']

    # checks whether it works as expected if there is only a single employee login
    employee_logins = '2017-11-18 14:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Nathan  at Thu Sep 21 11:42:20 EDT 2017 was successful'

    bad_swipes = '2017-11-18 11:44:14' \
                 '\n2017-11-18 12:34:56' \
                 '\n2017-11-18 12:50:14' \
                 '\n2017-11-18 13:34:56'
    mock_p_open_stripped.side_effect = [bad_swipes, employee_logins]
    assert payments.get_bad_swipes(today_date) == ['2017-11-18 11:44:14;Nathan', '2017-11-18 12:34:56;Nathan', '2017-11-18 12:50:14;Nathan',
                                                   '2017-11-18 13:34:56;Nathan']

    employee_logins = '2017-11-18 11:40:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Nathan  at Thu Sep 21 11:40:20 EDT 2017 was successful' \
                      '\n2017-11-18 11:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Nathan  at Thu Sep 21 12:43:20 EDT 2017 was successful'
    bad_swipes = '2017-11-18 11:44:14' \
                 '\n2017-11-18 12:34:56' \
                 '\n2017-11-18 12:50:14' \
                 '\n2017-11-18 13:34:56'
    mock_p_open_stripped.side_effect = [bad_swipes, employee_logins]
    assert payments.get_bad_swipes(today_date) == ['2017-11-18 11:44:14;Nathan', '2017-11-18 12:34:56;Nathan',
                                                   '2017-11-18 12:50:14;Nathan', '2017-11-18 13:34:56;Nathan']

    # check whether it handles empty employee logins
    employee_logins = ''

    bad_swipes = '2017-11-18 11:44:14' \
                 '\n2017-11-18 12:34:56' \
                 '\n2017-11-18 12:50:14' \
                 '\n2017-11-18 13:34:56'
    mock_p_open_stripped.side_effect = [bad_swipes, employee_logins]
    assert payments.get_bad_swipes(today_date) == []

    # check whether it handles empty bad swipes
    employee_logins = '2017-11-18 14:42:20,598 -qtp1556956098-73--INFO -com.leapset.tiny.web.filters.AuthenticationFilter:Authentication for the user Nathan  at Thu Sep 21 11:42:20 EDT 2017 was successful'

    bad_swipes = ''
    mock_p_open_stripped.side_effect = [bad_swipes, employee_logins]
    assert payments.get_bad_swipes(today_date) == []

    # check whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert payments.get_bad_swipes(today_date) == []

