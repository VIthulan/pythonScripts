"""
Test cases for Pos_diagnosis module
"""

# core modules
import logging
import time
import mock
from mock import Mock

# configs
from pulse_agent.utils.config import config
from pulse_agent.monitor.pos_diagnosis.dtos import ValueDesc

# testing module
from pulse_agent.monitor.pos_diagnosis import pos_diagnosis

logging.basicConfig(level=logging.FATAL)


def setup_module(mdl):
    """ setup_module """
    log = logging.getLogger('setup_module')
    log.debug("setup_module module:%s", mdl.__name__)


def teardown_module(mdl):
    """ teardown_module """
    log = logging.getLogger('teardown_module')
    log.debug("teardown_module module:%s", mdl.__name__)


def setup_function(func):
    """ setup_function """
    logging.info("setup_function function:%s", func.__name__)


def teardown_function(func):
    """ teardown_function """
    log = logging.getLogger('teardown_function')
    log.debug("teardown_function function:%s", func.__name__)


def assert_received_and_expected(received, expected):
    """ assert_received_and_expected """
    assert received.VALUE == expected.VALUE
    assert received.DESCRIPTION == expected.DESCRIPTION
    assert received.DATE_TIME == expected.DATE_TIME


def side_effect_check_xrog_crashes_reboot(day='today'):
    """ side_effect_check_xrog_crashes_reboot """
    res = {'today': ['crash-1', 'crash-2', 'crash-3'],
           'yesterday': ['crash-4:@ september 28 2017', 'crash-5', 'crash-6']}
    return res[day]


def side_effect_check_xrog_crashes_on_demand(day='today'):
    """ side_effect_check_xrog_crashes_on_demand """
    res = {'today': ['crash-1:@ september 28 2017', 'crash-2', 'crash-3'],
           'yesterday': ['crash-4:@ september 28 2017', 'crash-5', 'crash-6']}
    return res[day]


def side_effect_check_syslog_hd_status_for_day(checking_day='today'):
    """ side_effect_check_syslog_hd_status_for_day """
    res = {'today': ['syslog-1', 'syslog-2', 'syslog-3'],
           'yesterday': ['syslog-4:@ september 30 2017', 'syslog-5', 'syslog-6']}
    return res[checking_day]


def side_effect_check_syslog_hd_status_for_day_on_demand(checking_day='today'):
    """ side_effect_check_syslog_hd_status_for_day_on_demand """
    res = {'today': ['syslog-1:@ september 30 2017', 'syslog-2', 'syslog-3'],
           'yesterday': ['syslog-4:@ september 30 2017', 'syslog-5', 'syslog-6']}
    return res[checking_day]


def side_effect_check_xrog_crashes_empty(day):
    """ side_effect_check_xrog_crashes_empty """
    res = {'today': [],
           'yesterday': []}
    return res[day]


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_xrog_crashes_given_day(mock_p_open_stripped):
    """ Test cases for check_xrog_crashes_given_day """

    grep_month_read = Mock(return_value='September\n')
    grep_month_stdout = Mock(read=grep_month_read)
    grep_month = Mock(stdout=grep_month_stdout)

    grep_day_read = Mock(return_value='30\n')
    grep_day_stdout = Mock(read=grep_day_read)
    grep_day = Mock(stdout=grep_day_stdout)

    xorg_crashes_read = Mock(return_value='crash-1\ncrash-2\ncrash-3')
    xorg_crashes_stdout = Mock(read=xorg_crashes_read)
    xorg_crashes = Mock(stdout=xorg_crashes_stdout)

    expected_calls = [
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"')
    ]
    # check whether it works as expected for today
    mock_p_open_stripped.side_effect = [grep_month, grep_day, xorg_crashes]
    pos_diagnosis.check_xrog_crashes_given_day()
    assert mock_p_open_stripped.mock_calls == expected_calls

    # check whether it works as expected for yesterday
    expected_calls = [
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('date --date="1 days ago" +"%b"'),
        mock.call('date --date="1 days ago" +"%-d"')
    ]
    mock_p_open_stripped.side_effect = [grep_month, grep_day, xorg_crashes]
    pos_diagnosis.check_xrog_crashes_given_day('yesterday')
    assert mock_p_open_stripped.mock_calls == expected_calls

    # check whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert pos_diagnosis.check_xrog_crashes_given_day() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.monitor.pos_diagnosis.pos_diagnosis.check_xrog_crashes_given_day')
def test_check_Xrog_crashes(mock_check_xrog_crashes_given_day):
    """ Test cases for check_Xrog_crashes """

    # checks whether it works as expected if it handles error message from
    # check_Xrog_crashes_for_today() & check_Xrog_crashes_for_yesterday()
    mock_check_xrog_crashes_given_day.return_value = config.ERROR_MESSAGE
    assert pos_diagnosis.check_xrog_crashes('on-demand') == config.ERROR_MESSAGE

    # checks whether it works as expected if its been called due to an on-demand request
    mock_check_xrog_crashes_given_day.side_effect = side_effect_check_xrog_crashes_on_demand

    xorg_crashes = pos_diagnosis.check_xrog_crashes('on-demand')
    assert_received_and_expected(xorg_crashes,
                                 ValueDesc(value=config.MESSAGE_XORG_TAINTED,
                                           desc='crash-1:@ september 28 2017',
                                           date=':@ september 28'))

    # checks whether it works as expected if its been called due to a reboot
    mock_check_xrog_crashes_given_day.side_effect = side_effect_check_xrog_crashes_reboot
    xorg_crashes = pos_diagnosis.check_xrog_crashes('reboot')
    assert_received_and_expected(xorg_crashes,
                                 ValueDesc(value=config.MESSAGE_XORG_TAINTED,
                                           desc='crash-4:@ september 28 2017',
                                           date=':@ september 28'))

    # checks whether it works as expected if it handles empty results
    # from check_Xrog_crashes_for_today() & check_Xrog_crashes_for_yesterday()
    mock_check_xrog_crashes_given_day.side_effect = side_effect_check_xrog_crashes_empty
    xorg_crashes = pos_diagnosis.check_xrog_crashes('on-demand')
    assert_received_and_expected(xorg_crashes,
                                 ValueDesc())

    # check whether it handles exceptions properly
    mock_check_xrog_crashes_given_day.side_effect = Exception
    xorg_crashes = pos_diagnosis.check_xrog_crashes('on-demand')
    assert_received_and_expected(xorg_crashes,
                                 ValueDesc(value=config.ERROR_MESSAGE,
                                           desc='',
                                           date=None))


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_touch_fixes(mock_p_open_stripped):
    """ Test cases for check_touch_fixes """

    touch_fixes_read = Mock(return_value='')
    touch_fixes_stdout = Mock(read=touch_fixes_read)
    touch_fixes = Mock(stdout=touch_fixes_stdout)

    expected_calls = [
        mock.call("dpkg -s lp-touch 2>&1 | grep 'ok installed'")
    ]

    # check whether it works as expected if touch fixes have not been applied
    mock_p_open_stripped.return_value = ''
    check_touch_fixes = pos_diagnosis.check_touch_fixes()
    assert_received_and_expected(check_touch_fixes,
                                 ValueDesc(value=config.MESSAGE_TOUCH_FIXES_NOT_APPLIED))
    assert mock_p_open_stripped.mock_calls == expected_calls

    # check whether it works as expected if touch fixes have been applied
    mock_p_open_stripped.return_value = 'touch fixes not installed'
    check_touch_fixes = pos_diagnosis.check_touch_fixes()
    assert_received_and_expected(check_touch_fixes,
                                 ValueDesc())

    # check whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    check_touch_fixes = pos_diagnosis.check_touch_fixes()
    assert_received_and_expected(check_touch_fixes,
                                 ValueDesc(value=config.ERROR_MESSAGE))


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_touch_drivers(mock_p_open_stripped):
    """ Test cases for check_touch_drivers """

    # check whether it works as expected if touch river configuration error is not available
    mock_p_open_stripped.return_value = ''

    touch_drivers = pos_diagnosis.check_touch_drivers()
    assert_received_and_expected(touch_drivers,
                                 ValueDesc())

    # check whether it works as expected if touch river configuration error is not available
    mock_p_open_stripped.return_value = 'Touch driver configuration error'

    touch_drivers = pos_diagnosis.check_touch_drivers()
    assert_received_and_expected(touch_drivers,
                                 ValueDesc(
                                     value=config.MESSAGE_TOUCH_DRIVER_CONFIG_ERROR,
                                     desc='Touch driver configuration error',
                                     date=time.strftime("%a, %d %b %Y")))

    # check whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    touch_drivers = pos_diagnosis.check_touch_drivers()
    assert_received_and_expected(touch_drivers,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE))


@mock.patch('subprocess.Popen')
@mock.patch('pulse_agent.monitor.pos_diagnosis.pos_diagnosis.is_having_bad_sector')
def test_check_hard_disk_bad_sectors(mock_is_having_bad_sector, mock_popen):
    """ Test cases for check_hard_disk_bad_sectors """

    mock_is_having_bad_sector.return_value = True

    smartmon_enabled_read = Mock(return_value='smartmontool is installed')
    smartmon_enabled_stdout = Mock(read=smartmon_enabled_read)
    smartmon_enabled = Mock(stdout=smartmon_enabled_stdout)

    hd_bad_sectors_read = Mock(return_value='bad-sector-1\nbad-sector-2\nbad-sector-3')
    hd_bad_sectors_stdout = Mock(read=hd_bad_sectors_read)
    hd_bad_sectors = Mock(stdout=hd_bad_sectors_stdout)

    expected_calls = [
        mock.call("dpkg --get-selections| grep 'smartmontools'", stdout=mock.ANY, shell=mock.ANY),
        mock.call(
            "smartctl -A /dev/sda | grep -e 'Current_Pending_Sector' -e 'Offline_Uncorrectable'"
            " -e 'Reallocated_Sector_Ct'| awk '{print $2\";\"$4\";\"$5\";\"$6\";\"$7\";\"$10}'",
            stdout=mock.ANY, shell=mock.ANY)
    ]
    # check whether it works as expected if smartmon is installed
    mock_popen.side_effect = [smartmon_enabled, hd_bad_sectors]
    bad_sectors = pos_diagnosis.check_hard_disk_bad_sectors()
    assert_received_and_expected(bad_sectors,
                                 ValueDesc(
                                     value=config.MESSAGE_HD_FAILURES_FOUND,
                                     desc='bad-sector-1  bad-sector-2  bad-sector-3  '
                                 ))
    assert mock_popen.mock_calls == expected_calls

    # check whether it works as expected if no bad sectors are available
    mock_is_having_bad_sector.return_value = False
    mock_popen.side_effect = [smartmon_enabled, hd_bad_sectors]
    bad_sectors = pos_diagnosis.check_hard_disk_bad_sectors()
    assert_received_and_expected(bad_sectors,
                                 ValueDesc(
                                     desc='bad-sector-1  bad-sector-2  bad-sector-3  '
                                 ))

    # check whether it works as expected if smartmon is not installed
    smartmon_enabled_read = Mock(return_value='')
    smartmon_enabled_stdout = Mock(read=smartmon_enabled_read)
    smartmon_enabled = Mock(stdout=smartmon_enabled_stdout)

    mock_popen.side_effect = [smartmon_enabled, hd_bad_sectors]
    bad_sectors = pos_diagnosis.check_hard_disk_bad_sectors()
    assert_received_and_expected(bad_sectors,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE
                                 ))

    # check whether it handles exceptions properly
    mock_popen.side_effect = Exception
    bad_sectors = pos_diagnosis.check_hard_disk_bad_sectors()
    assert_received_and_expected(bad_sectors,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE
                                 ))


@mock.patch('subprocess.Popen')
def test_get_smartctl_self_assessment(mock_popen):
    """ Test cases for get_smartctl_self_assessment """

    smartctl_self_assessment_read = Mock(return_value='PASSED')
    smartctl_self_assessment_stdout = Mock(read=smartctl_self_assessment_read)
    smartctl_self_assessment = Mock(stdout=smartctl_self_assessment_stdout)

    expected_calls = [
        mock.call("smartctl -H /dev/sda | "
                  "grep 'SMART overall-health self-assessment test result'|cut -d ':' -f 2",
                  stdout=mock.ANY, shell=mock.ANY),
    ]

    # check whether it works as expected if self assesment is PASSED
    mock_popen.side_effect = [smartctl_self_assessment]
    smartctl_result = pos_diagnosis.get_smartctl_self_assessment()
    assert_received_and_expected(smartctl_result,
                                 ValueDesc())
    assert mock_popen.mock_calls == expected_calls

    smartctl_self_assessment_read = Mock(return_value='FAILED!')
    smartctl_self_assessment_stdout = Mock(read=smartctl_self_assessment_read)
    smartctl_self_assessment = Mock(stdout=smartctl_self_assessment_stdout)

    # check whether it works as expected if self assesment is FAILED
    mock_popen.side_effect = [smartctl_self_assessment]
    smartctl_result = pos_diagnosis.get_smartctl_self_assessment()
    assert_received_and_expected(smartctl_result,
                                 ValueDesc(
                                     value=config.MESSAGE_SAMRTMON_SELF_ASSESSMENT_FAILED,
                                     desc='SMART overall-health self-assessment test result : FAILED!'
                                 ))

    smartctl_self_assessment_read = Mock(return_value='ERROR')
    smartctl_self_assessment_stdout = Mock(read=smartctl_self_assessment_read)
    smartctl_self_assessment = Mock(stdout=smartctl_self_assessment_stdout)

    # check whether it works as expected if self assesment is some thing else
    mock_popen.side_effect = [smartctl_self_assessment]
    smartctl_result = pos_diagnosis.get_smartctl_self_assessment()
    assert_received_and_expected(smartctl_result,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE
                                 ))

    # check whether it handles exceptions properly
    mock_popen.side_effect = Exception
    smartctl_result = pos_diagnosis.get_smartctl_self_assessment()
    assert_received_and_expected(smartctl_result,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE
                                 ))


@mock.patch('time.strftime')
@mock.patch('os.path.exists')
@mock.patch('subprocess.Popen')
def test_check_eth0_connectivity(mock_popen, mock_path_exists, mock_time):
    """ Test cases for check_eth0_connectivity """

    eth0_read = Mock(return_value='down')
    eth0_stdout = Mock(read=eth0_read)
    eth0 = Mock(stdout=eth0_stdout)

    moxy_err_read = Mock(return_value='err-1\nerr-2')
    moxy_err_stdout = Mock(read=moxy_err_read)
    moxy_err = Mock(stdout=moxy_err_stdout)

    mock_time.return_value = '2017-10-13'
    mock_path_exists.return_value = False

    # checks whether it works as expected if eth0 file isn't available
    results = pos_diagnosis.check_eth0_connectivity()
    assert_received_and_expected(results,
                                 ValueDesc(
                                     value=config.ETH_0_NOT_AVAILABLE
                                 ))

    # check whether it works as expected if eth0 interface is down
    mock_path_exists.return_value = True
    mock_popen.side_effect = [eth0, moxy_err]
    results = pos_diagnosis.check_eth0_connectivity()
    assert_received_and_expected(results,
                                 ValueDesc(
                                     value=config.ETH_0_NOT_AVAILABLE
                                 ))

    # check whether it works as expected if eth0 interface is up and moxy err exists
    eth0_read = Mock(return_value='up')
    eth0_stdout = Mock(read=eth0_read)
    eth0 = Mock(stdout=eth0_stdout)

    mock_popen.side_effect = [eth0, moxy_err]
    results = pos_diagnosis.check_eth0_connectivity()
    assert_received_and_expected(results,
                                 ValueDesc(
                                     value=config.ETH_0_NOT_AVAILABLE
                                 ))

    # check whether it works as expected if eth0 interface is up and moxy err doesn't exists
    moxy_err_read = Mock(return_value='')
    moxy_err_stdout = Mock(read=moxy_err_read)
    moxy_err = Mock(stdout=moxy_err_stdout)

    mock_popen.side_effect = [eth0, moxy_err]
    results = pos_diagnosis.check_eth0_connectivity()
    assert_received_and_expected(results,
                                 ValueDesc())

    # chech whether it handles exceptions properly
    mock_path_exists.side_effect = Exception
    results = pos_diagnosis.check_eth0_connectivity()
    assert_received_and_expected(results,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE))


@mock.patch('pulse_agent.monitor.pos_diagnosis.pos_diagnosis.check_syslog_hd_status_for_day')
def test_check_syslog_hd_status(mock_check_syslog_hd_status_for_day):
    """ Test cases for check_syslog_hd_status """

    # checks whether it works as expected if it has been called due to a reboot
    mock_check_syslog_hd_status_for_day.side_effect = side_effect_check_syslog_hd_status_for_day

    syslog_hd_status = pos_diagnosis.check_syslog_hd_status('reboot')
    assert_received_and_expected(syslog_hd_status,
                                 ValueDesc(value=config.MESSAGE_KERNEL_DISK_READ_FAILURES_FOUND,
                                           desc='syslog-4:@ september 30 2017',
                                           date=':@ september 30'))

    # checks whether it works as expected if it has been called as an on-demand action
    mock_check_syslog_hd_status_for_day.side_effect = \
        side_effect_check_syslog_hd_status_for_day_on_demand

    syslog_hd_status = pos_diagnosis.check_syslog_hd_status('on-demand')
    assert_received_and_expected(syslog_hd_status,
                                 ValueDesc(
                                     value=config.MESSAGE_KERNEL_DISK_READ_FAILURES_FOUND,
                                     desc='syslog-1:@ september 30 2017',
                                     date=':@ september 30'
                                 ))

    # check whether it handles exceptions properly
    mock_check_syslog_hd_status_for_day.side_effect = Exception
    syslog_hd_status = pos_diagnosis.check_syslog_hd_status('reboot')
    assert_received_and_expected(syslog_hd_status,
                                 ValueDesc(
                                     value='ERROR'
                                 ))


def test_is_having_bad_sector():
    # checks whether it works as expected if there are bad sectors
    bad_secter_lines = ["sector-1;10;5;20", "sector-2;1;5;0"]
    assert pos_diagnosis.is_having_bad_sector(bad_secter_lines)

    # checks whether it works as expected if there are no bad sectors
    bad_secter_lines = ["sector-1;5;5;0", "sector-2;1;1;0"]
    assert not pos_diagnosis.is_having_bad_sector(bad_secter_lines)


@mock.patch('time.strftime')
@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_stuck_on_loading_from_frontend_log(mock_p_open_stripped, mock_time):
    mock_time.return_value = '2017-10-01'

    expected_calls = [
        mock.call(
            "grep '2017-10-01' /home/leapset/cinco/logs/wfe.log | grep 'WebPOS LOADING ERROR'| grep 'Exceed more than 5 minutes to load the app' | cut -d ',' -f 1")
    ]

    # check whether it works as expected if there are no stuck on loadings
    mock_p_open_stripped.return_value = ''
    stuck_on_loading_result = pos_diagnosis.check_stuck_on_loading()
    assert_received_and_expected(stuck_on_loading_result,
                                 ValueDesc())
    assert mock_p_open_stripped.mock_calls == expected_calls

    # check whether it works as expected if there are stuck on loading cases
    mock_p_open_stripped.return_value = '2017-10-01 04:05:06'
    stuck_on_loading_result = pos_diagnosis.check_stuck_on_loading()
    assert_received_and_expected(stuck_on_loading_result,
                                 ValueDesc(
                                     value=config.MESSAGE_STUCK_ON_LOADING_FOUND,
                                     desc='2017-10-01 04:05:06'
                                 ))

    # chech whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    stuck_on_loading_result = pos_diagnosis.check_stuck_on_loading()
    assert_received_and_expected(stuck_on_loading_result,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE
                                 ))


@mock.patch('pulse_agent.monitor.pos_diagnosis.pos_diagnosis.get_payment_cube_firmware_upgrade_info')
def test_get_payment_cube_firmware_upgrade_failure(mock_get_payment_cube_firmware_upgrade_info):
    # Checks whether it works when there are no firmware upgrade info
    mock_get_payment_cube_firmware_upgrade_info.return_value = []
    firmware_upgrade_failures = pos_diagnosis.get_payment_cube_firmware_upgrade_failure()
    assert_received_and_expected(firmware_upgrade_failures,
                                 ValueDesc())

    # Checks whether it works when there are firmware upgrade info
    mock_get_payment_cube_firmware_upgrade_info.return_value = [
        {'message': 'Firmware upgrade failure', 'code': '0003', 'type': 'ERR', 'time': ''},
        {'message': 'Firmware upgrade failure', 'code': '0003', 'type': 'ERR', 'time': ''}]
    firmware_upgrade_failures = pos_diagnosis.get_payment_cube_firmware_upgrade_failure()

    assert_received_and_expected(firmware_upgrade_failures,
                                 ValueDesc(
                                     value=config.FIRMWARE_UPGRADE_FAIL,
                                     desc='[{"message": "Firmware upgrade failure", "code": "0003", "type": "ERR", "time": ""}, {"message": "Firmware upgrade failure", "code": "0003", "type": "ERR", "time": ""}]'
                                 ))

    # Checks whether it works when an exception is raised
    mock_get_payment_cube_firmware_upgrade_info.side_effect = Exception
    firmware_upgrade_failures = pos_diagnosis.get_payment_cube_firmware_upgrade_failure()
    assert_received_and_expected(firmware_upgrade_failures,
                                 ValueDesc(
                                     value=config.ERROR_MESSAGE
                                 ))


@mock.patch('pulse_agent.utils.sub_process.p_open')
def test_get_payment_cube_firmware_upgrade_info(mock_p_open):

    """
    Test for get_payment_cube_firmware_upgrade_info
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :return: None
    """
    # Checks whether it works when there are no firmware upgrade info
    upgrade_info_read = Mock(return_value=[])
    stdout = Mock(readlines=upgrade_info_read)
    theMock = Mock(stdout=stdout)
    mock_p_open.side_effect = [theMock]
    expected = None
    assert pos_diagnosis.get_payment_cube_firmware_upgrade_info() == expected

    # Checks whether it works when there are firmware upgrade info
    upgrade_info_read = Mock(return_value=
    [
        'log:2017-12-08 23:38:52,975 -[UNIPAYIII-3-HW3-1]--ERROR-com.leapset.devicemanager.DeviceManagerImpl:[PULSE] [FWU] [ERR] [0003] [Firmware upgrade failure]',
        'log:2017-12-08 18:13:03 ,971 -[UNIPAYIII-3-HW3-1]--ERROR-com.leapset.devicemanager.DeviceManagerImpl:[PULSE] [FWU] [ERR] [0003] [Firmware upgrade failure]']

    )
    stdout = Mock(readlines=upgrade_info_read)
    theMock = Mock(stdout=stdout)
    mock_p_open.side_effect = [theMock]
    expected = [{'message': 'Firmware upgrade failure', 'code': '0003', 'type': 'ERR', 'time': 1512756532.0},
                {'message': 'Firmware upgrade failure', 'code': '0003', 'type': 'ERR', 'time': 1512736983.0}]
    assert pos_diagnosis.get_payment_cube_firmware_upgrade_info() == expected

    # Checks whether it handles exceptions
    mock_p_open.side_effect = Exception
    expected = None
    assert pos_diagnosis.get_payment_cube_firmware_upgrade_info() == expected


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_syslog_hd_status_for_day(mock_p_open_stripped):

    """
    Test for check_syslog_hd_status_for_day
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :return: None
    """

    #Check if it works for today
    mock_p_open_stripped.return_value = '3'

    expected_calls = [
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"')
    ]
    assert pos_diagnosis.check_syslog_hd_status_for_day() == ['3']
    assert mock_p_open_stripped.mock_calls == expected_calls

    # Check if it works for yesterday
    mock_p_open_stripped.return_value = '3'

    expected_calls = [
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"'),
        mock.call('date --date="1 days ago" +"%b"'),
        mock.call('date --date="1 days ago" +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"')
    ]
    assert pos_diagnosis.check_syslog_hd_status_for_day('yesterday') == ['3']
    assert mock_p_open_stripped.mock_calls == expected_calls

    # Check if it works for when date is >10
    mock_p_open_stripped.return_value = '13'

    expected_calls = [
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"'),
        mock.call('date --date="1 days ago" +"%b"'),
        mock.call('date --date="1 days ago" +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"'),
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "13 13"')
    ]
    assert pos_diagnosis.check_syslog_hd_status_for_day() == ['13']
    assert mock_p_open_stripped.mock_calls == expected_calls

    # Check if it handles exceptions
    mock_p_open_stripped.side_effect = Exception

    expected_calls = [
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"'),
        mock.call('date --date="1 days ago" +"%b"'),
        mock.call('date --date="1 days ago" +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "3  3"'),
        mock.call('date +"%b"'),
        mock.call('date  +"%-d"'),
        mock.call('zgrep "Unrecovered read error" /var/log/syslog* | grep "13 13"'),
        mock.call('date +"%b"'),
    ]
    assert pos_diagnosis.check_syslog_hd_status_for_day() == config.ERROR_MESSAGE
    assert mock_p_open_stripped.mock_calls == expected_calls


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_check_stuck_on_loading(mock_p_open_stripped):

    """
    Test for check_stuck_on_loading
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :return: None
    """

    #check if it works when there are no stuck onloading data
    mock_p_open_stripped.return_value = ''
    assert not pos_diagnosis.check_stuck_on_loading().VALUE
    assert not pos_diagnosis.check_stuck_on_loading().DATE_TIME
    assert not pos_diagnosis.check_stuck_on_loading().DESCRIPTION

    #check if it works when there are  stuck onloading data
    mock_p_open_stripped.return_value = 'date'
    assert pos_diagnosis.check_stuck_on_loading().VALUE == config.MESSAGE_STUCK_ON_LOADING_FOUND
    assert not pos_diagnosis.check_stuck_on_loading().DATE_TIME
    assert pos_diagnosis.check_stuck_on_loading().DESCRIPTION == 'date'

    #check if it handles exceptions
    mock_p_open_stripped.side_effect = Exception
    assert pos_diagnosis.check_stuck_on_loading().VALUE == config.ERROR_MESSAGE
    assert not pos_diagnosis.check_stuck_on_loading().DATE_TIME
    assert not pos_diagnosis.check_stuck_on_loading().DESCRIPTION

