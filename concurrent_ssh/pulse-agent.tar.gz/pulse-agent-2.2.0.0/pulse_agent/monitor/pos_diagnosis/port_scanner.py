"""
Functions related to port scanning
"""
import logging
from pulse_agent.utils import sub_process


def get_bind_processes_to_ports():
    """
    get_bind_processes_to_ports
    :return:
    """
    try:
        result = []
        all_active_ports = get_all_active_tcp_udp_ports()
        for active_port in all_active_ports:
            result.append({
                'VALUE': active_port,
                'ESTABLISHED': get_running_process_on_port(active_port),
                'LISTEN': get_listening_processes_on_port(active_port),
            })
        return result
    except Exception as exception:
        logging.error('Error while getting bind processes: %s', exception)


def get_running_process_on_port(port):
    """
    get_running_process_on_port
    :param port: port
    :return:
    """
    try:
        established_processes_command = ("lsof -i TCP:" + port + " -sTCP:ESTABLISHED "
                                                                 "| awk '{print $1\";\"$3}'"
                                                                 "|uniq|tail -n +2")
        logging.debug(established_processes_command)
        established_processes_array = sub_process.p_open_stripped(established_processes_command).splitlines()
        return established_processes_array
    except Exception as exception:
        logging.exception('Error while getting established processes to port: %s', exception)


def get_listening_processes_on_port(port):
    """
    get_listening_processes_on_port
    :param port: port
    :return:
    """
    try:
        listening_processes_command = ("lsof -i TCP:" + port + " -sTCP:LISTEN "
                                                               "| awk '{print $1\";\"$3}'"
                                                               "|uniq|tail -n +2")
        logging.debug(listening_processes_command)
        listening_processes = sub_process.p_open_stripped(listening_processes_command).splitlines()
        return listening_processes
    except Exception as exception:
        logging.error('Error while getting listening processes from port: %s', exception)


def get_all_active_tcp_udp_ports():
    """
    get_all_active_tcp_udp_ports
    :return:
    """
    try:
        active_ports_command = ("netstat -ln | awk '/^(tcp|udp)/ { split($4, a, /:/); "
                                "print $1, a[2]}' | sort -u|cut -d ' ' -f 2|grep -v '^$'")
        logging.debug(active_ports_command)
        active_ports_array = sub_process.p_open_stripped(active_ports_command).splitlines()
        return active_ports_array
    except Exception as exception:
        logging.error('Error while getting all active ports: %s', exception)
