"""
This module contains DTOS that have been used in Diagnosis
"""


# pylint: skip-file
# Pylint warns All Caps variables are not invalid


class ValueDesc(object):
    """
    ValueDesc to send diagnosis result
    """

    def __init__(self, value=None, desc='', date=None):
        self.VALUE = value
        self.DESCRIPTION = desc
        self.DATE_TIME = date
