"""
Pos diagnosis facade
"""
import logging
import time
from pulse_agent.monitor.pos_diagnosis import jvm_issue_checker
from pulse_agent.monitor.pos_diagnosis import port_scanner
from pulse_agent.monitor.pos_diagnosis import pos_diagnosis
from pulse_agent.monitor.pos_diagnosis import payments
from pulse_agent.monitor.pos_diagnosis import restarts
from pulse_agent.monitor.network import network
from pulse_agent.monitor.system_stats.system_stats import system_stats
from pulse_agent.services import cinco_identity
from pulse_agent.services.chrome import chrome
from pulse_agent.services.couch import couch
from pulse_agent.services.moxy import moxy
from pulse_agent.utils import json_utils
from pulse_agent.utils import time_utils
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils.config import config


class PosDiagnosisFacade(object):
    """
    Contains methods, attributes related to pos diagnosis
    """

    def __init__(self):
        pass

    def push_data(self, caller):
        """
        Push diagnosis update every hour to Pulse API through Rest
        :param caller:
        :return:
        """
        try:
            response = pulse_client.post(config.DIAGNOSIS_END_POINT, body={
                'payload': self.construct_pos_diagnosis_report(caller)
            })
            logging.info('POS diagnosis data has been sent success fully: %s', response)
        except Exception as exception:
            logging.exception('Error while pushing diagnosis update: %s', exception)

    def gather_restart_diagnosis(self):
        """
        Send restart diagnosis update every hour to Pulse API through Websocket
        :return:
        """
        restart_data = dict(
            MERCHANT_NAME=cinco_identity.get_merchant_name(),
            MERCHANT_ID=cinco_identity.get_merchant_id(),
            REGISTER_NO=cinco_identity.get_register_no(),
            RESTARTS=restarts.gather_new_restarts(),
            IS_PULSE_VERSION_CHANGED=pos_diagnosis.is_pulse_version_changed()
        )

        logging.debug('Sending restart stats: %s', json_utils.get_json_dump(restart_data))
        return restart_data

    def send_swipes_data(self):
        """
        Send swipes data related updates every hour to Pulse API through Rest API
        :return:
        """
        try:
            swipes_data = dict(
                SWIPES=payments.get_swipe_status_within_today(),
                SUCCESSFUL_CLOSE_CASHES=payments.get_close_cash_timestamp_list_today()
            )

            logging.debug('Swipes data: %s', json_utils.get_json_dump(swipes_data))

            response = pulse_client.post(config.SWIPES_ENDPOINT, body=swipes_data)
            logging.info('Swipes data has been sent success fully: %s', response)

        except Exception as exception:
            logging.exception('Error while processing Pulse Data Failed At Some Point: %s',
                              exception)

    def construct_pos_diagnosis_report(self, caller):
        """
        Construct Pos diagnosis update body
        :param caller: on-demand/reboot
        :return:
        """
        try:
            response = dict(
                MERCHANT_ID=cinco_identity.get_merchant_id(),
                REGISTER_NO=cinco_identity.get_register_no(),
                MERCHANT_NAME=cinco_identity.get_merchant_name(),
                POS_VERSION=cinco_identity.get_cinco_version().strip('"'),
                UPTIME=system_stats.get_system_uptime(),
                XORG_VERSION=system_stats.get_os_xorg_version(),
                XORG_CRASHES=pos_diagnosis.check_xrog_crashes(caller),
                TOUCH_FIXES=pos_diagnosis.check_touch_fixes(),
                TOUCH_DRIVERS=pos_diagnosis.check_touch_drivers(),
                JVM_CRASHES=jvm_issue_checker.check_jvm_crashes(),
                COUCHDB_CORRUPTIONS=couch.check_couch_corruptions(caller),
                COUCHDB_COMPACTIONS=couch.check_couch_db_compactions(),
                HAS_BAD_SECTORS=pos_diagnosis.check_hard_disk_bad_sectors(),
                SYSLOG_HD_STATUS=pos_diagnosis.check_syslog_hd_status(caller),
                MOXY_CORRUPTION=moxy.check_moxy_corruptions(caller),
                MAC=network.get_network_data('mac'),
                RESTARTS=restarts.reboot_count_between_restarts('03:30:00', caller),
                TIME_ZONE=time_utils.get_timezone(),
                UNIX_TIME=int(time.time()),
                STUCK_ON_LOADING=pos_diagnosis.check_stuck_on_loading(),
                MOXY_VERSION=moxy.get_running_moxy_version(),
                CARD_READER_NOT_FOUND=payments.check_swiper_connected(),
                PAYMENT_DECRYPT_ERROR=payments.check_decrypt_error_within_current_hour(),
                ACTIVE_PORTS=port_scanner.get_bind_processes_to_ports(),
                IMMINENT_HARD_DISK_FAILURE_DETECTED=pos_diagnosis.get_smartctl_self_assessment(),
                COUCH_LOG_SIZE_EXCEEDS_THRESHOLD=couch.check_if_couch_log_exceeds(),
                COUCH_DB_SIZE_EXCEEDS_THRESHOLD=couch.check_if_couch_size_exceeds_threshold(),
                MSR_ISSUE_DETECTED=payments.fetch_msr_related_issues(),
                FAILED_ORDER_FOUND=chrome.check_failed_orders(),
                MOXY_WAR_NOT_FOUND=moxy.check_moxy_war_existence(),
                ETH_0_NOT_AVAILABLE=pos_diagnosis.check_eth0_connectivity(),
                PAYMENT_CUBE_FIRMWARE_UPGRADE_FAIL=pos_diagnosis.get_payment_cube_firmware_upgrade_failure(),
            )

            logging.info('Diagnosis data: %s', json_utils.get_pretty_json(response))
            return response

        except Exception as exception:
            logging.exception("Error while gathering pos diagnosis data: %s", exception)
            raise Exception

    def process_jvm_crash_categories(self):
        """
        Process JVM crash categories
        """
        try:
            jvm_issue_checker.get_category_pattern_data_from_end_point()
        except Exception as exception:
            logging.exception('Error while starting pulse process: %s', exception)

    def process_payment_sanity(self):
        """
        Process payment sanity
        :return: Sends payment sanity report to the API
        """
        try:
            payment_sanity = dict(
                SANITY_DATA=dict(
                    PAYMENT_CUBE_FAILURES=payments.get_payment_cube_failure_data(),
                    CPM_BAD_SWIPES=payments.get_cpm_bad_swipes(),
                    AVERAGE_TRANSACTION=payments.get_average_transaction_time(),
                    FIRMWARE_UPGRADE_FAILURES=pos_diagnosis.get_payment_cube_firmware_upgrade_failure().DESCRIPTION,
                    DEVICE_CONNECTION=payments.get_device_connection_logs()
                )
            )
            logging.debug('Payment sanity report: %s', json_utils.get_json_dump(payment_sanity))

            response = pulse_client.post(config.PAYMENT_SANITY_ENDPOINT, body=payment_sanity)
            logging.info('Payment sanity data has been sent success fully: %s', response)

        except Exception as exception:
            logging.exception('Error while doing payment sanity: %s', exception)


pos_diagnosis_facade = PosDiagnosisFacade()
