"""
This module contains method related to jvm issues diagnosis
"""
import datetime
import glob
import json
import logging
import os
import pickle
import ast
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.monitor.pos_diagnosis.dtos import ValueDesc
from pulse_agent.utils.config import config


def check_jvm_crashes():
    """
    Check JVM crashes
    :return:
    """
    try:
        categorized_crash_log_file_list = get_categorize_crash_log_files(get_crash_log_file_list())

        if not categorized_crash_log_file_list:
            return ValueDesc()

        return ValueDesc(value=config.JVM_CRASHES_FOUND,
                         desc=json.dumps(categorized_crash_log_file_list))
    except Exception as exception:
        logging.exception('Error while checking JVM crashes: %s', exception)
        return ValueDesc(value=config.ERROR_MESSAGE)


def get_crash_log_file_list():
    """
    Get crash log file list
    :return:
    """
    try:
        crash_log_file_list = []
        current_time = int(datetime.datetime.now().strftime("%s"))

        os.chdir(config.CRASH_LOG_DIR_PATH)

        for file_name in glob.glob("hs*.log"):
            file_with_path = config.CRASH_LOG_DIR_PATH + file_name
            last_modified_time = os.path.getmtime(file_with_path)

            if last_modified_time >= (current_time - 24 * 3600):
                crash_log_file_list.append(
                    {'FILE_PATH': file_with_path, 'LAST_MODIFIED_TIME': last_modified_time})

        return crash_log_file_list
    except Exception as exception:
        logging.exception("[JVM_ISSUE_CHECKER] Error getting crash log file list : %s", exception)
        raise Exception


def get_categorize_crash_log_files(crash_log_file_list):
    """
    get_categorize_crash_log_files
    :param crash_log_file_list:
    :return:
    """
    try:
        category_patterns = []
        if os.path.isfile(config.JVM_CRASH_CATEGORY_PATTERNS_FILE_PATH):
            with open(config.JVM_CRASH_CATEGORY_PATTERNS_FILE_PATH, "rb") as input_file:
                category_patterns = pickle.load(input_file)

        categorized_crash_log_file_list = []

        for element in crash_log_file_list:
            is_match_found = False
            for category_pattern in category_patterns:
                if category_pattern.get('PATTERN') in open(element.get('FILE_PATH')).read():
                    is_match_found = True
                    categorized_crash_log_file_list.append(
                        {'FILE_PATH': element.get('FILE_PATH'),
                         'LAST_MODIFIED_TIME': element.get('LAST_MODIFIED_TIME'),
                         'CATEGORY': category_pattern.get('CATEGORY')})
                    break
            if not is_match_found:
                categorized_crash_log_file_list.append(
                    {'FILE_PATH': element.get('FILE_PATH'),
                     'LAST_MODIFIED_TIME': element.get('LAST_MODIFIED_TIME'),
                     'CATEGORY': 'UNCATEGORIZED'})
        categorized_crash_log_file_list.sort(
            lambda x, y: cmp(x['LAST_MODIFIED_TIME'], y['LAST_MODIFIED_TIME']))
        return categorized_crash_log_file_list
    except Exception as exception:
        logging.exception("[JVM_ISSUE_CHECKER] Error categorizing crash log file list : %s",
                          exception)
        raise Exception


def get_category_pattern_data_from_end_point():
    """
    Get category patterns data from pulse API and save it
    """
    try:
        response = pulse_client.dedicated_client.get(config.JVM_CRASH_CATEGORY_PATTERNS_END_POINT)
        if response.status_code == 200:
            result = str(response.text)
            logging.debug('retrieved json as jvm categories : %s', result)
            with open(config.JVM_CRASH_CATEGORY_PATTERNS_FILE, "wb") as output_file:
                pickle.dump(ast.literal_eval(result), output_file)
        else:
            logging.error('Could not get JVM Crashes list, Response : %s', response.status_code)
    except Exception as exception:
        logging.error('Error while processing jvm crash categories: %s', exception)
