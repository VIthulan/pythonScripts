"""
Job manager module: It acts as a mediator between initiators and services
"""
import logging
import time
from datetime import datetime
import threading
from pulse_agent.monitor.system_stats.stats_facade import stats_facade
from pulse_agent.monitor.post_restart_jobs import post_restart_job_manager
from pulse_agent.monitor.pos_diagnosis.pos_diagnosis_facade import pos_diagnosis_facade
from pulse_agent.monitor.network.network_facade import network_facade
from pulse_agent.monitor.app_state.app_state_facade import app_state_checker
from pulse_agent.actuator.image_upgrade.image_upgrader_facade import image_upgrader_facade
from pulse_agent.utils import json_utils
from pulse_agent.utils.config import config
from pulse_agent.utils import file_utils

logger = logging.getLogger('')
heading_logger = logging.getLogger(config.HEADING_LOGGER)


class JobManager(object):
    """ Connector for all pulse agent interval jobs """

    def __init__(self, dedicated_web_socket_client, dev_web_socket_client):
        self.dedicated_web_socket_client = dedicated_web_socket_client
        self.dev_web_socket_client = dev_web_socket_client
        self.lock = threading.Lock()  # This Lock will synchronize threads

    def send_system_stats_update(self, interval):
        """ Sends 3 minutes stats via web sockets """

        is_post_tool_alert_recorded = False

        while True:
            try:
                self.lock.acquire()
                logging.debug('HEART BEAT UPDATE thread activated')
                heart_beat = stats_facade.gather_stats(config.DEDICATED)
                logging.info("Sending Heart beat: " + json_utils.get_pretty_json(heart_beat))

                # send system stats to dedicated and dev servers
                self.dedicated_web_socket_client.send('HEART_BEAT', heart_beat)
                self.dev_web_socket_client.send('HEART_BEAT', stats_facade.gather_stats(config.DEV))
                logging.info('Heart beat is sent to both Dedicated Env and Dev Env')
                # update pulse agent heartbeat in records.conf
                file_utils.update_last_heart_beat(str(int(time.time())))
                if is_post_tool_alert_recorded is False:
                    #record post tool alert in meta.conf
                    is_post_tool_alert_recorded = post_restart_job_manager.record_post_tool_alert()
                self.lock.release()
                time.sleep(interval)
            except Exception as exception:
                logging.exception('Exception in HEARTBEAT thread: %s', exception)
                self.lock.release()
                time.sleep(interval)

    def send_diagnosis_update(self, interval):
        """ Sends hourly data via web sockets and rest calls """
        count = 0
        while True:
            try:
                self.lock.acquire()
                count = count + 1
                logging.debug('DIAGNOSIS UPDATE thread activated')
                # send restarts update to dedicated and dev servers
                restart_stats = pos_diagnosis_facade.gather_restart_diagnosis()
                self.dedicated_web_socket_client.send('RESTART_UPDATE', restart_stats)
                self.dev_web_socket_client.send('RESTART_UPDATE', restart_stats)
                logging.info('Pos diagnosis restart updates have been sent successfully')
                if count != 1:
                    # sends diagnosis update
                    pos_diagnosis_facade.push_data('on-demand')
                # sends swipe data
                pos_diagnosis_facade.send_swipes_data()
                logging.debug('Diagnosis data is sent to both Dedicated Env and Dev Env')
                self.lock.release()
                time.sleep(interval)
            except Exception as exception:
                logging.exception('Exception in DIAGNOSIS thread: %s', exception)
                self.lock.release()
                time.sleep(interval)

    def every_quarter_checkups(self, interval):
        """ Sends 15 minutes connectivity data via web sockets and rest calls """
        image_upgrade_checkups = False  # TODO: Once OS Upgrade is enabled by SWAT Team make it True
        while True:
            try:
                self.lock.acquire()
                logging.debug('Storm thread activated')
                if image_upgrade_checkups is True:
                    image_upgrade_checkups = image_upgrader_facade.upgrade_checkup_warden()
                #Post Tool Alert update
                post_restart_job_manager.check_post_tool_screen_alert()
                network_facade.process_inter_connection_check()
                logging.info(
                    'Network connectivity update is sent to both Dedicated Env and Dev Env')
                logging.debug('Storm thread sleeps')
                self.lock.release()
                time.sleep(interval)
            except Exception as exception:
                logging.exception('Exception in STORM thread: %s', exception)
                logging.debug('Storm thread sleeps')
                self.lock.release()
                time.sleep(interval)

    def every_min_checkups(self, interval):
        """ Sends 1 minutes about pos app states via rest calls """
        while True:
            try:
                self.lock.acquire()
                logging.debug('FLASH thread activated')
                app_state_checker.check_app_states()
                network_facade.perform_arp_scan_accumulation()
                logging.debug('FLASH thread completed execution')
                self.lock.release()
                time.sleep(interval)
            except Exception as exception:
                logging.exception('Exception in FLASH thread: %s', exception)
                self.lock.release()
                time.sleep(interval)

    def first_quarter_checkups(self, delay):
        """ Starts checking couch indexing time error and stops"""
        try:
            is_scheduled_restart = False
            current_time = datetime.now().time()
            start_time = datetime.strptime(config.FIXED_RESTART_START_TIME, "%H:%M:%S").time()
            end_time = datetime.strptime(config.FIXED_RESTART_END_TIME, "%H:%M:%S").time()

            if start_time <= current_time <= end_time:
                logging.debug("Its a scheduled restart time")
                is_scheduled_restart = True

            time.sleep(delay)
            logging.debug('First quarter checkups Thread activated')
            self.lock.acquire()

            post_restart_job_manager.check_couch_indexing_timeout()

            if is_scheduled_restart is True:
                # This block will contain functions that that has to be executed only
                # after scheduled restarts
                post_restart_job_manager.generate_time_not_synced_alert()

            logging.warning('First quarter checkups Thread dies')
            self.lock.release()
        except Exception as exception:
            logging.exception('Exception in FIRST QUARTER thread: %s', exception)
            self.lock.release()

    def check_couch_partial_compact(self, delay):
        """ starts partial post_restart_jobs compaction alert service
        only after the 3am restart and stops"""
        try:
            logging.debug('GENERATE PARTIAL COUCH COMPACTION thread activated')
            current_time = datetime.now().time()
            start_time = datetime.strptime(config.FIXED_RESTART_START_TIME, "%H:%M:%S").time()
            end_time = datetime.strptime(config.FIXED_RESTART_END_TIME, "%H:%M:%S").time()

            if start_time <= current_time <= end_time:
                logging.debug('Couch compaction check will start in %s seconds', delay)
                time.sleep(delay)
                self.lock.acquire()
                post_restart_job_manager.check_couch_partial_compaction()
                logging.warning('Couch compaction Thread dies')
                self.lock.release()
            else:
                logging.warning('Couch compaction Thread dies, current time is not between 3PM-4PM')
        except Exception as exception:
            logging.exception('Exception in Couch Compaction thread: %s', exception)
            self.lock.release()

    def is_scheduled_restart(self):
        """
        return true if this time window overlaps the scheduled restart time window
        :return: boolean
        """
        try:
            current_time = datetime.now().time()
            start_time = datetime.strptime(config.FIXED_RESTART_START_TIME, "%H:%M:%S").time()
            end_time = datetime.strptime(config.FIXED_RESTART_END_TIME, "%H:%M:%S").time()
            return start_time <= current_time <= end_time
        except Exception as exception:
            logging.exception("Exception while checking the scheduled restart time window: %s",
                              exception)
            return False

    def detect_anomalies(self, delay):
        """
        starts anomaly detection only after the 3am restart and stops
        :param delay: time to sleep
        :return: 
        """
        try:
            logging.debug('Anomaly Detection thread activated')
            if self.is_scheduled_restart():
                logging.debug('Anomaly detection will start in %s seconds', delay)
                time.sleep(delay)
                self.lock.acquire()
                post_restart_job_manager.detect_anomalies_occurred_yesterday()
                logging.warning('Anomaly detection Thread dies')
                self.lock.release()
            else:
                logging.warning(
                    'Anomaly detection Thread dies since this is not a scheduled restart')
        except Exception as exception:
            logging.exception('Exception in Anomaly detection thread: %s', exception)
            self.lock.release()


def process_initial_tasks():
    """
    Process initial tasks before starting pulse agent
    :return:
    """
    try:
        logging.info('Processing initial tasks')
        post_restart_job_manager.process_pulse_data()
        network_facade.process_connectivity_checks()
        pos_diagnosis_facade.process_jvm_crash_categories()
        pos_diagnosis_facade.push_data('reboot')
        pos_diagnosis_facade.process_payment_sanity()
        logging.info('Initial tasks completed successfully')
    except Exception as exception:
        logging.exception('Exception occured while processing initial tasks: %s', exception)
