"""
Test cases for post_restart_job_manager module
"""

# core modules
import logging
import mock
import time

# testing module
from pulse_agent.monitor.post_restart_jobs import post_restart_job_manager

from dtos import Response
from pulse_agent.utils.config import config
from pulse_agent.services.dtos.value_desc import ValueDesc

logging.basicConfig(level=logging.FATAL)

def setup_module(mdl):
    """ setup_module """
    log = logging.getLogger('setup_module')
    log.debug("setup_module module:%s", mdl.__name__)


def teardown_module(mdl):
    """ teardown_module """
    log = logging.getLogger('teardown_module')
    log.debug("teardown_module module:%s", mdl.__name__)


def setup_function(func):
    """ setup_function """
    logging.info("setup_function function:%s", func.__name__)


def teardown_function(func):
    """ teardown_function """
    log = logging.getLogger('teardown_function')
    log.debug("teardown_function function:%s", func.__name__)


def network_data_side_effect(arg):
    """ side effect for network data function """

    if arg == 'name':
        return 'nw_name'
    elif arg == 'ip':
        return 'nw_ip'
    elif arg == 'mask':
        return 'nw_mask'
    elif arg == 'mac':
        return 'nw_mac'


@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
@mock.patch('pulse_agent.services.chrome.chrome.find_pattern_in_chrome_logs')
def test_check_couch_indexing_timeout(
        mock_find_pattern_in_chrome_logs,
        mock_rest_client_post):
    """
    Test for check_couch_indexing_timeout
    :param mock_find_pattern_in_chrome_logs: magic mock object of find_pattern_in_chrome_logs method
    :param mock_rest_client_post: magic mock object of post method
    :return: None
    """

    start_time = (int(time.time()) - config.FIRST_QUARTER_TIMEOUT - config.COUCH_INDEXING_TIMEOUT_BUFFERED_SPAN)

    # When Patterns are not found in chrome logs
    mock_find_pattern_in_chrome_logs.return_value = False

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    post_restart_job_manager.check_couch_indexing_timeout()
    mock_find_pattern_in_chrome_logs.assert_called_with(
        config.CHROME_DEBUG_ACTIVE_LOG,
        config.COUCH_INDEXING_TIMEOUT_PATTERN,
        start_time)

    assert not mock_rest_client_post.called

    # When Patterns are found in chrome logs
    mock_find_pattern_in_chrome_logs.return_value = True

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    post_restart_job_manager.check_couch_indexing_timeout()
    mock_find_pattern_in_chrome_logs.assert_called_with(
        config.CHROME_DEBUG_ACTIVE_LOG,
        config.COUCH_INDEXING_TIMEOUT_PATTERN,
        start_time)

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'STATS': None,
            'DESCRIPTION': 'Couch indexing timeout found from chrome-dubug.log',
            'KEY': 'COUCH_INDEXING_TIMEOUT',
            'MERCHANT_ID': None},
        path='/api/v1/device/postRestartChecks')


@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_free_disk_space')
@mock.patch('pulse_agent.services.couch.couch.delete_couch_compact_file')
@mock.patch('pulse_agent.services.couch.couch.get_couch_db_size')
@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
@mock.patch('pulse_agent.services.couch.couch.check_couch_db_compactions')
def test_check_couch_partial_compaction(
        mock_check_couch_db_compactions,
        mock_rest_client_post,
        mock_get_couch_db_size,
        mock_delete_couch_compact_file,
        Mock_get_free_disk_space):
    """
    Test for check_couch_partial_compaction
    :param mock_check_couch_db_compactions: magic mock object of check_couch_db_compactions method
    :param mock_rest_client_post: magic mock object of post method
    :param mock_get_couch_db_size: magic mock object of get_couch_db_size method
    :param mock_delete_couch_compact_file: magic mock object of delete_couch_compact_file method
    :param Mock_get_free_disk_space: magic mock object of get_free_disk_space method
    :return: None
    """

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    # When Compaction is not running
    mock_check_couch_db_compactions.return_value = ValueDesc()
    mock_get_couch_db_size.return_value = 'value_02'
    mock_delete_couch_compact_file.return_value = 'value_01'
    Mock_get_free_disk_space.return_value = 'value_03'

    mock_rest_client_post.return_value = the_response
    post_restart_job_manager.check_couch_partial_compaction()

    mock_rest_client_post.assert_not_called()

    # When Compaction is running
    mock_check_couch_db_compactions.return_value = ValueDesc(value=config.MESSAGE_COMPACTION_RUNNING)
    mock_get_couch_db_size.return_value = 'value_02'
    mock_delete_couch_compact_file.return_value = 'value_01'
    Mock_get_free_disk_space.return_value = 'value_03'

    mock_rest_client_post.return_value = the_response
    post_restart_job_manager.check_couch_partial_compaction()

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'STATS': {
                'COUCH_DB_SIZE': 'value_02',
                'RESPONSE': 'value_01',
                'FREE_DISK_SPACE': 'value_03'
            },
            'DESCRIPTION': 'partial couch compaction file available in /var/lib/couchdb/* or /var/lib/couchdb/.*/mrview',
            'KEY': 'COUCH_PARTIAL_COMPACTION',
            'MERCHANT_ID': None},
        path='/api/v1/device/postRestartChecks')


@mock.patch('pulse_agent.utils.file_utils.update_statistics')
@mock.patch('pulse_agent.monitor.post_restart_jobs.post_restart_job_manager.get_daily_stats')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.ctd_status')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_os_xorg_version')
@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
def test_process_pulse_data(
        mock_rest_client_post,
        mock_get_os_xorg_version,
        mock_ctd_status,
        mock_get_daily_stats,
        mock_update_statistics
):
    """
    Test for process_pulse_data
    :param mock_rest_client_post: magic mock object of post method
    :param mock_get_os_xorg_version: magic mock object of get_os_xorg_version method
    :param mock_ctd_status: magic mock object of ctd_status method
    :param mock_get_daily_stats: magic mock object of get_daily_stats method
    :param mock_update_statistics: magic mock object of update_statistics method
    :return: None
    """

    # When process is not successful
    the_response = Response()
    the_response.code = "expired"
    the_response.error_type = "expired"
    the_response.status_code = 400

    mock_rest_client_post.return_value = the_response

    mock_get_os_xorg_version.return_value = 'os_xorg_version'
    mock_ctd_status.return_value = True
    mock_update_statistics.return_value = None
    mock_get_daily_stats.return_value = {
        'COUCH_DB_SIZE': 'value_02',
        'RESPONSE': 'value_01',
        'FREE_DISK_SPACE': 'value_03'
    }

    post_restart_job_manager.process_pulse_data()
    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'FREE_DISK_SPACE': 'value_03',
            'COUCH_DB_SIZE': 'value_02',
            'MERCHANT_ID': None,
            'RESPONSE': 'value_01'},
        path='/api/v1/pos/update')

    mock_update_statistics.assert_not_called()

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    mock_get_os_xorg_version.return_value = 'os_xorg_version'
    mock_ctd_status.return_value = True
    mock_update_statistics.return_value = None
    mock_get_daily_stats.return_value = {
        'COUCH_DB_SIZE': 'value_02',
        'RESPONSE': 'value_01',
        'FREE_DISK_SPACE': 'value_03'
    }

    post_restart_job_manager.process_pulse_data()
    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'FREE_DISK_SPACE': 'value_03',
            'COUCH_DB_SIZE': 'value_02',
            'MERCHANT_ID': None,
            'RESPONSE': 'value_01'},
        path='/api/v1/pos/update')

    mock_update_statistics.assert_called_with('os_xorg_version', True)

    # Check if it catches exceptions
    mock_get_os_xorg_version.return_value = 'os_xorg_version'
    mock_ctd_status.return_value = True
    mock_update_statistics.side_effect = Exception
    mock_get_daily_stats.return_value = {
        'COUCH_DB_SIZE': 'value_02',
        'RESPONSE': 'value_01',
        'FREE_DISK_SPACE': 'value_03'
    }
    post_restart_job_manager.process_pulse_data()
    expected_update_calls = [
        mock.call('os_xorg_version', True),
        mock.call('os_xorg_version', True)
    ]
    assert mock_update_statistics.mock_calls == expected_update_calls


@mock.patch('pulse_agent.monitor.pos_diagnosis.restarts.get_reboot_time')
@mock.patch('pulse_agent.services.couch.couch.get_couchdb_version')
@mock.patch('pulse_agent.services.cinco_identity.get_merchant_name')
@mock.patch('pulse_agent.services.cinco_identity.get_cinco_version')
@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.get_pos_build_env')
@mock.patch('pulse_agent.services.cinco_identity.get_image_version')
@mock.patch('pulse_agent.monitor.network.network.get_public_ip')
@mock.patch('pulse_agent.monitor.network.network.get_default_gateway')
@mock.patch('pulse_agent.monitor.network.network.get_network_data')
@mock.patch('pulse_agent.monitor.network.network.get_hostname')
@mock.patch('pulse_agent.monitor.network.network.get_network_interfaces')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_hard_disk_model')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_device_type')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_serial_number')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_hard_disk_bad_sectors_info')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_os_xorg_version')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_python_version')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_java_version')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_distribution_name')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_kernel_version')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.ctd_status')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_system_uptime')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_disk_partitions')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_processor_architecture')
def test_get_daily_stats(
        mock_get_processor_architecture,
        mock_get_disk_partitions,
        mock_get_system_uptime,
        mock_ctd_status,
        mock_get_kernel_version,
        mock_get_distribution_name,
        mock_get_java_version,
        mock_get_python_version,
        mock_get_os_xorg_version,
        mock_get_hard_disk_bad_sectors_info,
        mock_get_serial_number,
        mock_get_device_type,
        mock_get_hard_disk_model,
        mock_get_network_interfaces,
        mock_get_hostname,
        mock_get_network_data,
        mock_get_default_gateway,
        mock_get_public_ip,
        mock_get_image_version,
        mock_get_pos_build_env,
        mock_get_cinco_version,
        mock_get_merchant_name,
        mock_get_couchdb_version,
        mock_get_reboot_time
):

    """
    Test for test_get_daily_stats
    :param : magic mock objects for methods tto be mocked
    :return: None
    """

    # Check if the method works fine with correct data
    mock_get_processor_architecture.return_value = 'processor_architecture'
    mock_get_disk_partitions.return_value = 'disk_partitions'
    mock_get_system_uptime.return_value = 'system_uptime'
    mock_ctd_status.return_value = 'ctd_status'
    mock_get_kernel_version.return_value = 'kernel_version'
    mock_get_distribution_name.return_value = 'distribution_name'
    mock_get_java_version.return_value = 'java_version'
    mock_get_python_version.return_value = 'python_version'
    mock_get_os_xorg_version.return_value = 'xorg_version'
    mock_get_hard_disk_bad_sectors_info.return_value = 'hard_disk_bad_sectors_info'
    mock_get_serial_number.return_value = 'serial_number'
    mock_get_device_type.return_value = 'device_type'
    mock_get_hard_disk_model.return_value = 'hard_disk_model'
    mock_get_network_data.side_effect = network_data_side_effect
    mock_get_network_interfaces.return_value = 'network_interfaces'
    mock_get_hostname.return_value = 'hostname'
    mock_get_default_gateway.return_value = 'default_gateway'
    mock_get_public_ip.return_value = 'public_ip'
    mock_get_image_version.return_value = 'image_version'
    mock_get_pos_build_env.return_value = 'build_env'
    mock_get_cinco_version.return_value = 'cinco_version'
    mock_get_merchant_name.return_value = 'merchant_name'
    mock_get_couchdb_version.return_value = 'couchdb_version'
    mock_get_reboot_time.return_value = 'reboot_time'

    data = dict(
        AGENT_VERSION=config.VERSION,
        MERCHANT_NAME='merchant_name',
        POS_VERSION='cinco_version',
        BUILD_ENV='build_env',
        CPU_TYPE='processor_architecture',
        DISKS_PARTITIONS='disk_partitions',
        NETWORK_INTERFACES='network_interfaces',
        NETWORK_HOSTNAME='hostname',
        NETWORK_CARD='nw_name',
        NETWORK_GATEWAY='default_gateway',
        NETWORK_PUBLIC_IP='public_ip',
        NETWORK_LOCAL_IP='nw_ip',
        NETWORK_MASK='nw_mask',
        SYSTEM_UPTIME='system_uptime',
        CTD_STATUS='ctd_status',
        KERNEL='kernel_version',
        DISTRIBUTION='distribution_name',
        JAVA='java_version',
        COUCHDB='couchdb_version',
        PYTHON='python_version',
        XORG_VERSION='xorg_version',
        MAC='nw_mac',
        HD_BAD_SECTORS_INFO='hard_disk_bad_sectors_info',
        IMAGE_VERSION='image_version',
        SERIAL_NUMBER='serial_number',
        DEVICE_TYPE='device_type',
        HD_MODEL='hard_disk_model',
        REBOOT_TIME='reboot_time')

    assert post_restart_job_manager.get_daily_stats() == data

    # Check if it handles exceptions

    mock_get_reboot_time.side_effect = Exception
    assert post_restart_job_manager.get_daily_stats() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.services.moxy.moxy.is_time_not_synchronized')
@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
def test_generate_time_not_synced_alert(
        mock_rest_client_post,
        mock_is_time_not_synchronized
):
    """
    Test for generate_time_not_synced_alert
    :param mock_rest_client_post: magic mock object of post method
    :param mock_is_time_not_synchronized: magic mock object of is_time_not_synchronized method
    :return: None
    """

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    # check if it works as exoected when time is not synchronized
    mock_is_time_not_synchronized.return_value = True, 'description'

    post_restart_job_manager.generate_time_not_synced_alert()
    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'STATS': None,
            'DESCRIPTION': 'description',
            'KEY': 'TIME_NOT_SYNCED',
            'MERCHANT_ID': None},
        path='/api/v1/device/postRestartChecks')

    # check if it works as exoected when time is synchronized
    mock_is_time_not_synchronized.return_value = False, 'description'

    expected_calls = [
        mock.call(
            body={
                'REGISTER_NO': None,
                'STATS': None,
                'DESCRIPTION': 'description',
                'KEY': 'TIME_NOT_SYNCED',
                'MERCHANT_ID': None},
            path='/api/v1/device/postRestartChecks'),
        mock.call(
            body={
                'REGISTER_NO': None,
                'STATS': None,
                'DESCRIPTION': 'description',
                'KEY': 'TIME_NOT_SYNCED',
                'MERCHANT_ID': None},
            path='/api/v1/device/postRestartChecks')

    ]

    post_restart_job_manager.generate_time_not_synced_alert()
    assert mock_rest_client_post.mock_calls == expected_calls
    # check if it handles exceptions
    mock_is_time_not_synchronized.side_effect = Exception

    expected_calls = [
        mock.call(
            body={
                'REGISTER_NO': None,
                'STATS': None,
                'DESCRIPTION': 'description',
                'KEY': 'TIME_NOT_SYNCED',
                'MERCHANT_ID': None},
            path='/api/v1/device/postRestartChecks'),
        mock.call(
            body={
                'REGISTER_NO': None,
                'STATS': None,
                'DESCRIPTION': 'description',
                'KEY': 'TIME_NOT_SYNCED',
                'MERCHANT_ID': None},
            path='/api/v1/device/postRestartChecks')

    ]

    post_restart_job_manager.generate_time_not_synced_alert()
    assert mock_rest_client_post.mock_calls == expected_calls
