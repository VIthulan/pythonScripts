"""
DTOs for tests
"""


class Response(object):
    """
    mock Response object
    """
    def __init__(self, text='', status_code=200, data=None):
        self.text = text
        self.status_code = status_code
        self.data = data

    def json(self):
        """
        mock public method
        :return:data
        """
        return self.data

    def do2(self):
        """
        mock public method
        :return:None
        """
        pass