"""
This module contains jobs that will run once, after the pulse-agent restart.
Functions activation time may vary based on the requirements
"""
import datetime
import logging
import re
import time

from pulse_agent.monitor.network import network
from pulse_agent.monitor.pos_diagnosis import payments
from pulse_agent.monitor.pos_diagnosis import restarts
from pulse_agent.monitor.system_stats.system_stats import system_stats
from pulse_agent.services import cinco_identity
from pulse_agent.services.chrome import chrome
from pulse_agent.services.couch import couch
from pulse_agent.services.moxy import moxy
from pulse_agent.utils import file_utils
from pulse_agent.utils import json_utils
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config
from pulse_agent.utils.config_managers import pos_config_manager
from pulse_agent.utils.decorators.try_except import try_except
from pulse_agent.utils.pulse_client import pulse_client


def check_couch_indexing_timeout():
    """
    Check for couch indexing timeout from chrome log
    :return: None
    """
    logging.debug("Checking for couch indexing timeout")

    try:
        start_time = (int(
            time.time()) - config.FIRST_QUARTER_TIMEOUT - config.COUCH_INDEXING_TIMEOUT_BUFFERED_SPAN)

        couch_indexing_status = chrome.find_pattern_in_chrome_logs(
            config.CHROME_DEBUG_ACTIVE_LOG,
            config.COUCH_INDEXING_TIMEOUT_PATTERN,
            start_time
        )

        logging.debug("Couch indexing timeout status : %s", couch_indexing_status)

        if couch_indexing_status:
            pulse_client.post(config.POST_RESTART_CHECKS_END_POINT, body={
                'KEY': config.COUCH_INDEXING_TIMEOUT,
                'DESCRIPTION': config.COUCH_INDEXING_TIMEOUT_DESCRIPTION,
                'STATS': None
            })
    except Exception as exception:
        logging.exception(
            "Error while checking couch indexing timeout : %s", exception)


def check_couch_partial_compaction():
    """
    Generate partial compaction alert if compact file is available around 5PM
    :return:
    """
    try:
        logging.debug('Initiating couch compaction checks')
        if couch.check_couch_db_compactions().VALUE == config.MESSAGE_COMPACTION_RUNNING:

            data = {
                'KEY': config.PARTIAL_COUCH_COMPACTION,
                'DESCRIPTION': config.PARTIAL_COUCH_COMPACTION_DESCRIPTION,
                'STATS': {
                    'RESPONSE': couch.delete_couch_compact_file(),
                    'COUCH_DB_SIZE': couch.get_couch_db_size(),
                    'FREE_DISK_SPACE': system_stats.get_free_disk_space()
                }
            }

            logging.info('Compaction details %s : ', data)

            pulse_client.post(path=config.POST_RESTART_CHECKS_END_POINT, body=data)
        else:
            logging.info("No Partial Couch Compactions")
    except Exception as exception:
        logging.exception("Exception while checking for partial couch compaction: %s", exception)


@try_except(level='exception', default=False)
def record_post_tool_alert():
    """
    This method checks until Post Tool check stops.
    If it identifies zenity message of Post Tool it records in a flat file.
    :return:
    """
    if system_stats.is_post_tool_running:
        post_tool_screen_alert = system_stats.get_post_tool_screen_alert()

        if post_tool_screen_alert is not None:
            file_utils.update_conf_file(
                config.CONF_FILE_PATH,
                config.POST_TOOL_ALERT,
                post_tool_screen_alert
            )
            return True
    return False


@try_except(level='exception', default=None)
def check_post_tool_screen_alert():
    """
    Generate post tool screen alert if alert is already being persisted.
    Reset the value in the flat file when data is sent to the Pulse API successfully.
    :return:
    """
    conf = file_utils.load_config(config.CONF_FILE_PATH)
    post_tool_screen_alert = conf[config.POST_TOOL_ALERT]

    if post_tool_screen_alert != '':

        data = {
            'KEY': config.POST_TOOL_ALERT,
            'DESCRIPTION': post_tool_screen_alert,
            'STATS': {
                'MESSAGE': post_tool_screen_alert,
                'DESCRIPTION': config.POST_TOOL_ALERT_DESCRIPTION
            }
        }

        logging.info('Post Tool Alert details %s : ', data)

        response = pulse_client.post(path=config.POST_RESTART_CHECKS_END_POINT, body=data)

        if response.get('dedicated').status_code == 200:
            file_utils.update_conf_file(
                config.CONF_FILE_PATH,
                config.POST_TOOL_ALERT,
                ''
            )
    else:
        logging.info("No Post Tool Alert")


def process_pulse_data():
    """
    This is the main method to get all pulse related data from pos
    """
    logging.debug('Initiating processing pulse data')

    try:
        os_xorg_version = system_stats.get_os_xorg_version()
        os_ctd = system_stats.ctd_status()

        logging.debug('CTD new version: %s, XORG new version: %s', os_ctd, os_xorg_version)

        daily_stats = get_daily_stats()

        logging.info("Sending daily data to pulse: %s", json_utils.get_pretty_json(daily_stats))

        response = pulse_client.post(config.UPDATE_END_POINT, body=daily_stats)

        if response.get('dedicated').status_code == 200:
            file_utils.update_statistics(os_xorg_version, os_ctd)
        else:
            logging.error('Daily stats is not posted, response: %s',
                          response.get('dedicated').status_code)

        logging.debug('Daily stats processing is completed')

    except Exception as exception:
        logging.error('Error while sending daily stats: %s', exception)


def get_daily_stats():
    """
    Get daily status
    :return:
    """
    try:
        data = dict(
            AGENT_VERSION=config.VERSION,
            MERCHANT_NAME=cinco_identity.get_merchant_name(),
            POS_VERSION=cinco_identity.get_cinco_version().strip('"'),
            BUILD_ENV=pos_config_manager.get_pos_build_env(),
            CPU_TYPE=system_stats.get_processor_architecture(),
            DISKS_PARTITIONS=system_stats.get_disk_partitions('sda'),
            NETWORK_INTERFACES=network.get_network_interfaces(),
            NETWORK_HOSTNAME=network.get_hostname(),
            NETWORK_CARD=network.get_network_data('name'),
            NETWORK_GATEWAY=network.get_default_gateway(),
            NETWORK_PUBLIC_IP=network.get_public_ip(),
            NETWORK_LOCAL_IP=network.get_network_data('ip'),
            NETWORK_MASK=network.get_network_data('mask'),
            SYSTEM_UPTIME=system_stats.get_system_uptime(),
            CTD_STATUS=str(system_stats.ctd_status()),
            KERNEL=system_stats.get_kernel_version(),
            DISTRIBUTION=system_stats.get_distribution_name(),
            JAVA=system_stats.get_java_version(),
            COUCHDB=couch.get_couchdb_version(),
            PYTHON=system_stats.get_python_version(),
            XORG_VERSION=system_stats.get_os_xorg_version(),
            MAC=network.get_network_data('mac'),
            HD_BAD_SECTORS_INFO=system_stats.get_hard_disk_bad_sectors_info(),
            IMAGE_VERSION=cinco_identity.get_image_version(),
            SERIAL_NUMBER=system_stats.get_serial_number(),
            DEVICE_TYPE=system_stats.get_device_type(),
            HD_MODEL=system_stats.get_hard_disk_model(),
            REBOOT_TIME=restarts.get_reboot_time(),
            AVERAGE_TRANSACTION_TIME=payments.get_average_transaction_time())
        return data

    except Exception as exception:
        logging.error("Error while getting daily stats: %s", exception)
        return config.ERROR_MESSAGE


def generate_time_not_synced_alert():
    """
    # generate an alert if the pos time is not synced with actual timezone
    :return:
    """
    try:
        logging.info("[POS TIME AND ACTUAL TIME] START CHECKING")

        time_not_synced, description = moxy.is_time_not_synchronized()
        if time_not_synced:
            data = {
                'KEY': config.TIME_NOT_SYNCED,
                'DESCRIPTION': description,
                'STATS': None
            }

            logging.info("Sending time sync data: %s", json_utils.get_pretty_json(data))

            pulse_client.post(config.POST_RESTART_CHECKS_END_POINT, body=data)
        else:
            logging.debug('[POS TIME AND ACTUAL TIME] Time is synced as expected')

    except Exception as exception:
        logging.exception("Error while checking time synchronization: %s", exception)


def detect_anomalies_occurred_yesterday():
    """
    detect the anomalies occurred during yesterday
    :return:
    """
    try:
        logging.info("Detecting anomalies occurred during yesterday")
        """
        detect unique anomalies from both rolled back logs and active log
        update 'flag=1' when 'Traceback' is found
        then keep appending each line to 'str_builder'
        when 'ERROR|WARN|INFO|DEBUG' is found
        stop appending to 'str_builder' and update 'flag=2'
        finally print the 'str_builder' to output
        revert back 'flag=0'
        """

        yesterday = str(datetime.date.today() - datetime.timedelta(1))
        space_delimiter = '" "'
        erase_delimiter = '""'
        anomaly_separate_delimiter = "^_^"

        # pylint:disable=anomalous-backslash-in-string
        anomaly_detect_command = "gzip -dcf %s | awk -v separator='^_^' '/Traceback/" \
                                 "{flag = 1; str_builder = prv_line%s$0; next} " \
                                 "/\[ERROR\]|\[WARN\]|\[INFO\]|\[DEBUG\]/{if(flag == 1) flag = 2;}" \
                                 "{$2 = %s; prv_line = $0; if(flag == 1){ str_builder = str_builder%s$0;} " \
                                 "if(flag==2){ print str_builder%sseparator; flag=0;}}' | grep %s | sort -u" \
                                 % (config.LP_PULSE_LOG_FILES, space_delimiter, erase_delimiter,
                                    space_delimiter,
                                    space_delimiter, yesterday)

        logging.debug("Anomaly detecting command: %s", anomaly_detect_command)
        anomalies = sub_process.p_open_stripped(anomaly_detect_command)

        if anomalies != "":
            anomalies = anomalies.split(anomaly_separate_delimiter)
            anomalies = anomalies[:-1]  # leave out the last separator character
            date_erased_anomaly_list = []

            """
            following regex is used to remove color codes from logs
            ANSI escape sequence is used
            """
            ansi_escape = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -/]*[@-~]')

            """
            date is removed from every anomaly
            so that we can identify the same anomaly over different days as a unique one
            """
            for anomaly in anomalies:
                unicode_escaped_anomaly = anomaly.decode('unicode_escape')
                ansi_escaped_anomaly = ansi_escape.sub('', unicode_escaped_anomaly)
                date_erased_anomaly = ansi_escaped_anomaly.split('  ', 1)[
                    1]  # set two spaces purposefully
                date_erased_anomaly_list.append(date_erased_anomaly)

            data = {
                'ANOMALIES': date_erased_anomaly_list,
                'DATE': yesterday
            }
            logging.info("Sending detected anomalies data")
            pulse_client.post(config.ANOMALIES_END_POINT, body=data)

        else:
            logging.info("No anomalies found")

    except Exception as exception:
        logging.exception("Error while detecting anomalies occurred during yesterday: %s",
                          exception)
