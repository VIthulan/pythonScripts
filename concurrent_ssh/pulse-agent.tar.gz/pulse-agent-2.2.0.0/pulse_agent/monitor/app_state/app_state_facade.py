"""
This module will send app state to Pulse API
"""
import logging

from pulse_agent.services.moxy import moxy
from pulse_agent.services.couch import couch
from pulse_agent.services.chrome import chrome
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils.config import config


class PosAppStateChecker(object):
    """
    Pos App state checker related attributes and methods
    """

    def __init__(self):
        self.is_running = False
        self.pos_app_states = {'MOXY_STATE': "", 'COUCH_STATE': "", 'CHROME_STATE': ""}
        self.update_sent_successful = False

    def check_app_states(self):
        """
        Check App state method which responds to pulse API
        """
        MOXY_STATE = "MOXY_STATE"
        COUCH_STATE = "COUCH_STATE"
        CHROME_STATE = "CHROME_STATE"

        should_sent_update_to_api = False
        states = {}

        moxy_state = moxy.is_moxy_running()
        if self.pos_app_states.get(MOXY_STATE) != moxy_state:
            should_sent_update_to_api = True
            self.pos_app_states[MOXY_STATE] = moxy_state
            states[MOXY_STATE] = moxy_state

        couch_state = couch.is_couch_running()
        if self.pos_app_states.get(COUCH_STATE) != couch_state:
            should_sent_update_to_api = True
            self.pos_app_states[COUCH_STATE] = couch_state
            states[COUCH_STATE] = couch_state

        chrome_state = chrome.is_chrome_running()
        if self.pos_app_states.get(CHROME_STATE) != chrome_state:
            should_sent_update_to_api = True
            self.pos_app_states[CHROME_STATE] = chrome_state
            states[CHROME_STATE] = chrome_state

        if should_sent_update_to_api is False and self.update_sent_successful is False:
            should_sent_update_to_api = True
            states = self.pos_app_states.copy()

        if should_sent_update_to_api is True:

            try:
                response = pulse_client.post(config.APP_STATE_CHECK_ENDPOINT, body=states)

                if response.get('dedicated').status_code == 200:
                    logging.info('Successfully sent Pos App state to API: %s', states)
                    self.update_sent_successful = True
                else:
                    logging.error('Error while sending App state to API: %s', states)
                    self.update_sent_successful = False
            except Exception as exception:
                logging.exception('Exception while sending app state to API: %s', exception)
                self.update_sent_successful = False


app_state_checker = PosAppStateChecker()
