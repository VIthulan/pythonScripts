"""
Test cases for app_state_facade module
"""

# core modules
import logging
import mock

# testing module
from pulse_agent.monitor.app_state.app_state_facade import app_state_checker

from dtos import Response

logging.basicConfig(level=logging.FATAL)


def setup_module(mdl):
    """ setup_module """
    log = logging.getLogger('setup_module')
    log.debug("setup_module module:%s", mdl.__name__)


def teardown_module(mdl):
    """ teardown_module """
    log = logging.getLogger('teardown_module')
    log.debug("teardown_module module:%s", mdl.__name__)


def setup_function(func):
    """ setup_function """
    logging.info("setup_function function:%s", func.__name__)


def teardown_function(func):
    """ teardown_function """
    log = logging.getLogger('teardown_function')
    log.debug("teardown_function function:%s", func.__name__)


@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
@mock.patch('pulse_agent.services.chrome.chrome.is_chrome_running')
@mock.patch('pulse_agent.services.couch.couch.is_couch_running')
@mock.patch('pulse_agent.services.moxy.moxy.is_moxy_running')
def test_check_app_states(
        mock_is_moxy_running,
        mock_is_couch_running,
        mock_is_chrome_running,
        mock_rest_client_post):
    """
    Test for check app state
    :param mock_is_moxy_running: magic mock object of is_moxy_running method
    :param mock_is_couch_running: magic mock object of is_couch_running method
    :param mock_is_chrome_running: magic mock of is_chrome_running method
    :param mock_rest_client_post: magic mock of rest_client's post method
    :return: None
    """


    # When process is unsuccessful
    the_response1 = Response()
    the_response1.code = "expired"
    the_response1.error_type = "expired"
    the_response1.status_code = 400
    the_response1._content = b'{ "key" : "a" }'

    mock_is_moxy_running.return_value = False
    mock_is_couch_running.return_value = False
    mock_is_chrome_running.return_value = False
    mock_rest_client_post.return_value = the_response1

    app_state_checker.check_app_states()

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'MOXY_STATE': False,
            'COUCH_STATE': False,
            'MERCHANT_ID': None,
            'CHROME_STATE': False},
        path='/api/v1/pos/appStateUpdate'
    )

    assert not app_state_checker.update_sent_successful

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200
    the_response._content = b'{ "key" : "a" }'

    mock_rest_client_post.return_value = the_response

    # Initial State
    mock_is_moxy_running.return_value = False
    mock_is_couch_running.return_value = False
    mock_is_chrome_running.return_value = False

    app_state_checker.check_app_states()

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'MERCHANT_ID': None,
            'MOXY_STATE': False,
            'COUCH_STATE': False,
            'CHROME_STATE': False
        },
        path='/api/v1/pos/appStateUpdate'
    )

    assert app_state_checker.update_sent_successful

    # When moxy is running
    mock_is_moxy_running.return_value = True
    mock_is_couch_running.return_value = False
    mock_is_chrome_running.return_value = False

    app_state_checker.check_app_states()

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'MOXY_STATE': True,
            'MERCHANT_ID': None},
        path='/api/v1/pos/appStateUpdate'
    )

    assert app_state_checker.update_sent_successful

    # When couch is running
    mock_is_moxy_running.return_value = False
    mock_is_couch_running.return_value = True
    mock_is_chrome_running.return_value = False

    app_state_checker.check_app_states()

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'MOXY_STATE': False,
            'COUCH_STATE': True,
            'MERCHANT_ID': None
        },
        path='/api/v1/pos/appStateUpdate'
    )

    assert app_state_checker.update_sent_successful

    # When chrome is running
    mock_is_moxy_running.return_value = False
    mock_is_couch_running.return_value = False
    mock_is_chrome_running.return_value = True

    app_state_checker.check_app_states()

    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'COUCH_STATE': False,
            'MERCHANT_ID': None,
            'CHROME_STATE': True},
        path='/api/v1/pos/appStateUpdate'
    )

    assert app_state_checker.update_sent_successful
