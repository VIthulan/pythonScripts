"""
This Modules handles class and functions about system stats
"""
import logging
import multiprocessing
import os
from HTMLParser import HTMLParser
import platform
import subprocess
from pulse_agent.utils.decorators.try_except import try_except
from pulse_agent.utils.decorators.skip_upgrade_window import skip_upgrade_window
from pulse_agent.services.chrome import chrome
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config


class SystemStats(object):
    """
    Methods and attributes related to System stats
    """

    def __init__(self):
        self.black_screen_check_count = {'dedicated': 0, 'dev': 0}

    # -----------------------------------------------------------------------------
    # cpu / processor
    # -----------------------------------------------------------------------------

    def get_cpu_load(self):
        """ returns the CPU load averages for the last 5, 10, and 15 minutes. """
        loadavg = os.popen('cat /proc/loadavg').read().split()
        return dict(load5=loadavg[config.CPU_LOAD5], load10=loadavg[config.CPU_LOAD10],
                    load15=loadavg[config.CPU_LOAD15])

    def get_cpu_count(self):
        """ returns the number of CPUs installed on the system. """
        return multiprocessing.cpu_count()

    def get_processor_architecture(self):
        """ returns the bit architecture of the processor. """
        return platform.architecture()[config.CPU_BITS]

    # ----------------------------------------------------------------------------
    # disks / storage
    # ----------------------------------------------------------------------------

    def get_disk_partitions(self, diskname='sda'):
        """
        returns all of the disk partitions that are mounted on the system.

        :return:    dict
        """
        partitions = []

        for partition in os.popen('df -m').read().split('\n'):
            if partition.startswith('/dev/%s' % diskname):
                details = partition.split()

                partitions.append({
                    'name': details[config.PARTIION_NAME],
                    'used': details[config.PARTITION_USED],
                    'avail': details[config.PARTITION_AVAILABE],
                    'mount': details[config.PARTITION_MOUNT_POINT],
                    'total': int(details[config.PARTITION_USED]) + int(
                        details[config.PARTITION_AVAILABE])
                })

        return partitions

    def get_free_disk_space(self, disk_name='sda'):
        """
        return free disk space in bytes, or error if /dev/sda is missing
        :param disk_name:
        :return: Free disk space in bytes
        """
        size = 0
        error = 'NULL'
        try:
            # df -k return disk space in KB
            for partition in os.popen('df -k').read().split('\n'):
                if partition.startswith('/dev/%s' % disk_name):
                    details = partition.split()
                    # 4th column has the disk availability data, take it and convert to Bytes
                    size = int(details[3]) * 1024
                    logging.info('Free hard disk space: %s KB', int(details[3]))
                    return dict(
                        SIZE=size,
                        ERROR=error
                    )
            logging.error('Error while get free hard disk space: /dev/sda is not found')
            error = '/dev/sda is not found'
            return dict(
                SIZE=size,
                ERROR=error
            )
        except Exception as exception:
            logging.exception("Error while calculating free HD space: %s", exception)
            return dict(
                SIZE=size,
                ERROR=exception
            )

    def get_hard_disk_model(self):
        """
        get_hard_disk_model
        :return:
        """

        try:
            if self.get_device_type() == 'DATAVAN':
                return 'Transcend SSD'

            is_smart_enabled = sub_process.p_open_stripped(
                "dpkg --get-selections| grep 'smartmontools'")
            if is_smart_enabled == '':
                return config.ERROR_MESSAGE

            logging.debug('OK smartmontools is installed')
            hd_model_command = "smartctl -i /dev/sda | grep -e 'Device Model:'| cut -d ':' -f 2"
            hd_model = sub_process.p_open_stripped(hd_model_command)

            logging.debug("Hard Disk Model: %s", hd_model)

            return hd_model

        except Exception as exception:
            logging.exception('Error while getting hard disk model: %s', exception)
            return config.ERROR_MESSAGE

    def get_hard_disk_bad_sectors_info(self):
        """
        # Check Hard Disk bad sectors
        :return:
        """

        try:
            is_smart_enabled = sub_process.p_open_stripped(
                "dpkg --get-selections| grep 'smartmontools'")
            if is_smart_enabled == '':
                return config.ERROR_MESSAGE

            logging.debug('OK smartmontools is installed')
            # getting if bad sectors
            hd_bad_sectors_command = ("smartctl -A /dev/sda|grep -e 'ATTRIBUTE_NAME' -e "
                                      "'Reallocated_Sector_Ct' -e '"
                                      "Current_Pending_Sector' -e "
                                      "'Offline_Uncorrectable' -e "
                                      "'Pre-fail' -e "
                                      "'Power_On_Hours' -e "
                                      "'Temperature_Celsius' -e "
                                      "'G-Sense_Error_Rate'"
                                      "|awk '{print $2,$4,$5,$6,$7,$10;}'| tr '\n' ';'")

            hd_bad_sectors = sub_process.p_open_stripped(hd_bad_sectors_command)
            logging.debug("Hard Disk Bad Sectors: %s", hd_bad_sectors)
            return hd_bad_sectors

        except Exception as exception:
            logging.exception('Error while getting hd bad sector info: %s', exception)
            return config.ERROR_MESSAGE

    # -----------------------------------------------------------------------------
    # memory
    # -----------------------------------------------------------------------------

    def get_free_memory(self):
        """ returns the amount of free/usable memory, in megabytes. """
        return int(os.popen('grep "MemFree" /proc/meminfo').read().split()[1]) / 1024

    def get_buffered_memory(self):
        """ returns the amount of buffered memory, in megabytes. """
        return int(os.popen('grep "Buffers" /proc/meminfo').read().split()[1]) / 1024

    def get_cached_memory(self):
        """ returns the amount of cached memory, in megabytes. """
        return int(os.popen('grep "Cached" /proc/meminfo').read().split()[1]) / 1024

    def get_total_memory(self):
        """ returns the total amount of memory, in megabytes. """
        return int(os.popen('grep "MemTotal" /proc/meminfo').read().split()[1]) / 1024

    # -----------------------------------------------------------------------------
    # system / os
    # -----------------------------------------------------------------------------

    def get_system_uptime(self):
        """ returns the number of seconds since the system booted last. """
        uptime = sub_process.p_open_no_shell('cat /proc/uptime'.split())
        out, err = uptime.communicate()
        if err:
            logging.error(err)
            return ''
        return out.split()[0]

    def get_device_type(self):
        """
        Get device type
        :return: device type
        """
        try:
            command = 'cincoinfo | grep "HARDWARE" | cut -d ":" -f 2'

            logging.debug(command)
            device_type = sub_process.p_open_stripped(command)
            logging.info("Device Type %s", str(device_type))
            return str(device_type)
        except Exception as exception:
            logging.exception('Error while getting the manufacturer: %s', exception)
            return config.ERROR_MESSAGE

    def get_distribution_name(self):
        """ returns a string representing the Linux distribution. """
        return "%s %s (%s)" % platform.linux_distribution(distname="Uknown", version="Linux",
                                                          id="Unknown")

    def get_kernel_version(self):
        """ returns the current running version of the Linux kernel. """
        UNAME_RELEASE = 2
        return platform.uname()[UNAME_RELEASE]

    def get_java_version(self):
        """ returns the version of Java installed on the system. """
        java = sub_process.p_open_default('java -version'.split(), stderr=subprocess.PIPE)
        out, err = java.communicate()

        return err.split('\n')[0].split('"')[1]

    def get_python_version(self):
        """ returns the version of Python installed on the system. """
        return platform.python_version()

    def get_master_details(self):
        """
        Get master details
        :return: Master details
        """
        master_details = dict()

        try:
            # Check whether static master enabled
            is_static_master_command = ("grep -o isStaticSetupEnabled.* "
                                        "/home/leapset/cinco/logs/moxy.log "
                                        "| tail -1 | cut -d ':' -f 2")
            logging.debug(is_static_master_command)
            is_static_master_enabled = sub_process.p_open_stripped(is_static_master_command)
            logging.debug('is static master enabled : %s ', is_static_master_enabled)

            if is_static_master_enabled != '':
                if is_static_master_enabled == 'true':
                    master_details['is.static.setup'] = 'true'
                else:
                    master_details['is.static.setup'] = 'false'
            else:
                master_details['is.static.setup'] = ''

            # Check ip of the master
            get_master_ip_command = ("grep -o 'data request to master'.* "
                                     "/home/leapset/cinco/logs/moxy.log "
                                     "| tail -1 | grep -o 'http://'.* "
                                     "| cut -d '/' -f 3 | cut -d ':' -f 1")
            logging.debug(get_master_ip_command)
            master_ip = sub_process.p_open_stripped(get_master_ip_command)
            logging.info('master is: %s ', master_ip)

            master_details["master.device.ip"] = master_ip

            if master_ip != '':
                if master_ip == 'localhost':
                    master_details['is.master'] = 'true'
                else:
                    master_details['is.master'] = 'false'
            else:
                master_details['is.master'] = ''

            master_details["is.master.online"] = ''

        except Exception as exception:
            logging.exception(
                "Error: Error reading static/dynamic master related data: %s", exception)

        return master_details

    def get_os_xorg_version(self):
        """
        get xorg version from the os
        :return: String xorg version
        """
        try:
            xorg_data = os.popen('script -c "X -version" | grep "X.Org X Server"')
            data = xorg_data.read()
            data = data.replace('X.Org X Server ', '')
            data = data.strip('\n').strip('\r')

            return data
        except Exception as exception:
            logging.exception('Error while geting the xorg version from OS: %s', exception)
            return ''

    @try_except(level='exception', default=False)
    def ctd_status(self):
        """ returns whether the machine has a CTD (Customer Touch Display) attached. """
        xrandr = sub_process.p_open_default('xrandr -display :0.0 -q'.split(),
                                            stdout=subprocess.PIPE)
        out, err = xrandr.communicate()
        if err:
            logging.error('Error while getting ctd status: %s', err)
            return False

        return 'VGA1 connected' in out

    @try_except(level='exception', default=None)
    def get_serial_number(self):
        """ get serial number"""
        command = 'dmidecode -t system | grep "Serial Number" | cut -d ":" -f 2'
        logging.debug(command)
        serial_number = sub_process.p_open_stripped(command)
        logging.info("Version number %s", str(serial_number))
        return str(serial_number)

    @try_except(level='exception', default=None)
    def is_post_tool_running(self):
        """ Checks whether post tool is running"""
        command = 'ps -ef|grep [p]ost.sh'
        logging.debug(command)
        result = sub_process.p_open_stripped(command)
        logging.info("Is post tool running result %s", str(result))
        if result:
            return True
        return False

    @try_except(level='exception', default=None)
    def get_post_tool_screen_alert(self):
        """ Gets the post tool screen alert"""
        parser = MyHTMLParser()
        command = "ps -ef|grep [z]enity|awk -F '--text' '{ print $2 }'"
        logging.debug(command)
        result = sub_process.p_open_stripped(command)
        logging.info("Is post tool running result %s", str(result))
        if result:
            parser.feed(result)
            logging.debug("Post tool alert message %s", str(parser.read_arr()[0]))
            return parser.read_arr()[0]
        return None

    @skip_upgrade_window()
    def is_black_screen_occurred(self, env):
        """
        Checks whether if black screen is occurred
        :param env: environment
        :return: State
        """
        try:
            if self.black_screen_check_count[env] > 10:
                logging.debug('[BLACK_SCREEN_CHECK] black screen check begins %s',
                              str(self.black_screen_check_count))
                if chrome.is_chrome_running() == 'NOT_RUNNING' and not self.is_post_tool_running():
                    return "POS_BLACK_SCREEN_OCCURRED"
                return ""

            logging.debug('[BLACK_SCREEN_CHECK] black screen backed off %s',
                          str(self.black_screen_check_count))
            self.black_screen_check_count[env] = self.black_screen_check_count[env] + 1
            return ""
        except Exception as exception:
            logging.exception("Error while checking is black screen occurred: %s", exception)
            return ""


class MyHTMLParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.arr = []

    def handle_data(self, data):
        self.arr.append(data)

    def read_arr(self):
        return self.arr


system_stats = SystemStats()
