"""
tests for system_stats module
"""
# core modules
import logging
import subprocess
import mock
from mock import Mock

# testing module
from pulse_agent.monitor.system_stats.system_stats import system_stats

# helper
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


@mock.patch('os.popen')
def test_get_cpu_load(mock_popen):
    """
    test get_cpu_load()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    cpu_loads = '0.58 1.10 1.26 2/835 24901\n'
    mock_popen.return_value = Mock(read=Mock(return_value=cpu_loads))

    assert system_stats.get_cpu_load() == {
        'load5': '0.58',
        'load10': '1.10',
        'load15': '1.26'
    }
    assert mock_popen.mock_calls == [mock.call('cat /proc/loadavg'), mock.call().read()]


@mock.patch('multiprocessing.cpu_count')
def test_get_cpu_count(mock_cpu_count):
    """
    test get_cpu_count()
    :param mock_cpu_count: mock call to multiprocessing.cpu_count()
    """
    # checks whether it works as expected
    mock_cpu_count.return_value = 4
    assert system_stats.get_cpu_count() == 4
    assert mock_cpu_count.mock_calls == [mock.call()]


@mock.patch('platform.architecture')
def test_get_processor_architecture(mock_architecture):
    """
    test get_processor_architecture()
    :param mock_architecture: mock call to platform.architecture()
    """
    # checks whether it works as expected
    mock_architecture.return_value = ['64-bit']
    assert system_stats.get_processor_architecture() == '64-bit'
    assert mock_architecture.mock_calls == [mock.call()]


@mock.patch('os.popen')
def test_get_disk_partitions(mock_popen):
    """
    test get_disk_partitions()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    partitions = '/dev/opt hdd 100 200 mount-point opt\n/dev/sda1 hdd 10 20 mount-point dev'
    mock_popen.return_value = Mock(read=Mock(return_value=partitions))
    assert system_stats.get_disk_partitions() == [
        {
            'name': '/dev/sda1',
            'used': '10',
            'avail': '20',
            'mount': 'dev',
            'total': 30
        }
    ]
    assert mock_popen.mock_calls == [mock.call('df -m'), mock.call().read()]


@mock.patch('os.popen')
def test_get_free_disk_space(mock_popen):
    """
    test get_free_disk_space()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected if the /dev/sda is available
    partitions = '/dev/opt hdd 100 200 mount-point opt\n/dev/sda1 hdd 10 20 mount-point dev'
    mock_popen.return_value = Mock(read=Mock(return_value=partitions))
    assert system_stats.get_free_disk_space() == {
        'SIZE': 1024 * 20,
        'ERROR': 'NULL'
    }
    assert mock_popen.mock_calls == [mock.call('df -k'), mock.call().read()]

    # checks whether it works as expected if /dev/sda isn't available
    partitions = '/dev/opt hdd 100 200 mount-point opt\n/dev/media hdd 10 20 mount-point dev'
    mock_popen.return_value = Mock(read=Mock(return_value=partitions))
    assert system_stats.get_free_disk_space() == {
        'SIZE': 0,
        'ERROR': '/dev/sda is not found'
    }

    # checks whether it handles exceptions properly
    mock_popen.side_effect = Exception
    try:
        system_stats.get_free_disk_space()
        assert False
    except Exception:
        assert True


@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_device_type')
@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_hard_disk_model(mock_p_open_stripped, mock_get_device_type):
    """
    test get_hard_disk_model()
    :param mock_p_open_stripped: mock call to sub_process.p_open_stripped()
    :param mock_get_device_type: mock call to system_stats.get_device_type()
    """
    # checks whether it works as expected if device is DATAVAN
    mock_get_device_type.return_value = 'DATAVAN'
    mock_p_open_stripped.return_value = ''
    assert system_stats.get_hard_disk_model() == 'Transcend SSD'

    # checks whether it works as expected if smartmon isn't installed and device isn't DATAVAN
    mock_get_device_type.return_value = 'POINDUS'
    mock_p_open_stripped.return_value = ''
    assert system_stats.get_hard_disk_model() == config.ERROR_MESSAGE

    # checks whether it works as expected if smartmon is installed and device isn't DATAVAN
    mock_p_open_stripped.reset_mock()
    mock_get_device_type.return_value = 'POINDUS'
    mock_p_open_stripped.side_effect = ['installed', 'SeaGate-2']
    assert system_stats.get_hard_disk_model() == 'SeaGate-2'
    assert mock_p_open_stripped.mock_calls == [
        mock.call("dpkg --get-selections| grep 'smartmontools'"),
        mock.call("smartctl -i /dev/sda | grep -e 'Device Model:'| cut -d ':' -f 2")
    ]

    # checks whether it handles exceptions properly
    mock_get_device_type.side_effect = Exception
    assert system_stats.get_hard_disk_model() == config.ERROR_MESSAGE


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_hard_disk_bad_sectors_info(mock_p_open_stripped):
    """
    test get_hard_disk_bad_sectors_info()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if smartmon isn't installed
    mock_p_open_stripped.return_value = ''
    assert system_stats.get_hard_disk_bad_sectors_info() == config.ERROR_MESSAGE

    # checks whether it works as expected if smartmon is installed
    mock_p_open_stripped.side_effect = ['installed', 'many bad sectors']
    assert system_stats.get_hard_disk_bad_sectors_info() == 'many bad sectors'

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert system_stats.get_hard_disk_bad_sectors_info() == config.ERROR_MESSAGE


@mock.patch('os.popen')
def test_get_free_memory(mock_popen):
    """
    test get_free_memory()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(read=Mock(return_value='1000 2000'))
    assert system_stats.get_free_memory() == 2000 / 1024
    assert mock_popen.mock_calls == [mock.call('grep "MemFree" /proc/meminfo'), mock.call().read()]


@mock.patch('os.popen')
def test_get_buffered_memory(mock_popen):
    """
    test get_buffered_memory()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(read=Mock(return_value='1000 3000'))
    assert system_stats.get_buffered_memory() == 3000 / 1024
    assert mock_popen.mock_calls == [mock.call('grep "Buffers" /proc/meminfo'), mock.call().read()]


@mock.patch('os.popen')
def test_get_cached_memory(mock_popen):
    """
    test get_cached_memory()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(read=Mock(return_value='1000 4000'))
    assert system_stats.get_cached_memory() == 4000 / 1024
    assert mock_popen.mock_calls == [mock.call('grep "Cached" /proc/meminfo'), mock.call().read()]


@mock.patch('os.popen')
def test_get_total_memory(mock_popen):
    """
    test get_total_memory()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected
    mock_popen.return_value = Mock(read=Mock(return_value='1000 5000'))
    assert system_stats.get_total_memory() == 5000 / 1024
    assert mock_popen.mock_calls == [mock.call('grep "MemTotal" /proc/meminfo'), mock.call().read()]


@mock.patch('pulse_agent.utils.sub_process.p_open_no_shell')
def test_get_system_uptime(mock_p_open_no_shell):
    """
    test get_system_uptime()
    :param mock_p_open_no_shell: mock call to pulse_agent.utils.sub_process.p_open_default()
    """
    # checks whether it works as expected if error occurs
    mock_p_open_no_shell.return_value = Mock(communicate=Mock(return_value=('100 since someday', 'error')))
    assert system_stats.get_system_uptime() == ''
    assert mock_p_open_no_shell.mock_calls == [
        mock.call('cat /proc/uptime'.split()),
        mock.call().communicate()
    ]

    # checks whether it works as expected if no error occurs
    mock_p_open_no_shell.return_value = Mock(communicate=Mock(return_value=('100 since someday', None)))
    assert system_stats.get_system_uptime() == '100'


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_device_type(mock_p_open_stripped):
    """
    test get_device_type()
    :param mock_p_open_stripped: mock call to sub_process.p_open_stripped()
    """
    # checks whether it works as expected
    mock_p_open_stripped.return_value = 'DATAVAN'
    assert system_stats.get_device_type() == 'DATAVAN'
    assert mock_p_open_stripped.mock_calls == [mock.call('cincoinfo | grep "HARDWARE" | cut -d ":" -f 2')]

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert system_stats.get_device_type() == config.ERROR_MESSAGE


@mock.patch('platform.linux_distribution')
def test_get_distribution_name(mock_linux_distribution):
    """
    test get_distribution_name()
    :param mock_linux_distribution: mock call to platform.linux_distribution()
    """
    # checks whether it works as expected if 
    mock_linux_distribution.return_value = 'debian', 'ubuntu', '16.0'
    assert system_stats.get_distribution_name() == 'debian ubuntu (16.0)'
    assert mock_linux_distribution.mock_calls == [mock.call(distname="Uknown", version="Linux",
                                                            id="Unknown")]


@mock.patch('platform.uname')
def test_get_kernel_version(mock_uname):
    """
    test get_kernel_version()
    :param mock_uname: mock call to platform.uname()
    """
    # checks whether it works as expected if
    mock_uname.return_value = ['debian', 'ubuntu', '16.4']
    assert system_stats.get_kernel_version() == '16.4'


@mock.patch('platform.python_version')
def test_get_python_version(mock_python_version):
    """
    test get_python_version()
    :param mock_python_version: mock call to platform.python_version()
    """
    # checks whether it works as expected if
    mock_python_version.return_value = '2.7'
    assert system_stats.get_python_version() == '2.7'


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_master_details(mock_p_open_stripped):
    """
    test get_master_details()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if static master is enabled
    mock_p_open_stripped.side_effect = ['true', 'localhost']
    assert system_stats.get_master_details() == {
        'is.static.setup': 'true',
        'master.device.ip': 'localhost',
        'is.master': 'true',
        'is.master.online': ''
    }
    assert mock_p_open_stripped.mock_calls == [
        mock.call("grep -o isStaticSetupEnabled.* /home/leapset/cinco/logs/moxy.log | tail -1 | cut -d ':' -f 2"),
        mock.call(
            "grep -o 'data request to master'.* /home/leapset/cinco/logs/moxy.log | tail -1 | grep -o 'http://'.*"
            " | cut -d '/' -f 3 | cut -d ':' -f 1")
    ]

    # checks whether it works as expected if static master is not enabled
    mock_p_open_stripped.side_effect = ['', '']
    assert system_stats.get_master_details() == {
        'is.static.setup': '',
        'master.device.ip': '',
        'is.master': '',
        'is.master.online': ''
    }

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert system_stats.get_master_details() == {}


@mock.patch('os.popen')
def test_get_os_xorg_version(mock_popen):
    """
    test get_os_xorg_version()
    :param mock_popen: mock call to os.popen()
    """
    # checks whether it works as expected if
    mock_popen.return_value = Mock(read=Mock(return_value='X.Org X Server 10.2\n'))
    assert system_stats.get_os_xorg_version() == '10.2'

    # checks whether it handles exceptions properly
    mock_popen.side_effect = Exception
    assert system_stats.get_os_xorg_version() == ''


@mock.patch('pulse_agent.utils.sub_process.p_open_default')
def test_ctd_status(mock_p_open_default):
    """
    test ctd_status()
    :param mock_p_open_default: mock call to pulse_agent.utils.sub_process.p_open_default()
    """
    # checks whether it works as expected if error occurs
    mock_p_open_default.return_value = Mock(communicate=Mock(return_value=({'VGA1 connected': True}, 'error')))
    assert not system_stats.ctd_status()
    assert mock_p_open_default.mock_calls == [
        mock.call('xrandr -display :0.0 -q'.split(), stdout=subprocess.PIPE),
        mock.call().communicate()
    ]

    # checks whether it works as expected if no error occurs
    mock_p_open_default.return_value = Mock(communicate=Mock(return_value=({'VGA1 connected': True}, None)))
    assert system_stats.ctd_status()

    # checks whether it handles exceptions properly
    mock_p_open_default.side_effect = Exception
    assert not system_stats.ctd_status()


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_serial_number(mock_p_open_stripped):
    """
    test get_serial_number()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected if
    mock_p_open_stripped.return_value = '123-456-789'
    assert system_stats.get_serial_number() == '123-456-789'
    assert mock_p_open_stripped.mock_calls == [mock.call('dmidecode -t system | grep "Serial Number" | cut -d ":" -f 2')]

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert system_stats.get_serial_number() is None


@mock.patch('pulse_agent.services.chrome.chrome.is_chrome_running')
def test_is_black_screen_occurred(mock_is_chrome_running, monkeypatch):
    """
    test is_black_screen_occurred()
    :param mock_is_chrome_running: mock call to pulse_agent.services.chrome.chrome.is_chrome_running()
    :param monkeypatch: mock test class variables
    """
    # checks whether it works as expected if chrome is running
    env = 'dedicated'
    monkeypatch.setattr(
        'pulse_agent.monitor.system_stats.system_stats.system_stats.black_screen_check_count',
        {
            env: 15
        }
    )
    mock_is_chrome_running.return_value = 'NOT_RUNNING'
    assert system_stats.is_black_screen_occurred(env) == 'POS_BLACK_SCREEN_OCCURRED'

    # checks whether it works as expected if chrome isn't running
    mock_is_chrome_running.return_value = 'RUNNNING'
    assert system_stats.is_black_screen_occurred(env) == ''

    # checks whether it works as expected if the check count hasn't exceeded
    monkeypatch.setattr(
        'pulse_agent.monitor.system_stats.system_stats.system_stats.black_screen_check_count',
        {
            env: 0
        }
    )
    assert system_stats.is_black_screen_occurred(env) == ''
    assert system_stats.black_screen_check_count[env] == 1

    # checks whether it handles exceptions properly
    monkeypatch.setattr(
        'pulse_agent.monitor.system_stats.system_stats.system_stats.black_screen_check_count',
        {
            env: 15
        }
    )
    mock_is_chrome_running.side_effect = Exception
    assert system_stats.is_black_screen_occurred(env) == ''
