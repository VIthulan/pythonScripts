"""
This facade calls stats other controllers to get required information
"""
import logging

from pulse_agent.monitor.system_stats.system_stats import system_stats
from pulse_agent.monitor.network import network
from pulse_agent.monitor.tunnel.tunnel import tunnel
from pulse_agent.services import cinco_identity
from pulse_agent.services.couch import couch
from pulse_agent.services.moxy import moxy
from pulse_agent.services.chrome import chrome
from pulse_agent.utils.config import config
from pulse_agent.utils import json_utils


class SystemStatsFacade(object):
    """
    SystemStats methods and attributes
    """

    def __init__(self):
        pass

    def gather_stats(self, env):
        """
        Gather stats about pos
        :param env: Production environment
        :return: stats dict
        """
        is_orange_screen = system_stats.is_black_screen_occurred(env)
        if system_stats.is_post_tool_running() is True or is_orange_screen == 'POS_BLACK_SCREEN_OCCURRED':
            is_moxy_running = 'Skipped moxy status checking because of orange screen'
        else:
            is_moxy_running = moxy.is_moxy_running()

        return dict(
            MERCHANT_ID=cinco_identity.get_merchant_id(),
            REGISTER_NO=cinco_identity.get_register_no(),
            CPU_LOAD=system_stats.get_cpu_load(),
            CPU_COUNT=system_stats.get_cpu_count(),
            CPU_TYPE=system_stats.get_processor_architecture(),
            STORAGE=system_stats.get_disk_partitions('sda'),
            FREE_MEMORY=system_stats.get_free_memory(),
            BUFFERED_MEMORY=system_stats.get_buffered_memory(),
            CACHED_MEMORY=system_stats.get_cached_memory(),
            TOTAL_MEMORY=system_stats.get_total_memory(),
            RX=network.get_network_data('rx'),
            TX=network.get_network_data('tx'),
            UPTIME=system_stats.get_system_uptime(),
            TUNNEL_PORT=tunnel.get_tunnel_port(config.SSH_USER, tunnel.get_tunnel_server(env)),
            TUNNEL_TIME=tunnel.get_tunnel_duration(config.SSH_USER, tunnel.get_tunnel_server(env)),
            MERCHANT_NAME=cinco_identity.get_merchant_name(),
            DEVICE_TYPE=system_stats.get_device_type(),
            MASTER_DETAILS=system_stats.get_master_details(),
            MAC=network.get_network_data('mac'),
            IS_MOXY_RUNNING=is_moxy_running,
            COUCHDB_COMPACTIONS=couch.is_couch_compaction_running(),
            BLACK_SCREEN=is_orange_screen,
            ERROR_SELF_REPORT=chrome.get_self_reported_errors().__dict__
        )

    def gather_join_stats(self):
        """
        Gather stats for JOIN message to Pulse environment
        :return: stats dictionary
        """
        try:
            join_me = dict(
                MERCHANT_ID=cinco_identity.get_merchant_id(),
                REGISTER_NO=cinco_identity.get_register_no(),
                MERCHANT_NAME=cinco_identity.get_merchant_name(),
                MASTER_DETAILS=system_stats.get_master_details(),
                MAC=network.get_network_data('mac')
            )
            logging.debug('Requesting to join ws: %s', json_utils.get_json_dump(join_me))
            return join_me
        except Exception as exception:
            logging.exception('Exception while gathering stats for JOIN: %s', exception)


stats_facade = SystemStatsFacade()
