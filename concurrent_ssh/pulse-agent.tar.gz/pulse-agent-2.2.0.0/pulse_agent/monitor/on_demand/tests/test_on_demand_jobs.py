"""
Test cases for on_demand_jobs module
"""

# core modules
import logging
import mock
import time
from mock import mock_open
from mock import Mock

# testing module
from pulse_agent.monitor.on_demand import on_demand_jobs
from pulse_agent.utils.dtos import Response

from pulse_agent.utils.config import config

logging.basicConfig(level=logging.FATAL)


def setup_module(mdl):
    """ setup_module """
    log = logging.getLogger('setup_module')
    log.debug("setup_module module:%s", mdl.__name__)


def teardown_module(mdl):
    """ teardown_module """
    log = logging.getLogger('teardown_module')
    log.debug("teardown_module module:%s", mdl.__name__)


def setup_function(func):
    """ setup_function """
    logging.info("setup_function function:%s", func.__name__)


def teardown_function(func):
    """ teardown_function """
    log = logging.getLogger('teardown_function')
    log.debug("teardown_function function:%s", func.__name__)


@mock.patch('pulse_agent.utils.sub_process.p_open_default')
def test_run_lp_clean(mock_p_open_default):
    """
    Test for test_run_lp_clean
    :param mock_p_open_default: magic mock object of p_open_default method
    :return: None
    """

    # When no message is returned
    message_read = Mock(return_value='message1\nmessage-2\nmessage-3')
    message_stdout = Mock(read=message_read)
    messages = Mock(stdout=message_stdout)

    mock_p_open_default.side_effect = [messages]
    mock_p_open_default.side_effect = [messages]
    assert on_demand_jobs.run_lp_clean() == "message-3"

    # Check if it handles exceptions
    mock_p_open_default.side_effect = Exception

    assert on_demand_jobs.run_lp_clean() == "lp-clean is not installed in this POS"


@mock.patch('pulse_agent.utils.sub_process.p_open_default')
def test_run_lp_resize(mock_p_open_default):
    """
    Test for run_lp_resize
    :param mock_p_open_default: magic mock object of p_open_default method
    :return: None
    """

    # When no message is returned
    message_read = Mock(return_value='message1\nmessage-2\nmessage-3')
    message_stdout = Mock(read=message_read)
    messages = Mock(stdout=message_stdout)

    mock_p_open_default.side_effect = [messages]
    assert on_demand_jobs.run_lp_resize() == "message-3"

    # Check if it handles exceptions
    mock_p_open_default.side_effect = Exception

    assert on_demand_jobs.run_lp_resize() == "lp-resize is not installed in this POS"


@mock.patch('pulse_agent.monitor.on_demand.on_demand_jobs.run_lp_clean')
@mock.patch('pulse_agent.monitor.on_demand.on_demand_jobs.run_lp_resize')
@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_clean_hdd(
        mock_p_open_stripped,
        mock_rest_client_post,
        mock_run_lp_resize,
        mock_run_lp_clean
):
    """
    Test for clean_hdd
    :param mock_rest_client_post: magic mock object of post method
    :param mock_p_open_stripped: magic mock object of p_open_stripped method
    :param mock_run_lp_resize: magic mock object of lp_resize method
    :param mock_run_lp_clean: magic mock object of lp_clean method
    :return: None
    """

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    # When device type is poindus
    mock_p_open_stripped.return_value = "POINDUS"
    mock_run_lp_resize.return_value = "lp_resize_message"
    mock_run_lp_clean.return_value = "lp_clean_message"

    on_demand_jobs.clean_hdd()
    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'CLEAN_CODE_RESP': 'lp_clean_message',
            'RESIZE_CODE_RESP': 'lp_resize_message',
            'MERCHANT_ID': None},
        path='/api/v1/device/cleanHddResponse')

    # When device type is not poindus
    mock_p_open_stripped.return_value = "DEVICE"
    mock_run_lp_resize.return_value = "lp_resize_message"
    mock_run_lp_clean.return_value = "lp_clean_message"

    on_demand_jobs.clean_hdd()
    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'CLEAN_CODE_RESP': 'lp_clean_message',
            'RESIZE_CODE_RESP': "lp-resize not need to execute on DATAVAN devices",
            'MERCHANT_ID': None},
        path='/api/v1/device/cleanHddResponse')

    # Check whether it handles exceptions
    mock_p_open_stripped.return_value = "DEVICE"
    mock_run_lp_resize.return_value = "lp_resize_message"
    mock_run_lp_clean.side_effect = Exception

    on_demand_jobs.clean_hdd()
    mock_rest_client_post.assert_called_with(
        body={
            'REGISTER_NO': None,
            'MERCHANT_ID': None},
        path='/api/v1/device/cleanHddResponse')


@mock.patch('time.sleep')
@mock.patch('pulse_agent.monitor.on_demand.on_demand_jobs.send_debug_script_response')
@mock.patch('pulse_agent.services.moxy.moxy.check_if_moxy_running_after_gdm_restart')
@mock.patch('pulse_agent.utils.sub_process.p_open')
def test_debug_gdm_restart(
        mock_p_open,
        mock_if_moxy_running,
        mock_send_debug_response,
        mock_sleep
):

    """
    Test for debug_gdm_restart
    :param mock_p_open: magic mock object of popen method
    :param mock_if_moxy_running: magic mock object of if_moxy_running method
    :param mock_send_debug_response: magic mock object of send_debug_response method
    :param mock_sleep: magic mock object of sleep method
    :return: None
    """


    # check if it follows the path when Moxy is running
    mock_p_open.return_value = ''
    mock_if_moxy_running.return_value = True
    mock_send_debug_response.return_value = None
    mock_sleep.return_value = None

    on_demand_jobs.debug_gdm_restart("env")
    mock_sleep.assert_called_with(config.THRESHOLD_WAIT_TO_CHECK_MOXY_STATUS)
    mock_send_debug_response.assert_called_with(env='env', message=True)

    # check if it follows the path when Moxy is not running
    mock_p_open.return_value = ''
    mock_if_moxy_running.return_value = False
    mock_send_debug_response.return_value = None
    mock_sleep.return_value = None

    on_demand_jobs.debug_gdm_restart("env")
    mock_sleep.assert_called_with(config.THRESHOLD_WAIT_TO_CHECK_MOXY_STATUS)
    mock_send_debug_response.assert_called_with(env='env', message=False)


@mock.patch('pulse_agent.utils.sub_process.p_open')
def test_debug_futon(
        mock_p_open
):
    """
    Test for debug_gdm_futon
    :param mock_p_open: magic mock object of p_open method
    :return: None
    """

    # check if it follows the path
    mock_p_open.return_value = ''
    on_demand_jobs.debug_futon()
    mock_p_open.assert_called_with(
        "DISPLAY=:0 su -c \"firefox localhost:5984/_utils/ 2>&1 >  /dev/null &\" leapset"
    )


@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
def test_send_debug_script_response(mock_rest_client_post):
    """
    Test for send_debug_script_response
    :param mock_rest_client_post: magic mock object of post method
    :return: None
    """

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    # Check if it follows the path
    on_demand_jobs.send_debug_script_response('dev', 'message')
    mock_rest_client_post.assert_called_with(
        body={
            'REPORT': {
                'DEBUG_MESSAGE': 'message'},
            'REGISTER_NO': None,
            'MERCHANT_ID': None},
        path='/api/v1/device/onDemandDebugExecutionResult')


@mock.patch('pulse_agent.monitor.on_demand.on_demand_jobs.send_debug_script_response')
@mock.patch('pulse_agent.utils.sub_process.p_open')
def test_add_new_couch_user(
        mock_popen,
        mock_send_debug_respose):
    """
    Test for add_new_couch_user
    :param mock_p_open: magic mock object of p_open method
    :param mock_send_debug_respose: magic mock object of send_debug_respose method
    :return: None
    """

    # Check if it follows the path
    mock_popen.return_value = ''
    mock_send_debug_respose.return_value = None
    on_demand_jobs.add_new_couch_user('dev')
    mock_send_debug_respose.assert_called_with('dev', 'Adding Couch User Successful')

    # Check if it handles exceptions
    mock_popen.side_effect = Exception
    mock_send_debug_respose.return_value = None
    on_demand_jobs.add_new_couch_user('dev')
    mock_send_debug_respose.assert_called_with('dev', 'Adding Couch User Unsuccessful')


@mock.patch('pulse_agent.monitor.on_demand.on_demand_jobs.send_debug_script_response')
@mock.patch('pulse_agent.utils.sub_process.p_open')
def test_rename_register(
        mock_popen,
        mock_send_debug_respose):
    """
    Test for rename_register
    :param mock_p_open: magic mock object of p_open method
    :param mock_send_debug_respose: magic mock object of send_debug_respose method
    :return: None
    """

    # Check if it follows the path
    mock_popen.return_value = ''
    mock_send_debug_respose.return_value = None
    on_demand_jobs.rename_register('dev', 'previous_name', 'new_name', 'admin_pass')
    mock_send_debug_respose.assert_called_with('dev', 'Register Rename Successful')

    # Check if it handles exceptions
    mock_popen.side_effect = Exception
    mock_send_debug_respose.return_value = None
    on_demand_jobs.rename_register('dev', 'previous_name', 'new_name', 'admin_pass')
    mock_send_debug_respose.assert_called_with('dev', 'Register Renaming Unsuccessful')


@mock.patch('pulse_agent.monitor.on_demand.on_demand_jobs.get_lp_pulse_state')
@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
@mock.patch('pickle.load')
def test_check_lp_pulse_state_in_peer_registers(
        mock_Load,
        mock_rest_client_post,
        mock_get_lp_pulse_state):
    """
    Test for check_lp_pulse_state_in_peer_registers
    :param mock_Load: magic mock object of load method
    :param mock_rest_client_post: magic mock object of post method
    :param mock_get_lp_pulse_state: magic mock object of get_lp_pulse_state method
    :return: None
    """

    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    # Check if it follows the path
    with mock.patch("__builtin__.open", mock_open(read_data="data")) as mock_file:
        assert open("path/to/open").read() == "data"
        mock_open.return_value = 'File'
        mock_get_lp_pulse_state.return_value = "state"
        mock_Load.return_value = [
            {'DEVICE_TYPE': 'DESKTOP',
             'LOCAL_IP': "IP_01"},
            {'DEVICE_TYPE': 'DESKTOP',
             'LOCAL_IP': "IP_02"}]

        on_demand_jobs.check_lp_pulse_state_in_peer_registers('dev', 'pw')
        mock_rest_client_post.assert_called_with(
            body={
                'STATUS_ARRAY': [
                    {'LP_PULSE_STATUS': 'state',
                     'DEVICE_TYPE': 'DESKTOP',
                     'LOCAL_IP': 'IP_01'},
                    {'LP_PULSE_STATUS': 'state',
                     'DEVICE_TYPE': 'DESKTOP',
                     'LOCAL_IP': 'IP_02'}
                ],
                'REGISTER_NO': None,
                'MERCHANT_ID': None},
            path='/api/v1/network/onDemandLpPulseCheckResult'
        )

    # Check if it handles exceptions
    with mock.patch("__builtin__.open", mock_open(read_data="data")) as mock_file:
        assert open("path/to/open").read() == "data"
        mock_open.return_value = 'File'
        mock_get_lp_pulse_state.side_effect = Exception
        mock_Load.return_value = [
            {'DEVICE_TYPE': 'DESKTOP',
             'LOCAL_IP': "IP_01"},
            {'DEVICE_TYPE': 'DESKTOP',
             'LOCAL_IP': "IP_02"}]
        expected_calles = [
            mock.call(
                body={
                    'STATUS_ARRAY': [
                        {'LP_PULSE_STATUS': 'state',
                         'DEVICE_TYPE': 'DESKTOP',
                         'LOCAL_IP': 'IP_01'},
                        {'LP_PULSE_STATUS': 'state',
                         'DEVICE_TYPE': 'DESKTOP',
                         'LOCAL_IP': 'IP_02'}
                    ],
                    'REGISTER_NO': None,
                    'MERCHANT_ID': None},
                path='/api/v1/network/onDemandLpPulseCheckResult'
            )
        ]

        on_demand_jobs.check_lp_pulse_state_in_peer_registers('dev', 'pw')
        assert mock_rest_client_post.mock_calls == expected_calles


@mock.patch('pexpect.pxssh.pxssh.logout')
@mock.patch('pexpect.pxssh.pxssh.prompt')
@mock.patch('pexpect.pxssh.pxssh.sendline')
@mock.patch('pexpect.pxssh.pxssh.login')
@mock.patch('pulse_agent.monitor.system_stats.system_stats.system_stats.get_distribution_name')
def test_get_lp_pulse_state(
        mock_get_distribution_name,
        mocklogin,
        mock_sendline,
        mock_prompt,
        mock_logout
):
    """
    Test for get_lp_pulse_state
    :param mock_get_distribution_name: magic mock object of get_distribution_name method
    :param mocklogin: magic mock object of login method
    :param mock_sendline: magic mock object of sendline method
    :param mock_prompt: magic mock object of prompt method
    :param mock_logout: magic mock object of logout method
    :return: None
    """

    # When '14.04' is not in os_distribution
    mock_get_distribution_name.return_value = ''
    assert on_demand_jobs.get_lp_pulse_state('server', 'user', 'pw') == config.ERROR_CHECKING_LP_PULSE_STATE

    # When login fails
    mock_get_distribution_name.return_value = '14.04'
    mocklogin.return_value = False
    assert on_demand_jobs.get_lp_pulse_state('server', 'user', 'pw') == config.ERROR_CHECKING_LP_PULSE_STATE
    mock_sendline.assert_not_called()

    # When login is successfull
    mock_get_distribution_name.return_value = '14.04'
    mocklogin.return_value = True
    mock_sendline.return_value = ''
    mock_prompt.return_value = ''
    mock_logout.return_value = ''
    assert on_demand_jobs.get_lp_pulse_state('server', 'user', 'pw') == config.LP_PULSE_INSTALLED


@mock.patch('pulse_agent.utils.sub_process.p_open_default')
@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
def test_save_logs(
        mock_rest_client_post,
        mock_p_open_default):
    """
    Test for save_logs
    :param mock_rest_client_post: magic mock object of post method
    :param mock_p_open_default: magic mock object of p_open_default method
    :return: None
    """


    # When process is successful
    the_response = Response()
    the_response.code = "success"
    the_response.error_type = "success"
    the_response.status_code = 200

    mock_rest_client_post.return_value = the_response

    # Check if the path is followed
    message_read = Mock(return_value='message')
    message_stdout = Mock(read=message_read)
    messages = Mock(stdout=message_stdout)

    mock_p_open_default.side_effect = [messages]
    on_demand_jobs.save_logs('dev')
    mock_rest_client_post.assert_called_with(
        body={
            'STATUS': True,
            'REGISTER_NO': None,
            'MERCHANT_ID': None},
        path='/api/v1/device/saveLogsResponse')

    # Check if it handles exceptions
    mock_p_open_default.side_effect = Exception
    on_demand_jobs.save_logs('dev')
    mock_rest_client_post.assert_called_with(
        body={
            'STATUS': False,
            'REGISTER_NO': None,
            'MERCHANT_ID': None},
        path='/api/v1/device/saveLogsResponse')


@mock.patch('pulse_agent.monitor.on_demand.log_uploader.upload_log_files_to_server')
def test_upload_log_files_to_server(
        mock_upload_log_files_to_server
):
    """
    Test for upload_log_files_to_server
    :param mock_upload_log_files_to_server: magic mock object of upload_log_files_to_server method
    :return: None
    """

    on_demand_jobs.upload_log_files_to_server('dev', "issue_id", [], 'configs')
    mock_upload_log_files_to_server.assert_called_with('dev', "issue_id", [], 'configs')
