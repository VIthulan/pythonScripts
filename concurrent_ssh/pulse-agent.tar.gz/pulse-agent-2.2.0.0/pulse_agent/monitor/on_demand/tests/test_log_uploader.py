"""
Test cases for Log uploader
"""
import logging
import mock
from requests.models import Response
import pytest

from pulse_agent.monitor.on_demand import log_uploader

logging.basicConfig(level=logging.DEBUG)


def setup_module(mdl):
    """ setup_module """
    log = logging.getLogger('setup_module')
    log.debug("setup_module module:%s", mdl.__name__)


def teardown_module(mdl):
    """ teardown_module """
    log = logging.getLogger('teardown_module')
    log.debug("teardown_module module:%s", mdl.__name__)


def setup_function(func):
    """ setup_function """
    log = logging.getLogger('setup_function')
    log.debug("setup_function function:%s", func.__name__)


def teardown_function(func):
    """ teardown_function """
    log = logging.getLogger('teardown_function')
    log.debug("teardown_function function:%s", func.__name__)


@mock.patch('os.remove')
@mock.patch('shutil.rmtree')
def test_do_log_cleanup(mock_shutil_rmtree, mock_os_remove):
    """ Test cases for do_log_cleanup """

    # When no exceptions are raised
    mock_shutil_rmtree.return_value = None
    mock_os_remove.return_value = None

    log_uploader.do_log_cleanup()
    mock_os_remove.assert_called_with('/home/leapset/pulse/pos_logs.zip')
    mock_shutil_rmtree.assert_called_with('/home/leapset/pulse/log-files/')

    # When  os.remove raises an exception
    mock_os_remove.side_effect = Exception
    assert log_uploader.do_log_cleanup() is None

    # When  os.remove raises an exception
    mock_shutil_rmtree.side_effect = Exception
    mock_os_remove.return_value = None

    assert log_uploader.do_log_cleanup() is None


@mock.patch('pulse_agent.monitor.on_demand.log_uploader.send_log_collection_status_to_api')
@mock.patch('pulse_agent.monitor.on_demand.log_uploader.select_file_and_copy_to_local_path')
def test_select_files_and_copy_to_local_path(
        mock_select_file_and_copy_to_local_path,
        mock_send_log_collection_status_to_api):
    """ Test cases for select_files_and_copy_to_local_path """

    # When process is successful
    mock_select_file_and_copy_to_local_path.return_value = None
    log_uploader.select_files_and_copy_to_local_path(
        'dev',
        'sfIssue1',
        [
            {'type': 'MOXY', 'pastLogCount': 0},
            {'type': 'COUCH', 'pastLogCount': 2}
        ]
    )

    expected_calls = [
        mock.call('sfIssue1', '/home/leapset/cinco/logs/', 'MOXY', ['moxy.log']),
        mock.call('sfIssue1', '/var/log/couchdb/', 'COUCH', [
            'couch.log', 'couch.log.1', 'couch.log.1.gz', 'couch.log.2', 'couch.log.2.gz'
        ])
    ]
    assert mock_select_file_and_copy_to_local_path.mock_calls == expected_calls

    # When an exception is raised
    mock_send_log_collection_status_to_api.return_value = None
    mock_select_file_and_copy_to_local_path.side_effect = Exception

    with pytest.raises(Exception):
        log_uploader.select_files_and_copy_to_local_path(
            'dev',
            'sfIssue1',
            [
                {'type': 'MOXY', 'pastLogCount': 0},
                {'type': 'COUCH', 'pastLogCount': 2}
            ]
        )

    mock_send_log_collection_status_to_api.assert_called_with('dev', 'COLLECT_AND_UPLOAD_LOGS_FAILURE')


@mock.patch('shutil.copyfile')
@mock.patch('os.path.isfile')
@mock.patch('os.makedirs')
@mock.patch('os.path.exists')
def test_select_file_and_copy_to_local_path(
        mock_os_path_exists,
        mock_os_makedirs,
        mock_os_path_is_file,
        mock_shutil_copyfile):
    """ Test cases for select_file_and_copy_to_local_path """

    mock_os_makedirs.return_value = None
    mock_shutil_copyfile.return_value = None

    # path and files do not exist
    mock_os_path_exists.return_value = False
    mock_os_path_is_file.return_value = False

    log_uploader.select_file_and_copy_to_local_path(
        'Issue1',
        '/home/leapset/cinco/logs/',
        'MOXY',
        ['file1', 'file2']
    )

    mock_shutil_copyfile.assert_not_called()
    expected_makedirs_calls = [
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY')
    ]
    assert mock_os_makedirs.mock_calls == expected_makedirs_calls

    # path does not exist and files exist
    mock_os_path_exists.return_value = False
    mock_os_path_is_file.return_value = True

    log_uploader.select_file_and_copy_to_local_path(
        'Issue1',
        '/home/leapset/cinco/logs/',
        'MOXY',
        ['file1', 'file2']
    )

    expected_makedirs_calls = [
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY')
    ]

    expected_copy_file_calls = [
        mock.call('/home/leapset/cinco/logs/file1', '/home/leapset/pulse/log-files/Issue1/MOXY/file1'),
        mock.call('/home/leapset/cinco/logs/file2', '/home/leapset/pulse/log-files/Issue1/MOXY/file2')
    ]

    assert mock_os_makedirs.mock_calls == expected_makedirs_calls
    assert mock_shutil_copyfile.mock_calls == expected_copy_file_calls

    # path does exists and files do not exist
    mock_os_path_exists.return_value = True
    mock_os_path_is_file.return_value = False

    log_uploader.select_file_and_copy_to_local_path(
        'Issue1',
        '/home/leapset/cinco/logs/',
        'MOXY',
        ['file1', 'file2']
    )

    expected_makedirs_calls = [
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY')
    ]
    expected_copy_file_calls = [
        mock.call('/home/leapset/cinco/logs/file1', '/home/leapset/pulse/log-files/Issue1/MOXY/file1'),
        mock.call('/home/leapset/cinco/logs/file2', '/home/leapset/pulse/log-files/Issue1/MOXY/file2')
    ]

    assert mock_os_makedirs.mock_calls == expected_makedirs_calls
    assert mock_shutil_copyfile.mock_calls == expected_copy_file_calls

    # path and files exists
    mock_os_path_exists.return_value = True
    mock_os_path_is_file.return_value = True

    log_uploader.select_file_and_copy_to_local_path(
        'Issue1',
        '/home/leapset/cinco/logs/',
        'MOXY',
        ['file1', 'file2']
    )

    expected_makedirs_calls = [
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY'),
        mock.call('/home/leapset/pulse/log-files/Issue1/MOXY')
    ]
    expected_copy_file_calls = [
        mock.call('/home/leapset/cinco/logs/file1', '/home/leapset/pulse/log-files/Issue1/MOXY/file1'),
        mock.call('/home/leapset/cinco/logs/file2', '/home/leapset/pulse/log-files/Issue1/MOXY/file2'),
        mock.call('/home/leapset/cinco/logs/file1', '/home/leapset/pulse/log-files/Issue1/MOXY/file1'),
        mock.call('/home/leapset/cinco/logs/file2', '/home/leapset/pulse/log-files/Issue1/MOXY/file2')
    ]

    assert mock_os_makedirs.mock_calls == expected_makedirs_calls
    assert mock_shutil_copyfile.mock_calls == expected_copy_file_calls


def test_get_array_of_files_from_type():
    """ Test cases for get_array_of_files_from_type """

    assert log_uploader.get_array_of_files_from_type('MOXY', -1) == ['moxy.log']
    assert log_uploader.get_array_of_files_from_type('MOXY', 0) == ['moxy.log']
    assert log_uploader.get_array_of_files_from_type('MOXY', 1) == ['moxy.log']
    assert log_uploader.get_array_of_files_from_type('MOXY', 3) == [
        'moxy.log',
        'moxy.log.1',
        'moxy.log.1.gz',
        'moxy.log.2',
        'moxy.log.2.gz',
        'moxy.log.3',
        'moxy.log.3.gz'
    ]


@mock.patch('pulse_agent.utils.rest_client.RestClient.post')
def test_send_log_collection_status_to_api(mock_pulse_agent_utils_rest_client_post):
    """ Test cases for send_log_collection_status_to_api """

    # When process is successful
    the_response = Response()
    the_response.code = "expired"
    the_response.error_type = "expired"
    the_response.status_code = 400
    the_response._content = b'{ "key" : "a" }'

    mock_pulse_agent_utils_rest_client_post.return_value = the_response

    log_uploader.send_log_collection_status_to_api('dev', 'COLLECT_AND_UPLOAD_LOGS_FAILURE')

    mock_pulse_agent_utils_rest_client_post.assert_called_with(
        body={
            'STATUS': 'COLLECT_AND_UPLOAD_LOGS_FAILURE',
            'REGISTER_NO': None,
            'MERCHANT_ID': None
        },
        path='/api/v1/device/collectAndUploadLogsResponse'
    )

    # When an exception is raised
    mock_pulse_agent_utils_rest_client_post.side_effect = Exception
    log_uploader.send_log_collection_status_to_api('dev', 'COLLECT_AND_UPLOAD_LOGS_FAILURE')


@mock.patch('pulse_agent.utils.s3_client.get_s3_client')
@mock.patch('pulse_agent.utils.s3_client.upload_to_directory')
@mock.patch('pulse_agent.monitor.on_demand.log_uploader.do_log_cleanup')
@mock.patch('pulse_agent.monitor.on_demand.log_uploader.send_log_collection_status_to_api')
@mock.patch('pulse_agent.monitor.on_demand.log_uploader.select_files_and_copy_to_local_path')
@mock.patch('pulse_agent.utils.file_utils.compress_logs')
@mock.patch('pulse_agent.services.cinco_identity.get_merchant_id')
@mock.patch('pulse_agent.services.cinco_identity.get_register_no')
def test_upload_log_files_to_server(mock_get_merchant_id,
                                    mock_get_register_no,
                                    mock_compress_logs,
                                    mock_select_files_and_copy_to_local_path,
                                    mock_send_log_collection_status_to_api,
                                    mock_do_log_cleanup,
                                    mock_upload_to_directory,
                                    mock_get_s3_client):
    """ Test cases for upload_log_files_to_server """

    mock_compress_logs.return_value = None
    mock_select_files_and_copy_to_local_path.return_value = None
    mock_send_log_collection_status_to_api.return_value = None
    mock_do_log_cleanup.return_value = None
    mock_get_s3_client.return_value = {}
    mock_upload_to_directory.return_value = None

    # load_pref_entries successful
    mock_get_merchant_id.return_value = 'VALUE'
    mock_get_register_no.return_value = 'VALUE'
    log_uploader.upload_log_files_to_server(
        'dev',
        'SFIssue1',
        [
            {'type': 'MOXY', 'pastLogCount': 0},
            {'type': 'COUCH', 'pastLogCount': 2}
        ],
        {
            'credentials': {
                'awsAccessKeyId': 'awsAccessKeyId',
                'awsSecretAccessKey': 'awsSecretAccessKey',
                'regionName': 'regionName'
            },
            'bucketName': 'bucketName'
        }
    )

    mock_get_s3_client.assert_called_with('awsAccessKeyId', 'awsSecretAccessKey', 'regionName')

    mock_upload_to_directory.assert_called_with(
        {},
        'bucketName',
        'SFIssue1/VALUE/VALUE/SFIssue1_VALUE_VALUE_pos_logs.zip',
        '/home/leapset/pulse/pos_logs.zip'
    )
    mock_do_log_cleanup.assert_called()

    # load_pref_entries unsuccessful
    mock_get_merchant_id.return_value = 'Error: Preference entries empty'
    mock_get_register_no.return_value = 'Error: Preference entries empty'

    log_uploader.upload_log_files_to_server(
        'dev',
        'SFIssue1',
        [
            {'type': 'MOXY', 'pastLogCount': 0},
            {'type': 'COUCH', 'pastLogCount': 2}
        ],
        's3Configs'
    )

    expected_calls = [
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_PHASE_1_COMPLETE'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_PHASE_2_COMPLETE'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_PHASE_3_COMPLETE'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_SUCCESS'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_PHASE_1_COMPLETE'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_PHASE_2_COMPLETE'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_PHASE_3_COMPLETE'),
        mock.call('dev', 'COLLECT_AND_UPLOAD_LOGS_FAILURE')
    ]

    assert mock_send_log_collection_status_to_api.mock_calls == expected_calls

    mock_select_files_and_copy_to_local_path.assert_called_with(
        'dev',
        'SFIssue1', [{
            'type': 'MOXY',
            'pastLogCount': 0
        }, {
            'type': 'COUCH',
            'pastLogCount': 2
        }]
    )

    mock_do_log_cleanup.assert_called()
