import time
import logging
import pickle
import subprocess as subproc

from pulse_agent.monitor.on_demand import log_uploader
from pulse_agent.monitor.system_stats.system_stats import system_stats
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils import sub_process
from pulse_agent.services.moxy import moxy
from pulse_agent.utils.config import config


def run_lp_clean():
    """
    Run the lp-clean command
    :return: response from lp-clean
    """
    try:
        clean_code_resp = sub_process.p_open_default(
            "lp-control install +lp-clean",
            stdout=subproc.PIPE,
            stderr=subproc.PIPE,
            shell=True
        )
        message = clean_code_resp.stdout.read().strip()

        if not message:
            message = clean_code_resp.stderr.read()
        else:
            lines = message.split('\n')
            message = lines[-1]

        return message
    except Exception as exception:
        logging.exception("Error calling lp-clean: %s", exception)
        return "lp-clean is not installed in this POS"


def run_lp_resize():
    """
    Run the lp-resize command
    :return: response from lp-resize
    """
    try:
        resize_code_resp = sub_process.p_open_default(
            "lp-control install +lp-resize",
            stdout=subproc.PIPE,
            stderr=subproc.PIPE,
            shell=True
        )
        message = resize_code_resp.stdout.read().strip()

        if not message:
            message = resize_code_resp.stderr.read()
        else:
            lines = message.split('\n')
            message = lines[-1]

        return message
    except Exception as exception:
        logging.exception("Error calling lp-resize: %s", exception)
        return "lp-resize is not installed in this POS"


def clean_hdd():
    """
    Clean Hard disk
    :return:
    """
    response = None
    try:
        command = 'cincoinfo | grep "HARDWARE" | cut -d ":" -f 2'
        device_type = sub_process.p_open_stripped(command)
        if device_type == "POINDUS":
            response = {
                'RESIZE_CODE_RESP': run_lp_resize(),
                'CLEAN_CODE_RESP': run_lp_clean()
            }
        else:
            response = {
                'RESIZE_CODE_RESP': "lp-resize not need to execute on DATAVAN devices",
                'CLEAN_CODE_RESP': run_lp_clean()
            }

        logging.info("Clean HDD result: %s", str(response))

    except Exception as exception:
        logging.exception('Error while cleaning HDD %s', exception)

    pulse_client.post(config.CLEAN_HARD_DISK_END_POINT, body=response)


def debug_gdm_restart(env):
    """
    GDM restart
    :param env: Environment
    :return:
    """
    try:
        command = "/home/leapset/system/restart_gdm"
        logging.debug(command)
        sub_process.p_open(command)
        time.sleep(config.THRESHOLD_WAIT_TO_CHECK_MOXY_STATUS)
        moxy_status = moxy.check_if_moxy_running_after_gdm_restart()
        send_debug_script_response(env=env, message=moxy_status)
    except Exception as exception:
        logging.error('Error while debug gdm restart: %s', exception)


def debug_futon():
    """
    Debug futon
    :return:
    """
    try:
        command = "DISPLAY=:0 su -c \"firefox localhost:5984/_utils/ 2>&1 >  /dev/null &\" leapset"
        logging.debug(command)
        sub_process.p_open(command)
        logging.info('Futon checkup is completed')
    except Exception as exception:
        logging.exception('Error while debug futon: %s', exception)


def send_debug_script_response(env, message):
    """
    Send debug script response to related API
    :param env: Environment
    :param message: Message
    :return:
    """
    try:
        pulse_client.get_client(env).post(config.DEBUG_SCRIPT_RESULT_END_POINT, body={
            'REPORT': {
                'DEBUG_MESSAGE': message
            }
        })
    except Exception as exception:
        logging.exception('Error sending debug script success message to API websocket: %s', exception)


def debug_phantom_printer(env):
    """
    Debug phantom printers
    :param env: Environment
    :return:
    """
    try:
        phantom_command = "grep -q 'sudo touch /dev/ttyACM0 || true' /etc/rc.local"
        logging.debug(phantom_command)
        dev_exists_command = "grep -q 'touch /dev/ttyACM0' /etc/rc.local"
        check_if_in_dev = sub_process.p_open_stripped(dev_exists_command)

        if not check_if_in_dev:
            save_command = "sed -i '$ i\\touch /dev/ttyACM0' /etc/rc.local"
            logging.debug(save_command)
            sub_process.p_open(save_command)
            logging.debug("[Phantom Printer] dev save command saved!")
        else:
            logging.debug("File was already there in DEV mode!")

        permission_command = "grep -q 'chmod 667 /dev/ttyACM0' /etc/rc.local"
        check_if_in_permission = sub_process.p_open_stripped(permission_command)

        if not check_if_in_permission:
            add_permission = "sed -i '$ i\chmod 667 /dev/ttyACM0' /etc/rc.local"
            logging.debug(add_permission)
            sub_process.p_open(add_permission)
            logging.debug("save permission command saved!")
        else:
            logging.debug("File has already given the necessary permissions mode")

        permanently_add_to_local_file = sub_process.p_open(phantom_command)

        if not permanently_add_to_local_file:
            reboot_command = "sed -i '$ i\sudo touch /dev/ttyACM0 || true' /etc/rc.local"
            logging.debug(reboot_command)
            sub_process.p_open(reboot_command)
            logging.debug("save command saved!")
            logging.debug("FileSave : Changes will be applied after reboot")
        else:
            logging.debug("Did not save file /dev/ttyACM0")

        success_message = 'Phantom Printer Added Successful'
        return send_debug_script_response(env, success_message)
    except Exception as exception:
        logging.exception('Error while debug adding phantom printer: %s', exception)
        fail_message = 'An error occurred while adding phantom printer'
        return send_debug_script_response(env, fail_message)


def add_new_couch_user(env):
    """
    Add new couch user
    :param env: Environment
    :return:
    """
    try:
        command = "sed -i \"/^root/  a support=9ijnBGT5\" /etc/couchdb/local.ini"
        logging.debug(command)
        sub_process.p_open(command)
        couch_db_command = "service couchdb restart"
        sub_process.p_open(couch_db_command)
        success_message = 'Adding Couch User Successful'
        send_debug_script_response(env, success_message)

    except Exception as exception:
        logging.exception('Error while adding new couch user: %s', exception)
        fail_message = 'Adding Couch User Unsuccessful'
        send_debug_script_response(env, fail_message)


def rename_register(env, previous_name, new_name, admin_pass):
    """
    Rename register
    :param env: Environment
    :param previous_name: Previous name
    :param new_name: New Name
    :param admin_pass: Password
    :return:
    """
    try:
        # below is the shell command executed in the pos terminal
        command = ('curl http://Administrator:' + admin_pass +
                   '127.0.0.1:8080/moxy/rest/device/rename -d "current=' +
                   previous_name + '&new=' + new_name + '"')
        logging.debug(command)
        sub_process.p_open(command)
        logging.info("Successfully renamed the register")
        success_message = 'Register Rename Successful'
        send_debug_script_response(env, success_message)

    except Exception as exception:
        logging.error('Error while renaming register: %s', exception)
        fail_message = 'Register Renaming Unsuccessful'
        send_debug_script_response(env, fail_message)


def check_lp_pulse_state_in_peer_registers(env, root_password):
    """
    Check LP pulse status in peer registers
    :param env: Environment
    :param root_password: Password
    :return:
    """
    try:
        with open(config.NETWORK_INTERCONNECTIVITY_IP_LIST_FILE, "rb") as input_file:
            stored_inter_connectivity_data = pickle.load(input_file)

        register_list = []

        for device in stored_inter_connectivity_data:
            if device['DEVICE_TYPE'] == 'DESKTOP':
                register_list.append(device)

        for register in register_list:
            register['LP_PULSE_STATUS'] = get_lp_pulse_state(
                register['LOCAL_IP'],
                config.PEER_REGISTER_USER,
                root_password
            )

        logging.debug('LP-Pulse scan result: %s', register_list)

        pulse_client.get_client(env).post(config.ON_DEMAND_LP_PULSE_CHECK_RESULT_END_POINT, body={
            'STATUS_ARRAY': register_list
        })
    except Exception as exception:
        logging.exception("Error checking lp-pulse status in peer registers: %s", exception)


def get_lp_pulse_state(server, user, password):
    """
    Get LP pulse status
    :param server: Server
    :param user: User
    :param password: Password
    :return:
    """
    try:
        os_distribution = system_stats.get_distribution_name()
        logging.debug("[LP_PULSE CHECKER] OS DISTRIBUTION: %s", os_distribution)

        if '14.04' in os_distribution:
            from pexpect import pxssh
            ssh_server = pxssh.pxssh()
            if not ssh_server.login(server, user, password):
                logging.error("SSH session failed on login.")
                logging.error(str(ssh_server))
                return config.ERROR_CHECKING_LP_PULSE_STATE

            logging.debug("SSH session login successful")
            ssh_server.sendline('ls /etc/init/|grep lp-pulse.conf')
            ssh_server.prompt()
            result = ssh_server.before
            if result:
                result = result.replace('ls /etc/init/|grep lp-pulse.conf', '').strip()
                logging.info("lp pulse status result %s", result)
            ssh_server.logout()
            if result == '':
                return config.LP_PULSE_NOT_INSTALLED

            return config.LP_PULSE_INSTALLED

        return config.ERROR_CHECKING_LP_PULSE_STATE

    except Exception as exception:
        logging.exception("Error in reading meta data from file for lp pulse scan: %s", exception)
        return config.ERROR_CHECKING_LP_PULSE_STATE


def save_logs(env):
    """
    Save logs
    :param env: Environment
    :return:
    """

    try:
        save_log_process = sub_process.p_open_default('copyLog')
        save_log_process.wait()

        logging.debug("[COPY_LOG_FILES] success")

        pulse_client.get_client(env).post(config.SAVE_LOGS_RESULT_END_POINT, body={
            'STATUS': True
        })
    except Exception as exception:
        logging.exception('Error while copying log files: %s', exception)
        pulse_client.get_client(env).post(config.SAVE_LOGS_RESULT_END_POINT, body={
            'STATUS': False
        })


def upload_log_files_to_server(env, sf_issue_id, log_file_list, s3_configs):
    """
    Upload log files to server
    :param env:
    :param sf_issue_id:
    :param log_file_list:
    :param s3_configs:
    :return:
    """
    log_uploader.upload_log_files_to_server(env, sf_issue_id, log_file_list, s3_configs)
