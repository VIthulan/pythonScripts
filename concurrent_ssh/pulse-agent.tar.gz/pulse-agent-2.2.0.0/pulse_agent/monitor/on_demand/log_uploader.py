"""
Log uploader related functions
"""
# Core modules
import logging
import os
import shutil

# Custom modules
from pulse_agent.services import cinco_identity
from pulse_agent.utils import s3_client
from pulse_agent.utils.config import config
from pulse_agent.utils.pulse_client import pulse_client
from pulse_agent.utils import file_utils


def select_files_and_copy_to_local_path(env, sf_issue_id, log_file_list):
    """
    Select files and copy to local path
    :param env: Environment
    :param sf_issue_id: SF issue ID
    :param log_file_list: List
    :return:
    """
    try:
        for log_file in log_file_list:
            select_file_and_copy_to_local_path(
                sf_issue_id,
                config.LOG_FILE_META_DATA.get(log_file['type']).get('path'),
                log_file['type'],
                get_array_of_files_from_type(log_file['type'], log_file['pastLogCount'])
            )

    except Exception as exception:
        send_log_collection_status_to_api(env, config.COLLECT_AND_UPLOAD_LOGS_FAILURE)
        logging.exception("[LOG_UPLOADER] Error while selecting files and copy to given path : %s", exception)
        raise Exception


def get_array_of_files_from_type(log_type, past_logs_count):
    """
    Get array of files
    :param log_type: type
    :param past_logs_count: required count
    :return:
    """
    try:
        log_files = [config.LOG_FILE_META_DATA.get(log_type).get('active')]

        if past_logs_count > 1:
            for i in range(0, past_logs_count):
                log_files.append(config.LOG_FILE_META_DATA.get(log_type).get('past_prefix') + str(i + 1))
                log_files.append(config.LOG_FILE_META_DATA.get(log_type).get('past_prefix') + str(i + 1) + '.gz')

        logging.info('log file array from type %s is %s', str(log_files), log_type)

        return log_files
    except Exception as exception:
        logging.exception("[LOG_UPLOADER] Error getting array of files from type : %s", exception)


def select_file_and_copy_to_local_path(sf_issue_id, directory, log_type, log_files):
    """
    Select file and copy to local path
    :param sf_issue_id: SF ID
    :param directory: directory
    :param log_type: Type
    :param log_files: Files
    :return:
    """
    try:
        path = "{}{}/".format(config.LOCAL_LOG_DIRECTORY, sf_issue_id) + log_type

        logging.info('log path for type %s is %s', log_type, path)

        for log_file in log_files:
            if not os.path.exists(path):
                os.makedirs(path)
            if os.path.isfile(directory + log_file):
                shutil.copyfile(directory + log_file, path + "/" + log_file)

    except Exception as exception:
        logging.exception("[LOG_UPLOADER] Error while selecting a file and copy to given path : %s", exception)


def send_log_collection_status_to_api(env, status):
    """
    Send log collection status to API
    :param env: Env
    :param status: Status
    :return:
    """
    try:
        response = pulse_client.get_client(env).post(config.LOG_COLLECTION_RESPONSE_END_POINT, body={
            'STATUS': status
        })

        logging.debug("[LOG_UPLOADER] Sent %s State to %s API : %s", status, env, response.json())

    except Exception as exception:
        logging.exception("[LOG_UPLOADER] Error while sending %s state to api : %s", status, exception)


def do_log_cleanup():
    """
    Clean directory
    """
    try:
        local_zip_file = "{}/{}".format(config.LOCAL_LOG_ZIP_DIRECTORY, config.LOG_FILE_IDENTIFIER + ".zip")
        shutil.rmtree(config.LOCAL_LOG_DIRECTORY)
        os.remove(local_zip_file)
    except Exception as exception:
        logging.exception("[LOG_UPLOADER] Error while pos clean up : %s", exception)


def upload_log_files_to_server(env, sf_issue_id, log_file_list, s3_configs):
    """
    upload_log_files_to_server
    :param env: Env
    :param sf_issue_id: ID
    :param log_file_list: List
    :param s3_configs: Configs
    :return:
    """
    try:
        # Init variables
        merchant_id = cinco_identity.get_merchant_id()
        register_no = cinco_identity.get_register_no()

        # Phase 1
        do_log_cleanup()
        send_log_collection_status_to_api(env, config.COLLECT_AND_UPLOAD_LOGS_PHASE_1_COMPLETE)

        # Phase 2
        select_files_and_copy_to_local_path(env, sf_issue_id, log_file_list)
        send_log_collection_status_to_api(env, config.COLLECT_AND_UPLOAD_LOGS_PHASE_2_COMPLETE)

        # Phase 3
        file_utils.compress_logs(
            src_directory=config.LOCAL_LOG_DIRECTORY,
            dest_directory=config.LOCAL_LOG_ZIP_DIRECTORY,
            file_name=config.LOG_FILE_IDENTIFIER
        )
        send_log_collection_status_to_api(env, config.COLLECT_AND_UPLOAD_LOGS_PHASE_3_COMPLETE)

        # Phase final: success
        local_zip_file = "{}/{}".format(config.LOCAL_LOG_ZIP_DIRECTORY, config.LOG_FILE_IDENTIFIER + ".zip")
        remote_path = "{}/{}/{}/{}".format(
            sf_issue_id,
            merchant_id,
            register_no,
            "{}_{}_{}_{}.zip".format(
                sf_issue_id,
                merchant_id,
                register_no,
                config.LOG_FILE_IDENTIFIER
            )
        )
        client = s3_client.get_s3_client(
            s3_configs['credentials']['awsAccessKeyId'],
            s3_configs['credentials']['awsSecretAccessKey'],
            s3_configs['credentials']['regionName']
        )

        s3_client.upload_to_directory(client, s3_configs['bucketName'], remote_path, local_zip_file)

        send_log_collection_status_to_api(env, config.COLLECT_AND_UPLOAD_LOGS_SUCCESS)

        do_log_cleanup()
    except Exception as exception:
        # Phase final: failure
        send_log_collection_status_to_api(env, config.COLLECT_AND_UPLOAD_LOGS_FAILURE)
        do_log_cleanup()

        logging.exception("[LOG_UPLOADER] Error while uploading logs : %s", exception)
