"""
Tunnel module controller
"""
import os
import logging
import time

from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config
from pulse_agent.utils.config_managers import pos_config_manager
from pulse_agent.utils.config import env_config


class Tunnel(object):
    """
    Tunnel related methods and attributes
    """

    def __init__(self):
        pass

    def get_tunnel_port(self, user, host):
        """ returns any currently open SSH tunnel port number with particular user and host. """
        ssh_port = ''
        grep_outputs = os.popen(
            'ps aux | grep -v grep | grep ' + user + '@' + host +
            ' | grep -o [0-9]*:localhost:22').read().strip().splitlines()
        tunnel_ports = []
        for output in grep_outputs:
            tunnel_ports.append(int(output.split(':')[0]))

        if tunnel_ports:
            ssh_port = min(tunnel_ports)
        return str(ssh_port)

    def get_tunnel_duration(self, user, host):
        """ returns the amount of time the SSH tunnel has been established
        with particular user and host. """
        ssh_port = self.get_tunnel_port(user, host)

        duration = os.popen(
            'ps -eo etime,cmd | grep -v grep | grep ' + user + '@' +
            host + ' | grep ' + ssh_port + ':localhost:22').read()

        if duration == '' or duration is None:
            return None

        return duration.strip().split()[0]

    def get_tunnel_server(self, env):
        """
        Get tunnel server
        :param env: environment
        :return: tunnel server
        """
        try:
            if env == config.DEDICATED:
                build_env = pos_config_manager.get_pos_build_env().lower()
                logging.debug("build_env: %s", build_env)
                tunnel_server = env_config.ENV_CONFIG.get(build_env).get('TUNNEL_SERVER')
                if tunnel_server is not None:
                    return tunnel_server
                logging.error(
                    "Error: not a valid build environment provided : "
                    "So returns ENV_PROD as default %s:", build_env)
                return env_config.ENV_CONFIG.get('prod').get('TUNNEL_SERVER')
            elif env == config.DEV:
                return env_config.ENV_CONFIG.get('dev').get('TUNNEL_SERVER')
            else:
                logging.error("URL type is not mentioned")
                return ""
        except Exception as exception:
            logging.exception("Error while generating web socket url: %s", exception)
            return ""

    def is_tunnel_exists(self, user, host):
        """ returns whether an SSH tunnel is currently open. """
        return self.get_tunnel_port(user, host) != ''

    def destroy_tunnel(self):
        """ terminates all SSH and X11VNC sessions. """
        os.popen('killall ssh x11vnc')

    def create_tunnel(self, server, port, user, key):
        """ establishes SSH tunnels for shell and VNC access.

        :param server:      the IP address or hostname of the tunneling server
        :param port:        the port forwarded on the tunneling server
        :param user:        user
        :param key:         key
        """

        ssh_tun_cmd = 'ssh {opts} -i {keyfile} -R {port}:localhost:22 -N -f {user}@{server}'.format(
            opts=config.SSH_OPTS,
            keyfile=key,
            port=str(port),
            user=user,
            server=server
        )

        vnc_tun_cmd = 'ssh {opts} -i {keyfile} -R {port}:localhost:5900 -N -f {user}@{server}'.format(
            opts=config.SSH_OPTS,
            keyfile=key,
            port=str(port + 1),
            user=user,
            server=server
        )

        couch_tun_cmd = 'ssh {opts} -i {keyfile} -R {port}:localhost:22 -N -f {user}@{server}'.format(
            opts=config.SSH_OPTS,
            keyfile=key,
            port=str(port + 2),
            user=user,
            server=server
        )

        vnc_cmd = 'x11vnc -q -reopen -shared -many -passwd %s' % str(port)

        # start each of the processes as background processes
        with open(os.devnull, 'w') as devnull:
            # Port forwarding for Tunneling
            sub_process.p_open_default(ssh_tun_cmd.split(), stderr=devnull, stdout=devnull)

            # Port forwarding for VNC Tunnel
            sub_process.p_open_default(vnc_tun_cmd.split(), stderr=devnull, stdout=devnull)

            # Port forwarding for Couch
            sub_process.p_open_default(couch_tun_cmd.split(), stderr=devnull, stdout=devnull)

            # VNC Command
            sub_process.p_open_default(vnc_cmd.split(), stderr=devnull, stdout=devnull)

        # we sleep here to allow enough time for the SSH tunnels to open and x11vnc
        # to start. I am not sure on the best value so it should be monitored and
        # adjusted as necessary
        time.sleep(1)


tunnel = Tunnel()
