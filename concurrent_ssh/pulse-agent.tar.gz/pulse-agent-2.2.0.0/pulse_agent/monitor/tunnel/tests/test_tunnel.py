"""
Test for tunnel module
"""
import logging
import mock
from pulse_agent.monitor.tunnel.tunnel import tunnel

logging.basicConfig(level=logging.DEBUG)


def setup_module(mdl):
    """ setup_module """
    log = logging.getLogger('setup_module')
    log.debug("setup_module module:%s", mdl.__name__)


def teardown_module(mdl):
    """ teardown_module """
    log = logging.getLogger('teardown_module')
    log.debug("teardown_module module:%s", mdl.__name__)


def setup_function(func):
    """ setup_function """
    logging.info("setup_function function:%s", func.__name__)


def teardown_function(func):
    """ teardown_function """
    log = logging.getLogger('teardown_function')
    log.debug("teardown_function function:%s", func.__name__)


@mock.patch('os.popen')
def test_destroy_tunnel(mock_popen):
    """ Test cases for destroy_tunnel """
    tunnel.destroy_tunnel()
    mock_popen.assert_called_once_with('killall ssh x11vnc')


@mock.patch('os.popen')
def test_get_tunnel_port(mock_popen):
    """ Test cases for get_tunnel_port """

    # If tunnels have been established
    mock_popen_return_value = mock_popen.return_value
    mock_popen_return_value.read.return_value = '25034:localhost:22\n25032:localhost:22'
    assert tunnel.get_tunnel_port('support', 'pulse.leapset.com') == '25032'

    # If no tunnels have been established
    mock_popen_return_value = mock_popen.return_value
    mock_popen_return_value.read.return_value = ''
    assert tunnel.get_tunnel_port('support', 'pulse.leapset.com') == ''

    mock_popen.assert_called_with('ps aux | grep -v grep | '
                                  'grep support@pulse.leapset.com | '
                                  'grep -o [0-9]*:localhost:22')
    assert mock_popen.call_count == 2


@mock.patch('pulse_agent.monitor.tunnel.tunnel.tunnel.get_tunnel_port')
def test_is_tunnel_exists(mock_get_tunnel_port):
    """ Test cases for is_tunnel_exists """

    # If tunnels have been established
    mock_get_tunnel_port.return_value = '25032'
    assert tunnel.is_tunnel_exists('support', 'pulse.leapset.com') is True

    # If no tunnels have been established
    mock_get_tunnel_port.return_value = ''
    assert tunnel.is_tunnel_exists('support', 'pulse.leapset.com') is False


@mock.patch('pulse_agent.monitor.tunnel.tunnel.tunnel.get_tunnel_port')
@mock.patch('os.popen')
def test_get_tunnel_duration(mock_popen, mock_get_tunnel_port):
    """ Test cases for get_tunnel_duration """

    mock_get_tunnel_port.return_value = '25032'

    mock_popen_return_value = mock_popen.return_value
    mock_popen_return_value.read.return_value = \
        '01:02 ssh -o UserKnownHostsFile=' \
        '/dev/null -o StrictHostKeyChecking=no -i ' \
        '/home/leapset/.ssh/id_dsa -R 10608:localhost:22 ' \
        '-N -f support@pulse.leapset.com'

    assert tunnel.get_tunnel_duration('support', 'pulse.leapset.com') == '01:02'

    mock_popen.assert_called_with(
        'ps -eo etime,cmd | grep -v grep '
        '| grep support@pulse.leapset.com '
        '| grep 25032:localhost:22')
    mock_get_tunnel_port.assert_called_with('support', 'pulse.leapset.com')


@mock.patch('subprocess.Popen')
@mock.patch("__main__.open", create=True)
def test_create_tunnel(mock_open, mock_subprocess_popen):
    """ Test cases for create_tunnel """

    mock_open.return_value = None

    tunnel.create_tunnel('pulse.leapset.com', 25032, 'support', '/home/leapset/.ssh/id_dsa')

    logging.debug(mock_subprocess_popen.call_args_list)

    expected_calls = [mock.call(['ssh', '-o', 'UserKnownHostsFile=/dev/null',
                                 '-o', 'StrictHostKeyChecking=no', '-i',
                                 '/home/leapset/.ssh/id_dsa', '-R',
                                 '25032:localhost:22', '-N', '-f',
                                 'support@pulse.leapset.com'], stderr=mock.ANY, stdout=mock.ANY),
                      mock.call(['ssh', '-o', 'UserKnownHostsFile=/dev/null',
                                 '-o', 'StrictHostKeyChecking=no', '-i',
                                 '/home/leapset/.ssh/id_dsa', '-R',
                                 '25033:localhost:5900', '-N', '-f',
                                 'support@pulse.leapset.com'], stderr=mock.ANY, stdout=mock.ANY),
                      mock.call(['ssh', '-o', 'UserKnownHostsFile=/dev/null',
                                 '-o', 'StrictHostKeyChecking=no', '-i',
                                 '/home/leapset/.ssh/id_dsa', '-R',
                                 '25034:localhost:22', '-N', '-f',
                                 'support@pulse.leapset.com'], stderr=mock.ANY, stdout=mock.ANY),
                      mock.call(['x11vnc', '-q', '-reopen', '-shared',
                                 '-many', '-passwd', '25032'], stderr=mock.ANY,
                                stdout=mock.ANY)]
    assert mock_subprocess_popen.mock_calls == expected_calls
