"""
Regex finder to grep timestamps from logs
"""
import datetime


# Only for minute < 60
def get_regex_for_time(time_range):
    """
    get_regex_for_time
    :param time_range: time range
    :return: regex range
    """
    now = datetime.datetime.now()
    start_time = (datetime.datetime.now() - datetime.timedelta(minutes=time_range))
    if start_time.hour == now.hour:
        regex_for_range = start_time.strftime("%d-%b %H:") + get_regex_for_min(start_time.minute,
                                                                               now.minute)
    else:
        regex_for_range = get_regex_diff_hour(start_time, now)
    return regex_for_range


def get_regex_region(from_value, to_value):
    """
    Get regex region
    :param from_value: from value
    :param to_value: to value
    :return: regex
    """
    return '(' + str(from_value) + ')|(' + str(to_value) + ')'


def get_regex_diff_hour(start_time, now):
    """
    get_regex_diff_hour
    :param start_time: start time
    :param now: now
    :return: regex region
    """
    start_regex = start_time.strftime("%d-%b %H:") + get_regex_for_min(start_time.minute, '59')
    end_regex = now.strftime("%d-%b %H:") + get_regex_for_min('00', now.minute)
    return get_regex_region(start_regex, end_regex)


def get_regex_for_min(from_value, to_value):
    """
    get_regex_for_min
    :param from_value: from
    :param to_value: to
    :return: regex
    """
    str_from = str(from_value)
    str_to = str(to_value)
    if len(str_from) < 2:
        str_from = '0' + str_from
    if len(str_to) < 2:
        str_to = '0' + str_to

    if str_from[0] != str_to[0]:
        intermediate = ''
        for i in range(int(str_from[0]) + 1, int(str_to[0])):
            intermediate += str(i) + '[0-9]|'
        return '(' + str_from[0] + '[' + str_from[1] + '-9]|' + intermediate + str_to[0] + '[0-' + \
               str_to[1] + '])'

    return '(' + str_from[0] + '[' + str_from[1] + '-9])'
