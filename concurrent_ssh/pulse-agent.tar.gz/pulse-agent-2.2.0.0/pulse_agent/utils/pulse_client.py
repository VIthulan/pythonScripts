"""
Pulse API rest client
"""

import logging
from .rest_client import RestClient
from .config_managers import server_config_manager
from .config import config
from ..utils import file_utils


class PulseClient(object):
    """
    Rest Client instance proxy to be used by the Pulse Client
    """

    def __init__(self, env='dedicated'):
        """
        :param env: used to switch between the prod and dev pulse API instance
        """
        self.env = env
        self.host = server_config_manager.get_node_server_url(env)
        self.client = RestClient(
            host=self.host,
            headers={
                'app-secret': file_utils.read_app_secret()
            },
            response_type='verbose'
        )
        self.identity = {
            'MERCHANT_ID': None,
            'REGISTER_NO': None
        }

    def setup_identity(self, device_id, merchant_id, register_no):
        """
        Set up the identity of the device
        :param device_id: device id of the POS device
        :param merchant_id: merchant id of the POS device
        :param register_no: register no of the POS device
        :return: None
        """
        self.client.headers['device-id'] = device_id
        self.identity.update({
            'MERCHANT_ID': merchant_id,
            'REGISTER_NO': register_no
        })

    """
    login to pulse api is not required anymore
    """
    def login(self):
        """
        Update the app secret in the header of the embedded rest client
        :return: None
        """
        response = self.post(config.APP_SECRET_END_POINT)
        if response and response.status_code == 200:
            app_secret = response.headers.get('app-secret')
            self.client.headers['app-secret'] = app_secret
        else:
            logging.error("Failed to get app secret for %s env", self.env)
            self.client.headers['app-secret'] = 'no-app-secret'

    def get(self, path, params=None):
        """
        Perform get request to the instance env
        :param path: path
        :param params: optional query params
        :return: response json data
        """
        if isinstance(params, dict):
            params.update(self.identity)
        return self.client.get(path=path, params=params)

    def post(self, path, body=None):
        """
        Perform post request to the instance env
        :param path: path
        :param body: body
        :return: response json data
        """
        if isinstance(body, dict):
            body.update(self.identity)
        else:
            body = self.identity
        return self.client.post(path=path, body=body)


class PulseClientProxy(object):
    """
    Proxy class for Performing requests to both dedicated and dev environments
    """

    def __init__(self):
        """
        Create two rest clients and attach to the instance
        """
        self.dev_client = PulseClient(env='dev')
        self.dedicated_client = PulseClient(env='dedicated')

    def setup_identity(self, device_id, merchant_id, register_no):
        """
        Proxy method of setup_identity
        :param device_id: device id of the POS device
        :param merchant_id: merchant id of the POS device
        :param register_no: register no of the POS device
        :return: None
        """
        self.dev_client.setup_identity(device_id, merchant_id, register_no)
        self.dedicated_client.setup_identity(device_id, merchant_id, register_no)

    def get(self, path):
        """
        Proxy get requests to both environments
        :param path: path
        :return: response dict
        """
        return {
            'dedicated': self.dedicated_client.get(path=path),
            'dev': self.dev_client.get(path=path)
        }

    def post(self, path, body):
        """
        Proxy post requests to both environments
        :param path: path
        :param body: post body
        :return: response dict
        """
        return {
            'dedicated': self.dedicated_client.post(path=path, body=body),
            'dev': self.dev_client.post(path=path, body=body)
        }

    def get_client(self, env):
        """
        :param env: enum(dedicated, dev) the target environment
        :return: env specific pulse client instance
        """
        if env == 'dev':
            return self.dev_client
        elif env == 'dedicated':
            return self.dedicated_client


# pylint: disable=invalid-name
pulse_client = PulseClientProxy()
