"""
This customizes standard logging module
"""
import logging
import logging.config
import coloredlogs
from pulse_agent.utils.config import config


class Logger(object):
    """ Do configurations for loggers """

    def __init__(self, tasks):
        pass

    @staticmethod
    def initialize_logger(debug):
        """
        Initialize loggers
        :return:
        """
        Logger.initialize_thread_logger(debug)

    @staticmethod
    def initialize_thread_logger(debug):
        """
        Initialize default logger
        :return:
        """
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)

        if debug:
            coloredlogs.install(fmt="%(asctime)s [%(threadName)s] [%(levelname)s]  %(message)s"
                                , logger=logger, level='DEBUG')
        else:
            # Set level to INFO if DEBUG is not needed by default
            coloredlogs.install(fmt="%(asctime)s [%(threadName)s] [%(levelname)s]  %(message)s"
                                , logger=logger, level='DEBUG')

    @staticmethod
    def initialize_heading_logger():
        """
        Initialize heading logger
        :return:
        """
        logger = logging.getLogger(config.HEADING_LOGGER)
        logger.setLevel(logging.DEBUG)

        handler = logging.StreamHandler()
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s [%(threadName)s] [%(levelname)s] "
                                      "############### %(message)s ###############")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        coloredlogs.install(fmt="%(asctime)s [%(threadName)s] [%(levelname)s] "
                                "############### %(message)s ###############", logger=logger)
