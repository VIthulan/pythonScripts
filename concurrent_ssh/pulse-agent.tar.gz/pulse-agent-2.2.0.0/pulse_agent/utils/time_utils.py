"""
Time related utils
"""
import logging
import time
import datetime
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config


def get_timezone():
    """
    Get timezone
    :return: time zone
    """
    try:
        command = 'cat /etc/timezone'
        logging.debug(command)
        timezone = sub_process.p_open_stripped(command).splitlines()  # TODO: why return an array

        logging.info('Time Zone: %s', timezone)
        return timezone

    except Exception as exception:
        logging.exception('Error while getting time zone: %s', exception)
        return config.ERROR_MESSAGE


def date_to_unix(date):
    """
       This method converts the date in format 'Jun  15   15:30:00 2015' to unix time
    """
    try:
        unix = time.mktime(datetime.datetime.strptime(date, "%b  %d %H:%M:%S %Y").timetuple())
        return unix
    except Exception as exception:
        logging.exception('Error while converting date to unix: %s', exception)
        raise Exception


def unix_to_date(unix_time):
    """
    This method converts unix time into date timestamp
    """
    try:
        return datetime.datetime.utcfromtimestamp(unix_time)
    except Exception as exception:
        logging.exception('Error while converting unix to date: %s', exception)
        raise Exception


def get_unix_time_list_within_frame(time_list, time_frame):
    """
    get_unix_time_list_within_frame
    :param time_list:
    :param time_frame:
    :return:
    """
    try:
        result_list = []
        current_time = int(datetime.datetime.now().strftime("%s"))
        time_before_frame = int(
            (datetime.datetime.now() - datetime.timedelta(hours=time_frame)).strftime("%s"))

        # Find unix times within time frame
        for times in time_list:
            if current_time >= int(times) >= time_before_frame:
                result_list.append(int(times))

        return result_list
    except Exception as exception:
        logging.exception("Error: while getting restarts within time frame: %s", exception)
