"""
DTOs for polyfills & tests
"""

import json


class Response(object):
    """
    Response object for polyfills & mocks
    """
    def __init__(self, status_code=200, data=None, headers=None):
        if data is None:
            self.text = None
        else:
            self.text = json.dumps(data)
        self.status_code = status_code
        self.data = data
        self.headers = headers

    def json(self):
        """
        Return the json content of the polyfill or mock
        :return:data
        """
        return self.data

    def update(self, data):
        """
        Update the data entry(both text and data) of the instance
        :return:None
        """
        if self.text == json.dumps(self.data):
            self.text = json.dumps(data)
        self.data = data
