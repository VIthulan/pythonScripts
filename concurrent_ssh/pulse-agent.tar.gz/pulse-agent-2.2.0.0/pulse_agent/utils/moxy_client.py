"""
Moxy Component rest client
"""

import logging
from .config import config
from .rest_client import RestClient, rest_client


class MoxyClient(object):
    """
    Class for Performing requests to Moxy component end points
    """

    def __init__(self):
        self.host = self.get_appropriate_host()
        self.client = RestClient(
            host=self.host,
            response_type='verbose'
        )

    def get_appropriate_host(self):
        """
        Returns host based on the check whether re-architectured Moxy or not
        :return: host
        """
        try:
            response = rest_client.get(url=config.MOXY_URL_NEW + config.CINCO_VERSION_ENDPOINT)
            if response.status_code == 200 or response.status_code == 520:
                logging.debug("New moxy url responded success")
                return config.MOXY_URL_NEW
            return config.MOXY_URL_OLD
        except Exception as exception:
            logging.exception('Exception occurred while getting appropriate host: %s', exception)

    def get(self, path, params=None):
        """
        Perform get request to the instance env
        :param path: path
        :param params: optional query params
        :return: response json data
        """
        return self.client.get(path=path, params=params)

    def post(self, path, body):
        """
        Perform post request to the instance env
        :param path: path
        :param body: body
        :return: response json data
        """
        return self.client.post(path=path, body=body)

    def delete(self, path):
        """
        Perform post request to the instance env
        :param path: path
        :return: response json data
        """
        return self.client.delete(path=path)

    def is_new_moxy(self):
        """
        Get host
        :return: host
        """
        return self.host == config.MOXY_URL_NEW


# pylint: disable=invalid-name
moxy_client = MoxyClient()
