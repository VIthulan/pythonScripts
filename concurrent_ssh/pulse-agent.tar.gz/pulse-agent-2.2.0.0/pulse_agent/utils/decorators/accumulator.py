"""
Accumulator decorator
It takes threshold and default response as arguments for function.
Returns default response if count < threshold
Returns X if count >= threshold and X is the repeating response for all count number of func calls
Returns default response if there is no such X exists
"""
import logging


def accumulator(threshold=5, default_response='Processing'):
    """

    :param threshold: How many times that an accumulation should memorize
    :param default_response: Default response for a function call
    :return: decorator function
    """
    def decorator_func(func):
        """
        Decorator function receives function object
        :param func: function object
        :return: receiving function
        """
        memory = Memory()   # Initiate memory for specific function at declaration time

        def receiving_func(*args, **kwargs):
            """
            Receiving function receives arguments of the function
            :param args: arguments
            :param kwargs: key valued arguments
            :return: response from function call based on analysis
            """
            results = func(*args, **kwargs)
            memory.results.append(results)
            memory.count += 1
            logging.debug('Accumulator decorator, total accumulation count: %s', memory.count)
            if memory.count >= threshold and memory.results:
                status = memory.validate()
                if status is None:
                    memory.results = []
                    memory.count = 0
                    logging.debug(
                        'Returning default response from accumulator since no unique '
                        'response found after accumulation: %s', default_response)
                    return default_response
                logging.debug('Returning unique response from accumulation: %s', status)
                return status
            logging.debug('Returning default response from accumulator: %s', default_response)
            return default_response

        return receiving_func

    return decorator_func


class Memory(object):
    """
    Memory class to store the state changes and count
    """
    def __init__(self):
        self.count = 0
        self.results = []

    def validate(self):
        """
        Validate accumulated results
        :return: Result/None
        """
        if isinstance(self.results[0], list):
            return self.list_validate()
        else:
            return self.var_validate()

    def list_validate(self):
        """
        Validate accumulated result if result elements are list
        :return: value/None
        """
        list_element = None
        for arr in self.results:
            if list_element is None:
                list_element = arr
                continue
            list_element = set(list_element) - (set(list_element) - set(arr))
        if len(set(list_element)) >= 1:
            return list(set(list_element))
        return None

    def var_validate(self):
        """
        Validate accumulated result if result elements are variable
        :return: value/None
        """
        if len(set(self.results)) == 1:
            return set(self.results).pop()
        return None
