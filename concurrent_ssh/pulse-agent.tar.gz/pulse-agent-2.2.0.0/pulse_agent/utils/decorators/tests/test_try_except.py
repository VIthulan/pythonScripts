"""
Tests for decorator functions
"""

import mock
from ..try_except import try_except


def fake_side_effect_func(role):
    """
    Fake function to raise exception or return some value based on an argument
    :param role: whether or not to raise exception
    :return: string or Exception
    """
    if role == "success":
        return "Success"
    else:
        raise Exception("Fake exception")


@try_except
def example_usage_1():
    """
    Use the basic try_except decorator expecting an exception will not be raised
    :return:
    """
    fake_side_effect_func("exception")


@try_except()
def example_usage_2():
    """
    Use the basic try_except decorator expecting an exception will not be raised
    :return:
    """
    fake_side_effect_func("exception")


@mock.patch('pulse_agent.decorators.try_except.logging.error')
def test_try_except(mock_logging_error):
    """
    Call functions which uses the try_except decorator to avoid raising an exception
    :return:
    """
    example_usage_1()
    example_usage_2()
    mock_logging_error.assert_called()
