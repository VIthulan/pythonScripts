"""
Decorator functions for common tasks such as try-except, delaying, timing etc.
"""

import logging
from functools import wraps


def try_except(*args_a, **kwargs_a):
    """
    Executes side-effect functions and return the value
    :param kwargs_a: loglevel, default, ...
    :return: higher order function
    """

    loglevel = 'error'
    levels = ['debug', 'info', 'warning', 'error', 'exception']
    return_value = None

    if kwargs_a.get('level') is not None:
        loglevel = kwargs_a.get('level')
        if loglevel not in levels:
            loglevel = 'error'

    if kwargs_a.get('default') is not None:
        return_value = kwargs_a.get('default')

    def decorator_wrapper(original_function):
        """
        :param original_function: function to try and execute
        :return: function definition which will try and except the original function
        """

        @wraps(original_function)
        def wrapper(*args, **kwargs):
            """
            Call the wrapped function and fallback to defaults upon exceptions
            :param args: arguments
            :param kwargs: keyword arguments
            :return: function return value or default fallback value
            """
            try:
                return original_function(*args, **kwargs)
            except Exception as exception:
                getattr(logging, loglevel)('| %s | args: %s | kwargs: %s', exception, args, kwargs)
                return return_value

        return wrapper

    if len(args_a) > 0 and callable(args_a[0]):
        return decorator_wrapper(*args_a, **kwargs_a)

    return decorator_wrapper
