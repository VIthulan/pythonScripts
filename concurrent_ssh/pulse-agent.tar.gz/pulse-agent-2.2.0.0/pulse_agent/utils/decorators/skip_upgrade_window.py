"""
Decorator functions for common tasks such as try-except, delaying, timing etc.
"""

import logging
import datetime
from functools import wraps
from pulse_agent.utils import sub_process
from pulse_agent.utils.config import config


def skip_upgrade_window(default_response='Skipped in upgrade window'):
    """
    skip_upgrade_window
    :param default_response: Default response to send when upgrade window is detected
    :return: response
    """
    def decorator_wrapper(original_function):
        @wraps(original_function)
        def wrapper(*args, **kwargs):
            """
            Call the wrapped function and fallback to defaults upon exceptions
            :param args: arguments
            :param kwargs: keyword arguments
            :return: function return value or default fallback value
            """
            response = original_function(*args, **kwargs)
            if is_upgrade_window():
                return default_response
            return response

        return wrapper

    return decorator_wrapper


def is_upgrade_window():
    """
    Check if POS is in upgrade window
    :return: True/False
    """
    try:
        today = datetime.date.today().strftime('%Y-%m-%d')
        today_logs_grep = 'zgrep --no-filename "%s" %s | grep "UPGRADE STEP" ' % (
            today, config.MOXY_LOG_FILES)
        logging.debug(today_logs_grep)
        logs = sub_process.p_open(today_logs_grep).stdout.read().splitlines()

        upgrade_started = False
        for log_line in logs:
            if config.UPGRADE_START_MOXY_LOG in log_line:
                upgrade_started = True
                continue

            if upgrade_started is True and config.UPGRADE_COMPLETED_MOXY_LOG in log_line:
                upgrade_started = False

        if upgrade_started is True:
            logging.info('Currently POS is in upgrade process!')

        return upgrade_started
    except Exception as exception:
        logging.exception('Error while checking upgrade window :%s', exception)
