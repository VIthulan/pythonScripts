"""
Constants
"""
# ========= AGENT VERSION ======================================================================
VERSION = '2.2.0.0'

SERVER_PATH = ''

# ========= INTERVALS FOR THREADS ==============================================================
RECONNECT_INTERVAL = 10
UPDATER_INTERVAL = 180
RESTART_UPDATER_INTERVAL = 3600
INTERCONNECTIVITY_UPDATER_INTERVAL = 900
DEFAULT_IS_MOXY_RUNNING_CHECKING_INTERVAL = 3600
WHEN_ERROR_IS_MOXY_RUNNING_CHECKING_INTERVAL = 40
IS_MOXY_RUNNING_CHECK_ITERATION = 5
EVERY_MIN_THREAD_INTERVAL = 60
FIRST_QUARTER_TIMEOUT = 60 * 15
PARTIAL_COUCH_COMPACTION_CHECK_INTERVAL = 8100  # 2 hrs and 15 mins from restart
ANOMALY_DETECTION_TIMEOUT = 60 * 95  # 1 hour and 35 minutes

# ========= BUILD PROFILES =====================================================================
PROD = 'prod'
DEV = 'dev'
QA = 'qa'
DEDICATED = 'dedicated'
BUILD_ENVIRONMENT = 'BUILD_ENVIRONMENT'

# ========= LOGGERS ============================================================================
HEADING_LOGGER = 'HEADING_LOGGER'
EXCEPTION_LOGGING_WITH_MESSAGE = "%s : %s"

# ========= FILE PATHS =========================================================================
PREFS_FILE = '/home/leapset/.java/.userPrefs/CincoTinyServer/prefs.xml'
AGENT_VERSION_CONF_FILE_PATH = '/usr/local/agent-version.conf'  # agent-version conf
CONF_FILE_PATH = '/usr/local/meta.conf'
RECORDS_FILE_PATH = '/usr/local/agent-records.conf'
CHROME_DEBUG_ACTIVE_LOG = '/home/leapset/.config/google-chrome/chrome_debug.log'
CHROME_DEBUG_LOGS = '/home/leapset/.config/google-chrome/chrome_debug.log*'
NETWORK_LOG = '/home/leapset/cinco/logs/pulse_network_devices.log'
COUCH_DB_FILE_PATH = '/var/lib/couchdb/'
COUCH_LOG_FILES = '/var/log/couchdb/couch.log*'
PAYMENTS_LOG_PATH = '/home/leapset/cinco/logs/payment.log'
MOXY_LOG_FILES = '/home/leapset/cinco/logs/moxy.log*'
MOXY_WAR_PATH = '/home/leapset/cinco/moxy.war'
FRONT_END_LOG_PATH = '/home/leapset/cinco/logs/wfe.log'
DM_DEVICES_LOG = '/home/leapset/cinco/logs/dm_devices.log*'
SYS_LOG_PATH = '/var/log/syslog'
CRASH_LOG_DIR_PATH = '/home/leapset/cinco/'
ETH0_FILE_PATH = '/sys/class/net/eth0'
RESTART_DATA_PKL_FILE = "/home/leapset/pulse/restart.pkl"
CINCO_VERSION_PKL_FILE = "/home/leapset/pulse/cinco_version.pkl"
DIAGNOSIS_DATA_PKL_FILE = "/home/leapset/pulse/diagnosis_jsons.pkl"
JVM_CRASH_CATEGORY_PATTERNS_FILE = '/home/leapset/pulse/jvm_crash_category.pkl'
NETWORK_INTERCONNECTIVITY_IP_LIST_FILE = '/home/leapset/pulse/interconnectivity_ip_list.pkl'
VERSION_INFO = '/home/leapset/system/version.info'
AUTH_FILE_PATH = '/usr/local/auth.conf'
LP_PULSE_LOG_FILES = '/var/log/upstart/lp-pulse.log*'
CPM_LOG_PATH = '/home/leapset/cinco/logs/cpm.log'
CPM_ALL_LOGS_PATH = '/home/leapset/cinco/logs/cpm.log*'

# ========= COMMON CONSTANTS ===================================================================
BUILD_ENV = "build.environment"
MERCHANT_ID = "merchant.id"
STATION_ID = "station.id"
CLIENT_VERSION = "merchant.client.version"
KEY = 'key'
VALUE = 'value'
ENTRY = 'entry'
THREAD_POOL_SIZE = 10
ENCODING = 'utf-8'
CPU_LOAD5 = 0
CPU_LOAD10 = 1
CPU_LOAD15 = 2
CPU_BITS = 0
PARTIION_NAME = 0
PARTITION_USED = 2
PARTITION_AVAILABE = 3
PARTITION_MOUNT_POINT = 5
COUCH_COMPACTION_START_TIME = '03:00:00'
COUCH_COMPACTION_END_TIME = '04:00:00'
APP_ID = 'pulse-agent'
APP_SECRET = "app-secret"
FIXED_RESTART_START_TIME = '03:00:00'
FIXED_RESTART_END_TIME = '03:15:00'
GET = 'GET'
POST = 'POST'
COUCH_FILE_SIZE_THRESHOLD = 50
ETH0_NETWORK_INTERFACE = 'eth0'
THRESHOLD_WAIT_TO_CHECK_MOXY_STATUS = 60
MOXY_IS_RUNNING_AFTER_GDM_RESTART = 1
MOXY_IS_NOT_RUNNING_AFTER_GDM_RESTART = 0
PEER_REGISTER_USER = 'root'

# ========= SEARCH PATTERNS ====================================================================

# ========= ERROR MESSAGES =====================================================================
ERROR_MESSAGE = "ERROR"

# ========= URLS ===============================================================================
MOXY_URL_NEW = 'http://localhost:8080/moxy'
MOXY_URL_OLD = 'http://localhost:8080'

# ========= END POINTS =========================================================================
# -- LOCAL ---
CINCO_VERSION_ENDPOINT = '/rest/application/version'
PARTIAL_COMPACT_FILE_REMOVAL_END_POINT = '/rest/pulse/compactFiles'
MOXY_NETWORK_ENDPOINT = '/rest/pulse/notify/operator/'

# -- PULSE ---
POST_RESTART_CHECKS_END_POINT = '/api/v1/device/postRestartChecks'
APP_SECRET_END_POINT = '/getAppSecret'
DIAGNOSIS_END_POINT = '/api/v1/diagnosis/update'
SWIPES_ENDPOINT = '/api/v1/payment/saveswipes'
PAYMENT_SANITY_ENDPOINT = '/api/v1/payment/paymentSanity'
UPDATE_END_POINT = "/api/v1/pos/update"
JVM_CRASH_CATEGORY_PATTERNS_END_POINT = '/api/v1/diagnosis/jvmCrashCategories'
NETWORK_INTERCONNECTIVITY_END_POINT = '/api/v1/network/deviceConfig'
NETWORK_ADVANCED_CHECK_RESULT_END_POINT = '/api/v1/network/passAdvanceAnalysisResult'
NETWORK_INTERCONNECTIVITY_RESULT_END_POINT = '/api/v1/network/networkUpdate'
NETWORK_INTERCONNECTIVITY_TRACE_ROUTE_END_POINT = '/api/v1/network/passTraceRouteResult'
NETWORK_INTERCONNECTIVITY_UDP_LOSS_FINDER_RESULT_END_POINT = '/api/v1/network/passUdpResult'
ISP_SPEED_URL_END_POINT = '/api/v1/device/ispurl'
CLEAN_HARD_DISK_END_POINT = '/api/v1/device/cleanHddResponse'
DEBUG_SCRIPT_RESULT_END_POINT = '/api/v1/device/onDemandDebugExecutionResult'
ON_DEMAND_LP_PULSE_CHECK_RESULT_END_POINT = '/api/v1/network/onDemandLpPulseCheckResult'
SAVE_LOGS_RESULT_END_POINT = '/api/v1/device/saveLogsResponse'
LOG_COLLECTION_RESPONSE_END_POINT = '/api/v1/device/collectAndUploadLogsResponse'
APP_STATE_CHECK_ENDPOINT = '/api/v1/pos/appStateUpdate'
ON_DEMAND_COUCH_SYNC = '/api/v1/cloudCouch/syncMerchantInfoFromCouch'
ANOMALIES_END_POINT = '/api/v1/deviceAnomalies/anomalies'
IMAGE_UPGRADE_FLAG_END_POINT = '/api/v1/osUpgrade/updateImageUpgradeFlag'

# ========= MESSAGES ===========================================================================
MOXY_IS_RUNNING = 'moxy is running'
MOXY_IS_NOT_RUNNING = 'moxy is not running'
AVOID_MOXY_RUNNING_CHECK = 'avoid moxy running check as below 6.20'
MESSAGE_COMPACTION_RUNNING = 'Compaction may be still running'

# ========= SSH SETTINGS ========================================================================
SSH_USER = 'support'
DEV_SSH_USER = 'support'
SSH_KEY = '/home/leapset/.ssh/id_dsa'
SSH_OPTS = '-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no'
AGENT_PATH = '/home/support/pulse-agent-latest.tar.gz'

# ========= FEATURE CONSTANTS ==================================================================

# -- Couch indexing timeout --
COUCH_INDEXING_TIMEOUT_BUFFERED_SPAN = 60 * 5
COUCH_INDEXING_TIMEOUT_PATTERN = 'preProcessor:PREPROCESSOR_TIME_OUT'
COUCH_INDEXING_TIMEOUT = 'COUCH_INDEXING_TIMEOUT'
COUCH_INDEXING_TIMEOUT_DESCRIPTION = 'Couch indexing timeout found from chrome-dubug.log'

# -- Couch Compaction checks --
PARTIAL_COUCH_COMPACTION = 'COUCH_PARTIAL_COMPACTION'
PARTIAL_COUCH_COMPACTION_DESCRIPTION = ('partial couch compaction file available in '
                                        '/var/lib/couchdb/* or /var/lib/couchdb/.*/mrview')

# -- Post Tool Alert checks --
POST_TOOL_ALERT = 'POST_TOOL_ALERT'
POST_TOOL_ALERT_DESCRIPTION = 'Post Tool Alert pops up on the POS screen'

# -- POS DIAGNOSIS--
MESSAGE_XORG_TAINTED = 'Xorg has been Tainted'
MESSAGE_TOUCH_FIXES_NOT_APPLIED = 'Touch fixes has not been applied'
MESSAGE_TOUCH_DRIVER_CONFIG_ERROR = 'Touch driver configuration error'
MESSAGE_COUCH_CORRUPTION = 'CouchDb file corruption found'
MESSAGE_HD_FAILURES_FOUND = 'HD faliures found'
MESSAGE_KERNEL_DISK_READ_FAILURES_FOUND = 'Kernel disk read faluires found'
MESSAGE_MOXY_CORRUPTIONS_FOUND = 'Moxy corruptions found'
MESSAGE_STUCK_ON_LOADING_FOUND = 'Stuck on Loading Found'
MESSAGE_CARD_READER_NOT_FOUND = 'Card Reader not found'
MESSAGE_PAYMENT_DECRYPT_ERROR = 'Track data cannot be decrypted exceeds threshold'
MESSAGE_SAMRTMON_SELF_ASSESSMENT_FAILED = 'SMART overall-health self-assessment test failed'
MESSAGE_COUCH_LOG_SIZE_EXCEEDS_THRESHOLD = 'One or more couch log files exceeds threshold'
MESSAGE_FAILED_ORDER_FOUND = 'Failed Order Found',
MESSAGE_COUCH_DB_SIZE_EXCEEDS = 'Couch DB size exceeds the threshold'
MOXY_WAR_NOT_FOUND = 'moxy.war not found in standard location'
ETH_0_NOT_AVAILABLE = 'eth0 interface not available'
FIRMWARE_UPGRADE_FAIL = 'firmware upgrade failure'
PRINT_START_SWIPES_DATA_UPDATE = "START UPDATING SWIPES DATA ....."

# -- JVM Crashes --
JVM_CRASHES_FOUND = 'JVM crashes found'
JVM_CRASH_CATEGORY_PATTERNS_FILE_PATH = '/home/leapset/pulse/jvm_crash_category.pkl'

# -- MSR --
AUTHORIZING_NETWORK_DECLINED_THE_TRANSACTION = 'authorizing network declined the transaction'
MSR_IS_NOT_SWIPING_CARDS = 'MSR is not swiping cards'
KSN_HAS_INCORRECT_FORMAT = 'KSN has incorrect format'
MSR_SENDS_BAD_DATA = 'MSR sends bad data'
BURNED_MSR = 'Burned MSR'
MSR_IS_BURNED_OR_CABLE_MAY_BE_BROKEN = 'MSR is burned or cable may be broken'
KSN_INVALID_ = 'Invalid KSN'

MSR_ISSUE_DETECTED = 'MSR issue detected'

# -- LP PULSE CHECK --
ERROR_CHECKING_LP_PULSE_STATE = 'ERROR_CHECKING_LP_PULSE_STATE'
LP_PULSE_NOT_INSTALLED = 'LP_PULSE_NOT_INSTALLED'
LP_PULSE_INSTALLED = 'LP_PULSE_INSTALLED'

# -- Log Uploader --

COLLECT_AND_UPLOAD_LOGS_PHASE_1_COMPLETE = 'COLLECT_AND_UPLOAD_LOGS_PHASE_1_COMPLETE'
COLLECT_AND_UPLOAD_LOGS_PHASE_2_COMPLETE = 'COLLECT_AND_UPLOAD_LOGS_PHASE_2_COMPLETE'
COLLECT_AND_UPLOAD_LOGS_PHASE_3_COMPLETE = 'COLLECT_AND_UPLOAD_LOGS_PHASE_3_COMPLETE'
COLLECT_AND_UPLOAD_LOGS_SUCCESS = 'COLLECT_AND_UPLOAD_LOGS_SUCCESS'
COLLECT_AND_UPLOAD_LOGS_FAILURE = 'COLLECT_AND_UPLOAD_LOGS_FAILURE'

LOG_FILE_META_DATA = {
    'MOXY': {'path': '/home/leapset/cinco/logs/', 'active': 'moxy.log', 'past_prefix': 'moxy.log.'},
    'COUCH': {'path': '/var/log/couchdb/', 'active': 'couch.log', 'past_prefix': 'couch.log.'},
    'PAYMENT': {'path': '/home/leapset/cinco/logs/', 'active': 'payment.log',
                'past_prefix': 'payment.log.'},
    'CHROME_DEBUG': {'path': '/home/leapset/.config/google-chrome/', 'active': 'chrome_debug.log',
                     'past_prefix': 'chrome_debug.log.'}}

LOG_SERVER_USERNAME = 'root'
LOG_FILE_IDENTIFIER = 'pos_logs'
LOG_SERVER_REMOTE_BASE_PATH = '/'
LOCAL_LOG_DIRECTORY = '/home/leapset/pulse/log-files/'
LOCAL_LOG_ZIP_DIRECTORY = '/home/leapset/pulse'

# -- Self report error --
ERROR_SELF_REPORT_FOUND = 'Self Reported Error'

# -- TimeZone not synced --
ACTUAL_TIME_END_POINT = '/rest/pulse/timeInformation'
TIME_NOT_SYNCED_DESC = 'POS time is out of sync from actual timezone'
TIME_NOT_SYNCED = 'TIME_NOT_SYNCED'

# -- Image Upgrade flag set feature --
IMAGE_UPGRADE_FLAG_PATH = '/home/leapset/image_upgrade'
PROCESSOR_32_BIT = "32bit"

# -- Upgrading window logs --
UPGRADE_START_MOXY_LOG = 'checking for merchant upgrade state, Current state is START'
UPGRADE_COMPLETED_MOXY_LOG = 'Detected device initial state :UPTODATE'
