"""
Configurations related to environments
"""
ENV_CONFIG = {
    'dev': {
        'API_SERVER_URL': 'dev-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'dev-pulse.leapset.com'
    },
    'pos1': {
        'API_SERVER_URL': 'pos1-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'pos1-pulse.leapset.com'
    },
    'pos2': {
        'API_SERVER_URL': 'pos2-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'pos2-pulse.leapset.com'
    },
    'pos3': {
        'API_SERVER_URL': 'pos3-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'pos3-pulse.leapset.com'
    },
    'pos4': {
        'API_SERVER_URL': 'pos4-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'pos4-pulse.leapset.com'
    },
    'prod': {
        'API_SERVER_URL': 'pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'pulse.leapset.com'
    },
    'qa': {
        'API_SERVER_URL': 'dev-ops.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'support-dev.leapset.com'
    },
    'stag': {
        'API_SERVER_URL': 'stag-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'stag-pulse.leapset.com'
    },
    'tst1': {
        'API_SERVER_URL': 'tst1-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'tst1-pulse.leapset.com'
    },
    'tst2': {
        'API_SERVER_URL': 'tst2-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'tst2-pulse.leapset.com'
    },
    'tst3': {
        'API_SERVER_URL': 'tst3-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'tst3-pulse.leapset.com'
    },
    'tst4': {
        'API_SERVER_URL': 'tst4-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'tst4-pulse.leapset.com'
    },
    'tst5': {
        'API_SERVER_URL': 'tst5-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'tst5-pulse.leapset.com'
    },
    'tst6': {
        'API_SERVER_URL': 'tst6-pulse.leapset.com',
        'API_SERVER_PORT': 8080,
        'TUNNEL_SERVER': 'tst6-pulse.leapset.com'
    }
}
