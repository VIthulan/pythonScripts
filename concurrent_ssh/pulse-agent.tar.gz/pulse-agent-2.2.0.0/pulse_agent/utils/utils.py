import logging
import subprocess as subproc
from pulse_agent.utils import sub_process


def kill_process(process_name):
    try:
        proc = sub_process.p_open_default(["pgrep", process_name], stdout=subproc.PIPE)
        pid_list = proc.stdout
        for pid in pid_list:
            sub_process.p_open_default(["kill", "-9", pid.rstrip()], stdout=subproc.PIPE)
    except OSError as exception:
        logging.exception('OSError while killing the process: %s', exception)
    except Exception as exception:
        logging.exception('Error while killing the process: %s', exception)
