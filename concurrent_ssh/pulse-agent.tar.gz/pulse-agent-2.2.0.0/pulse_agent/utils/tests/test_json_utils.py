"""
Unit tests for the json_utils module
"""
import mock

#Test Module
from pulse_agent.utils import json_utils


@mock.patch('json.dumps')
def test_get_pretty_json(mock_dumps):
    """
    Test for get_pretty_json
    :param mock_dumps: magic mock object of json.dumps method
    :return: None
    """

    #Check if it follows the path
    mock_dumps.return_value = 'ret_value'
    assert json_utils.get_pretty_json('data') == 'ret_value'


    #Check if it handles exceptions
    mock_dumps.side_effect = Exception
    assert json_utils.get_pretty_json('data') == 'data'

@mock.patch('json.dumps')
def test_get_json_dump(mock_dumps):
    """
    Test for get_json_dump
    :param mock_dumps: magic mock object of json.dumps method
    :return: None
    """

    #Check if it follows the path
    mock_dumps.return_value = 'ret_value'
    assert json_utils.get_json_dump('data') == 'ret_value'


    #Check if it handles exceptions
    mock_dumps.side_effect = Exception
    assert json_utils.get_json_dump('data') == 'data'
