"""
Unit tests for the json_utils module
"""
import mock
import math
import pytest

# Test Module
from pulse_agent.utils import file_utils

from pulse_agent.utils.config import config


class ConfigObj(object):
    """
    mock ConfigObj object
    """

    def __init__(self, key=''):
        self.key = key

    def __setitem__(self, key, val):
        return None

    def write(self):
        """
        mock write method
        """
        return None

    def update(self, val):
        """
        mock update method
        """
        return None


class StatInfo(object):
    """
    mock StatInfo object
    """

    def __init__(self, st_size=0):
        self.st_size = st_size
        self.st_mtime = 0


@mock.patch('configobj.ConfigObj')
def test_load_config(
        mock_ConfigObj):
    """
    Test for load_config
    :param mock_ConfigObj: magic mock object of ConfigObj method
    :return: None
    """
    mock_ConfigObj.return_value = None
    file_utils.load_config("url")
    mock_ConfigObj.assert_called_with(
        "url",
        raise_errors=True,
        file_error=True,
        encoding=config.ENCODING,
        default_encoding=config.ENCODING
    )


@mock.patch('pulse_agent.utils.tests.test_file_utils.ConfigObj.write')
@mock.patch('pulse_agent.utils.file_utils.load_config')
def test_update_conf_file(mock_load_config, mock_write):
    """
    Test for load_config
    :param mock_load_config: magic mock object of load_config method
    :param mock_write: magic mock object of write method
    :return: None
    """

    # Check if it follows the path
    mock_load_config.return_value = ConfigObj()
    mock_write.return_value = None

    file_utils.update_conf_file('conf_file', 'key', 'value')
    mock_write.assert_called_with()

    # Check if it handles exceptions
    mock_load_config.side_effect = Exception
    mock_write.return_value = None

    file_utils.update_conf_file('conf_file', 'key', 'value')
    expected_calls = [mock.call()]
    assert mock_write.mock_calls == expected_calls


@mock.patch('pulse_agent.utils.tests.test_file_utils.ConfigObj.write')
@mock.patch('pulse_agent.utils.file_utils.load_config')
def test_update_last_heart_beat(mock_load_config, mock_write):
    """
    Test for update_last_heart_beat
    :param mock_load_config: magic mock object of load_config method
    :param mock_write: magic mock object of write method
    :return: None
    """

    # Check if it follows the path
    mock_load_config.return_value = ConfigObj()
    mock_write.return_value = None

    file_utils.update_last_heart_beat('03:15')
    mock_write.assert_called_with()

    # Check if it handles exceptions
    mock_load_config.side_effect = Exception
    mock_write.return_value = None

    file_utils.update_last_heart_beat('03:15')
    expected_calls = [mock.call()]
    assert mock_write.mock_calls == expected_calls


@mock.patch('os.stat')
@mock.patch('glob.glob')
def test_get_file_size_array(mock_glob, mock_stat):
    """
    Test for get_file_size_array
    :param mock_glob: magic mock object of glob method
    :param mock_stat: magic mock object of stat method
    :return: None
    """

    # When files exist
    size = 500 * math.pow(1024, 2)
    mock_glob.return_value = ['file_01', 'file_02']
    statinfo = StatInfo(st_size=size + 1)
    mock_stat.return_value = statinfo
    assert file_utils.get_file_size_array('path') == \
           [500.0000009536743, 500.0000009536743]

    # When files do not exist
    mock_glob.return_value = []
    statinfo = StatInfo(st_size=size + 1)
    mock_stat.return_value = statinfo
    assert file_utils.get_file_size_array('path') == []

    # Check if it handles exceptions
    mock_glob.side_effect = Exception
    statinfo = StatInfo(st_size=size + 1)
    mock_stat.return_value = statinfo
    assert file_utils.get_file_size_array('path') == []


@mock.patch('pulse_agent.utils.file_utils.get_file_size_array')
def test_does_file_exceeds_threshold(mock_get_file_size_array):
    """
    Test for does_file_exceeds_threshold
    :param mock_get_file_size_array: magic mock object of get_file_size_array method
    :return: None
    """

    # When two files exceeds threshold
    mock_get_file_size_array.return_value = [502, 503]
    assert file_utils.does_file_exceeds_threshold('path', 500)

    # When one file exceeds threshold
    mock_get_file_size_array.return_value = [490, 503]
    assert file_utils.does_file_exceeds_threshold('path', 500)

    # When no files exceeds threshold
    mock_get_file_size_array.return_value = [400, 450]
    assert not file_utils.does_file_exceeds_threshold('path', 500)

    # Check if it handles exceptions
    mock_get_file_size_array.side_effect = Exception
    assert file_utils.does_file_exceeds_threshold('path', 500)


@mock.patch('pulse_agent.utils.tests.test_file_utils.ConfigObj.write')
@mock.patch('pulse_agent.utils.file_utils.load_config')
def test_update_statistics(mock_load_config, mock_write):
    """
    Test for update_statistics
    :param mock_load_config: magic mock object of load_config method
    :param mock_write: magic mock object of write method
    :return: None
    """

    # Check if it follows the path
    mock_load_config.return_value = ConfigObj()
    mock_write.return_value = None

    file_utils.update_statistics('version', 'ctd')
    mock_write.assert_called_with()

    # Check if it handles exceptions
    mock_load_config.side_effect = Exception
    mock_write.return_value = None

    file_utils.update_statistics('version', 'ctd')
    expected_calls = [mock.call()]
    assert mock_write.mock_calls == expected_calls


@mock.patch('pulse_agent.utils.tests.test_file_utils.ConfigObj.write')
@mock.patch('pulse_agent.utils.file_utils.load_config')
def test_update_startup_status(mock_load_config, mock_write):
    """
    Test for update_startup_status
    :param mock_load_config: magic mock object of load_config method
    :param mock_write: magic mock object of write method
    :return: None
    """

    # Check if it follows the path
    mock_load_config.return_value = ConfigObj()
    mock_write.return_value = None

    file_utils.update_startup_status('status')
    mock_write.assert_called_with()

    # Check if it handles exceptions
    mock_load_config.side_effect = Exception
    mock_write.return_value = None

    file_utils.update_startup_status('status')
    expected_calls = [mock.call()]
    assert mock_write.mock_calls == expected_calls


@mock.patch('pulse_agent.utils.tests.test_file_utils.ConfigObj.write')
@mock.patch('pulse_agent.utils.file_utils.load_config')
def test_update_upgrade_rq_status(mock_load_config, mock_write):
    """
    Test for update_upgrade_rq_status
    :param mock_load_config: magic mock object of load_config method
    :param mock_write: magic mock object of write method
    :return: None
    """

    # Check if it follows the path
    mock_load_config.return_value = ConfigObj()
    mock_write.return_value = None

    file_utils.update_upgrade_rq_status("status")
    mock_write.assert_called_with()

    # Check if it handles exceptions
    mock_load_config.side_effect = Exception
    mock_write.return_value = None

    with pytest.raises(Exception):
        file_utils.update_upgrade_rq_status("status")
        expected_calls = [mock.call()]
        assert mock_write.mock_calls == expected_calls


@mock.patch('pulse_agent.utils.tests.test_file_utils.ConfigObj.write')
@mock.patch('pulse_agent.utils.file_utils.load_config')
def test_update_version_to_upgrade(mock_load_config, mock_write):
    """
    Test for update_statistics
    :param mock_load_config: magic mock object of load_config method
    :param mock_write: magic mock object of write method
    :return: None
    """

    # Check if it follows the path
    mock_load_config.return_value = ConfigObj()
    mock_write.return_value = None

    file_utils.update_version_to_upgrade('version')
    mock_write.assert_called_with()

    # Check if it handles exceptions
    mock_load_config.side_effect = Exception
    mock_write.return_value = None

    with pytest.raises(Exception):
        file_utils.update_version_to_upgrade('version')
        expected_calls = [mock.call()]
        assert mock_write.mock_calls == expected_calls


@mock.patch('shutil.make_archive')
def test_compress_logs(mock_make_archive):
    """
    Test for compress_logs
    :param mock_make_archive: magic mock object of make_archive method
    :return: None
    """

    # Check if it follows the path
    mock_make_archive.return_value = None
    file_utils.compress_logs('src_dir', 'dest_dir', 'file_name')
    mock_make_archive.assert_called_with("{}/{}".format('dest_dir', 'file_name'), 'zip', 'src_dir')

    # Check if it handles exceptions
    mock_make_archive.side_effect = Exception
    with pytest.raises(Exception):
        file_utils.compress_logs('src_dir', 'dest_dir', 'file_name')
        mock_make_archive.assert_called_with("{}/{}".format('dest_dir', 'file_name'), 'zip', 'src_dir')
