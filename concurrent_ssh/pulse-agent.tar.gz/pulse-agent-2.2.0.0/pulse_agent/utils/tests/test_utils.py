"""
Unit tests for the utils module
"""
import subprocess as subproc
import mock
from mock import MagicMock

#Test Module
from pulse_agent.utils import utils

@mock.patch('pulse_agent.utils.sub_process.p_open_default')
def test_kill_process(mock_p_open_default):
    """
    Test for kill_process
    :param mock_p_open_default: magic mock object of p_open_default method
    :return: None
    """

    #Check if it follows the path
    messages = MagicMock(stdout=['pid_01', 'pid_02'])
    mock_p_open_default.return_value = messages
    expected_calls = [
        mock.call(["pgrep", "process"], stdout=subproc.PIPE),
        mock.call(["kill", "-9", 'pid_01'], stdout=subproc.PIPE),
        mock.call(["kill", "-9", 'pid_02'], stdout=subproc.PIPE)
    ]
    utils.kill_process("process")
    assert mock_p_open_default.mock_calls == expected_calls

    #Check if it handles OSError
    mock_p_open_default.side_effect = OSError
    expected_calls = [
        mock.call(["pgrep", "process"], stdout=subproc.PIPE),
        mock.call(["kill", "-9", 'pid_01'], stdout=subproc.PIPE),
        mock.call(["kill", "-9", 'pid_02'], stdout=subproc.PIPE),
        mock.call(["pgrep", "process"], stdout=subproc.PIPE)
    ]
    utils.kill_process("process")
    assert mock_p_open_default.mock_calls == expected_calls

    #Check if it handles exceptions
    mock_p_open_default.side_effect = Exception
    expected_calls = [
        mock.call(["pgrep", "process"], stdout=subproc.PIPE),
        mock.call(["kill", "-9", 'pid_01'], stdout=subproc.PIPE),
        mock.call(["kill", "-9", 'pid_02'], stdout=subproc.PIPE),
        mock.call(["pgrep", "process"], stdout=subproc.PIPE),
        mock.call(["pgrep", "process"], stdout=subproc.PIPE)
    ]
    utils.kill_process("process")
    assert mock_p_open_default.mock_calls == expected_calls
