"""
Unit tests for the s3_client module
"""
import mock
import pytest

#Test Module
from pulse_agent.utils import s3_client

@mock.patch('boto3.client')
def test_get_s3_client(mock_client):

    #Check if it follows the path
    mock_client.return_value = 'Return_value'
    assert s3_client.get_s3_client('aws_access_key_id', 'aws_secret_access_key', 'region_name') == 'Return_value'


    #Check if it handles exceptions
    mock_client.side_effect = Exception
    with pytest.raises(Exception):
        s3_client.get_s3_client('aws_access_key_id', 'aws_secret_access_key', 'region_name')
