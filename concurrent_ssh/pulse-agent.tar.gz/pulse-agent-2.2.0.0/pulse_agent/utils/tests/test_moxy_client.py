"""
Unit tests for the pulse_client module
"""
import json
import mock
from pulse_agent.utils.tests.stub_manager import decorate_mock_request
from pulse_agent.utils.moxy_client import MoxyClient
from pulse_agent.utils.dtos import Response


@mock.patch('pulse_agent.utils.moxy_client.MoxyClient.get_appropriate_host')
@mock.patch('pulse_agent.utils.rest_client.request')
def test_get(mock_request, mock_get_appropriate_host):
    """
    Test for the get requests of pulse_client
    :param mock_request: magic mock object of request method
    :param mock_get_appropriate_host: magic mock object of mock_get_appropriate_host method
    :return: None
    """
    # Mock calls
    decorate_mock_request(mock_request, 200, {'data': 'some data'})
    mock_get_appropriate_host.return_value = 'http://localhost:8080/moxy'

    # Create instance
    moxy_client = MoxyClient()

    # Perform actions
    response_data = moxy_client.get('/custom/path')

    # Assert whether the required calls were made

    mock_request.assert_called_once_with(headers={'content-type': 'application/json'},
                                         data=None,
                                         method='get',
                                         timeout=60,
                                         url='http://localhost:8080/moxy/custom/path',
                                         params=None)

    # Assert the response data
    assert response_data.json() == {'data': 'some data'}


@mock.patch('pulse_agent.utils.moxy_client.MoxyClient.get_appropriate_host')
@mock.patch('pulse_agent.utils.rest_client.request')
def test_post(mock_request, mock_get_appropriate_host):
    """
    Test for the post requests of pulse_client
    :param mock_request: magic mock object of request method
    :param mock_get_appropriate_host: magic mock object of mock_get_appropriate_host method
    :return: None
    """
    # Mock calls
    decorate_mock_request(mock_request, 200, {'data': 'some data'})
    mock_get_appropriate_host.return_value = 'http://localhost:8080/moxy'

    # Create instance
    moxy_client = MoxyClient()

    # Perform actions
    response_data = moxy_client.post('/custom/path', body={
        'some_count': 5
    })

    # Assert whether the required calls were made

    mock_request.assert_called_once_with(headers={'content-type': 'application/json'},
                                         data=json.dumps({
                                             'some_count': 5,
                                         }),
                                         method='post',
                                         timeout=60,
                                         url='http://localhost:8080/moxy/custom/path',
                                         params=None)

    # Assert the response data
    assert response_data.json() == {'data': 'some data'}


@mock.patch('pulse_agent.utils.moxy_client.MoxyClient.get_appropriate_host')
def test_get_host(mock_get_appropriate_host):
    """
    Test for the get host of pulse_client
    :param mock_get_appropriate_host: magic mock object of get_appropriate_host method
    :return: None
    """
    # Mock calls
    mock_get_appropriate_host.return_value = 'http://localhost:8080/moxy'

    # Create instance
    moxy_client = MoxyClient()

    # Assert the response data
    assert moxy_client.is_new_moxy() is True


@mock.patch('pulse_agent.utils.rest_client.RestClient.get')
def test_get_appropriate_host(mock_get):
    """
    Test for the get appropriate host of pulse_client
    :param mock_get: magic mock object of Rest Client get method
    :return: None
    """

    # Mock calls
    mock_get.return_value = Response(200, data={'data': 'some data'})

    # Create instance
    moxy_client = MoxyClient()

    assert moxy_client.get_appropriate_host() == 'http://localhost:8080/moxy'

    # Mock calls
    mock_get.return_value = Response(404)

    # Create instance
    moxy_client = MoxyClient()

    assert moxy_client.get_appropriate_host() == 'http://localhost:8080'
