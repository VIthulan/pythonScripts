"""
Unit tests for the pulse_client module
"""
import mock
import json
from stub_manager import decorate_mock_request
from pulse_agent.utils.config_managers.tests.stub_manager import decorate_mock_get_node_server_url
from pulse_agent.utils.pulse_client import PulseClientProxy
from pulse_agent.utils.dtos import Response


@mock.patch('pulse_agent.utils.pulse_client.server_config_manager.get_node_server_url')
@mock.patch('pulse_agent.utils.pulse_client.PulseClient.post')
@mock.patch('pulse_agent.utils.rest_client.request')
def test_get(mock_request, mock_post, mock_get_node_server_url):
    """
    Test for the get requests of pulse_client
    :param mock_request: magic mock object of request method
    :param mock_post: magic mock object of post method of the PulseClient
    :param mock_get_node_server_url: magic mock of get_node_server_url method
    :return: None
    """
    # Mock calls
    decorate_mock_request(mock_request, 200, {'data': 'some data'}, {'data': 'some other data'})
    mock_post.return_value = Response(200, headers={
        'app-secret': 'some_secret'
    })
    decorate_mock_get_node_server_url(mock_get_node_server_url)

    # Create instance
    pulse_client = PulseClientProxy()

    # Perform actions
    pulse_client.setup_identity('m_id:1', 'm_id', 1)
    response_data = pulse_client.get('/custom/path')

    # Assert whether the required calls were made
    calls = [
        mock.call(
            headers={
                'content-type': 'application/json',
                'device-id': 'm_id:1',
                'app-id': 'pulse-agent',
                'app-secret': 'some_secret'
            },
            data=None,
            method='get',
            timeout=5,
            url='https://dev-pulse.leapset.com:8080/custom/path',
            params=None
        ),
        mock.call(
            headers={
                'content-type': 'application/json',
                'device-id': 'm_id:1',
                'app-id': 'pulse-agent',
                'app-secret': 'some_secret'
            },
            data=None,
            method='get',
            timeout=5,
            url='https://pulse.leapset.com:8080/custom/path',
            params=None
        )
    ]
    mock_request.assert_has_calls(calls, any_order=True)

    # Assert the response data
    assert response_data['dedicated'].json() == {'data': 'some data'}
    assert response_data['dev'].json() == {'data': 'some other data'}


@mock.patch('pulse_agent.utils.pulse_client.server_config_manager.get_node_server_url')
@mock.patch('pulse_agent.utils.pulse_client.PulseClient.login')
@mock.patch('pulse_agent.utils.rest_client.request')
def test_post(mock_request, mock_login, mock_get_node_server_url):
    """
        Test for the post requests of pulse_client
        :param mock_request: magic mock object of request method
        :param mock_login: magic mock object of login method of PulseClient
        :param mock_get_node_server_url: magic mock of get_node_server_url method
        :return: None
    """
    # Mock calls
    decorate_mock_request(mock_request, 200, {'data': 'some data'}, {'data': 'some other data'})
    mock_login.return_value = None
    decorate_mock_get_node_server_url(mock_get_node_server_url)

    # Create instance
    pulse_client = PulseClientProxy()

    # Perform actions
    pulse_client.setup_identity('m_id:2', 'm_id', 2)
    response_data = pulse_client.post('/custom/path', body={
        'some_count': 5
    })

    # Assert whether the required calls were made
    calls = [
        mock.call(
            method='post',
            url='https://dev-pulse.leapset.com:8080/custom/path',
            headers={
                'content-type': 'application/json',
                'device-id': 'm_id:2',
                'app-id': 'pulse-agent'
            },
            data=json.dumps({
                'some_count': 5,
                'MERCHANT_ID': 'm_id',
                'REGISTER_NO': 2
            }),
            timeout=5,
            params=None
        ),
        mock.call(
            url='https://pulse.leapset.com:8080/custom/path',
            method='post',
            headers={
                'content-type': 'application/json',
                'device-id': 'm_id:2',
                'app-id': 'pulse-agent'
            },
            data=json.dumps({
                'some_count': 5,
                'MERCHANT_ID': 'm_id',
                'REGISTER_NO': 2
            }),
            timeout=5,
            params=None
        )
    ]
    mock_request.assert_has_calls(calls, any_order=True)

    # Assert the response data
    assert response_data['dedicated'].json() == {'data': 'some data'}
    assert response_data['dev'].json() == {'data': 'some other data'}
