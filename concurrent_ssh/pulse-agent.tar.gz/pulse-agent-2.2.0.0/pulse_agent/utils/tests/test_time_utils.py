"""
tests for time_utils module
"""
# core modules
import logging
import datetime
import mock

# testing module
from pulse_agent.utils import time_utils

# helper
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


@mock.patch('pulse_agent.utils.sub_process.p_open_stripped')
def test_get_timezone(mock_p_open_stripped):
    """
    test get_timezone()
    :param mock_p_open_stripped: mock call to pulse_agent.utils.sub_process.p_open_stripped()
    """
    # checks whether it works as expected
    mock_p_open_stripped.return_value = 'America/New York\n'
    assert time_utils.get_timezone() == ['America/New York']
    assert mock_p_open_stripped.mock_calls == [mock.call('cat /etc/timezone')]

    # checks whether it handles exceptions properly
    mock_p_open_stripped.side_effect = Exception
    assert time_utils.get_timezone() == config.ERROR_MESSAGE


def test_date_to_unix():
    """
    test date_to_unix()
    """
    # checks whether it works as expected if
    assert time_utils.date_to_unix('Jun  15   15:30:00 2015') == 1434362400.0

    # checks whether it handles exceptions properly
    try:
        time_utils.date_to_unix(None)
        assert False
    except Exception:
        assert True


def test_unix_to_date():
    """
    test unix_to_date()
    """
    # checks whether it works as expected if
    assert time_utils.unix_to_date(1434362400.0) == datetime.datetime(2015, 6, 15, 10, 0)

    # checks whether it handles exceptions properly
    try:
        time_utils.unix_to_date(None)
        assert False
    except Exception:
        assert True


def test_get_unix_time_list_within_frame():
    """
    test get_unix_time_list_within_frame()
    """
    # checks whether it works as expected if
    time_1 = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%s")
    time_2 = (datetime.datetime.now() - datetime.timedelta(hours=5)).strftime("%s")
    time_3 = (datetime.datetime.now() - datetime.timedelta(hours=10)).strftime("%s")
    time_list = [time_1, time_2, time_3]
    time_frame = 8
    assert time_utils.get_unix_time_list_within_frame(time_list, time_frame) == [int(time_1), int(time_2)]

    # checks whether it handles exceptions properly
    assert time_utils.get_unix_time_list_within_frame(None, time_frame) is None
