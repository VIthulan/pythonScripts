"""
All mock decoration logic of the util package are defined in this modules
"""
from pulse_agent.utils.dtos import Response


def decorate_mock__request(mock__request):
    """
    mock functionality of the mock__request stub method
    :param mock__request: mock of the _request method
    :return: decorated mock of _request method
    """
    mock__request.return_value = Response()
    return mock__request


def decorate_mock_request(mock_request, status_code, *data):
    """
    mock functionality of the mock_request stub method
    :param mock_request: mock of the request method
    :param status_code: override status code of Response object
    :param data: data to return to when calling json method on first time
    :return: decorated mock of request method
    """

    responses = []

    for item in data:
        responses.append(Response(status_code=status_code, data=item))

    if len(responses) > 0:
        mock_request.side_effect = lambda **_: responses.pop(0)
    else:
        mock_request.return_value = Response(status_code=status_code, data=None)

    return mock_request
