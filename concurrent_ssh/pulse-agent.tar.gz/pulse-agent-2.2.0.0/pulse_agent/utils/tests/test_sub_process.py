"""
tests for sub_process module
"""
# core modules
import logging
import subprocess
import mock
from mock import Mock

# testing module
from pulse_agent.utils import sub_process

logging.basicConfig(level=logging.INFO)


def setup_module(module):
    """
    setup test module
    :param module:
    """
    log = logging.getLogger('setup_module')
    log.info("setup_module module:%s", module.__name__)


def teardown_module(module):
    """
    teardown test module
    :param module:
    """
    log = logging.getLogger('teardown_module')
    log.info("teardown_module module:%s", module.__name__)


def setup_function(function):
    """
    setup test function
    :param function:
    """
    logging.info("setup_function function:%s", function.__name__)


def teardown_function(function):
    """
    teardown test function
    :param function:
    """
    log = logging.getLogger('teardown_function')
    log.info("teardown_function function:%s", function.__name__)


@mock.patch('subprocess.Popen')
def test_p_open_stripped(mock_popen):
    """
    test p_open_stripped
    :param mock_popen:
    """
    cinco_version_read = Mock(return_value='  6.24.1.0  ')
    cinco_version_stdout = Mock(read=cinco_version_read)
    cinco_version = Mock(stdout=cinco_version_stdout)

    command = "cinco -v"

    # check whether it works as expected if the command returns results properly
    expected_calls = [
        mock.call(command, stdout=mock.ANY, shell=mock.ANY)
    ]
    mock_popen.side_effect = [cinco_version]
    assert sub_process.p_open_stripped(command) == '6.24.1.0'
    assert mock_popen.mock_calls == expected_calls

    # check whether it handles exceptions properly
    mock_popen.side_effect = Exception
    assert sub_process.p_open_stripped(command) is None


@mock.patch('subprocess.Popen')
def test_p_open(mock_popen):
    """
    test p_open
    :param mock_popen:
    """
    command = "couch -v"

    # check whether it works as expected if the command returns results properly
    expected_calls = [
        mock.call(command, stdout=mock.ANY, shell=mock.ANY)
    ]
    mock_popen.return_value = '1.6.0'
    assert sub_process.p_open(command) == '1.6.0'
    assert mock_popen.mock_calls == expected_calls

    # check whether it handles exceptions properly
    mock_popen.side_effect = Exception
    assert sub_process.p_open(command) is None


@mock.patch('subprocess.Popen')
def test_p_open_no_shell(mock_popen):
    """
    test p_open_no_shell
    :param mock_popen:
    """
    command = "xorg -v"

    # check whether it works as expected if the command returns results properly
    expected_calls = [
        mock.call(command, stdout=mock.ANY)
    ]
    mock_popen.return_value = '1.14.3'
    assert sub_process.p_open_no_shell(command) == '1.14.3'
    assert mock_popen.mock_calls == expected_calls

    # check whether it handles exceptions properly
    mock_popen.side_effect = Exception
    assert sub_process.p_open_no_shell(command) is None


@mock.patch('subprocess.Popen')
def test_p_open_default(mock_popen):
    """
    test p_open_default
    :param mock_popen:
    """
    command = "python -v"

    # check whether it works as expected if only the command is passed
    expected_calls = [
        mock.call(command)
    ]
    mock_popen.return_value = '2.7.3'
    assert sub_process.p_open_default(command) == '2.7.3'
    assert mock_popen.mock_calls == expected_calls

    # check whether it works as expected if more arguments than the command is passed
    mock_popen.return_value = '2.7.3'
    assert sub_process.p_open_default(command, stdout=subprocess.PIPE, shell=True) == '2.7.3'

    # check whether it handles exceptions properly
    mock_popen.side_effect = Exception
    assert sub_process.p_open_default(command) is None
