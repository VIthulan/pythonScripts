"""
Tests for rest_client module
"""

# Disable pointless-string-statement rule since docstrings are used for marking different cases of a test
# pylint: disable=pointless-string-statement

import mock
import pytest
from pulse_agent.utils.rest_client import RestClient
from .stub_manager import decorate_mock_request


@mock.patch('pulse_agent.utils.rest_client.logging.exception')
@mock.patch('pulse_agent.utils.rest_client.logging.error')
@mock.patch('pulse_agent.utils.rest_client.request')
def test_side_effects(mock_request, mock_error, mock_exception):
    """
    Unit tests for handling different side effects of the rest client
    :param mock_request: magic mock of request method
    :return: None
    """
    # Mocks
    decorate_mock_request(mock_request, 500, {
        'data': 'some data'
    })

    """Case 1: Verbose rest client with failure status code"""
    # Create Instance
    rest_client = RestClient(response_type='verbose')

    # Perform actions
    response = rest_client.get(url='https://www.example.com/fake')

    # Do assertions
    assert response.status_code == 500
    assert response.json() == {'data': 'some data'}
    mock_error.assert_called()

    """Case 2: Invalid url and path: fail silently"""
    # Will use the same instance as above

    # Perform actions and assert
    response = rest_client.get()
    assert response.data is None

    """Case 3: Invalid url and host: fail with exception"""
    # Create Instance
    rest_client = RestClient(fail_silently=False)

    # Perform actions
    with pytest.raises(ValueError, match=r'Host is None & url is not provided'):
        rest_client.get(path='custom/path')

    """Case 4: Other exception from request"""
    # Mock request to raise exception
    mock_request.side_effect = Exception("some other error")

    # Perform actions with same rest client
    with pytest.raises(Exception):
        rest_client.get('https://www.example.com/fake')

    # Do assertions
    mock_exception.assert_called()


@mock.patch('pulse_agent.utils.rest_client.request')
def test_get_with_params(mock_request):
    """
    Unit test for get request with query params
    :param mock_request: magic mock of request
    :return: None
    """
    # Mocks
    decorate_mock_request(mock_request, 200, {
        'data': 'some data'
    })

    # Create Instance
    rest_client = RestClient(response_type='verbose')

    # Perform actions
    response = rest_client.get(
        url='https://www.example.com/fake',
        params={
            'key1': 'val1',
            'key_num': 123
        }
    )

    # Do assertions
    mock_request.assert_called_with(
        method='get',
        url='https://www.example.com/fake',
        params={'key1': 'val1', 'key_num': 123},
        timeout=5,
        headers={'content-type': 'application/json'},
        data=None
    )
    assert response.status_code == 200
    assert response.json() == {'data': 'some data'}


@mock.patch('pulse_agent.utils.rest_client.request')
def test_delete(mock_request):
    """
    Unit test for get request with query params
    :param mock_request: magic mock of request
    :return: None
    """
    # Mocks
    decorate_mock_request(mock_request, 200)

    # Create Instance
    rest_client = RestClient(response_type='verbose')

    # Perform actions
    response = rest_client.delete(url='https://www.example.com/fake')

    # Do assertions
    mock_request.assert_called_with(
        method='delete',
        url='https://www.example.com/fake',
        timeout=5,
        params=None,
        headers={'content-type': 'application/json'},
        data=None
    )
    assert response.status_code == 200
