import logging
import boto3


def get_s3_client(aws_access_key_id, aws_secret_access_key, region_name):
    try:
        from botocore.client import Config
        return boto3.client('s3',
                            aws_access_key_id=aws_access_key_id,
                            aws_secret_access_key=aws_secret_access_key,
                            region_name=region_name,
                            config=Config(signature_version='s3v4'))
    except Exception as exception:
        logging.exception("[S3_CLIENT] Error getting s3 boto client : %s", exception)
        raise Exception


def upload_to_directory(s3_client, bucket_name, remote_dir_name, file_name):
    try:
        s3_client.upload_file(file_name, bucket_name, remote_dir_name)
    except Exception as exception:
        logging.exception("[S3_CLIENT] Error uploading file %s to directory %s : %s",
                          file_name, remote_dir_name, exception)
        raise Exception
