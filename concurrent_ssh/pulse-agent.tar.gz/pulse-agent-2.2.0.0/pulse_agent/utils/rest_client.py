"""
Generic rest client blueprint
"""

import logging
import json
from types import MethodType
from requests.api import request
from . import json_utils
from .dtos import Response


def json_polyfill(self):
    """

    :param self:
    :return:
    """
    return json.loads(self.text)


class RestClient(object):
    """
    ReST Client class for generating rest_client instances
    """

    def __init__(self, headers=None, host=None, timeout=60, fail_silently=True, response_type=None):
        """
        :param headers: headers dictionary
        :param host: default host part for ReST calls
        :param timeout: time to wait till rest call response (default = 5)
        :param fail_silently: if True, will not raise exceptions, will raise otherwise
        :param response_type: if 'verbose' will return response object, else will return response data dict
        """
        if headers is None:
            headers = {'content-type': 'application/json'}
        else:
            headers.update({'content-type': 'application/json'})

        self.headers = headers
        self.timeout = timeout
        self.host = host
        self.fail_silently = fail_silently
        self.response_type = response_type

    def _request(self, method, url=None, path=None, body=None, params=None):
        """
        Perform a general HTTP request
        :param method: HTTP method (get or post or ...)
        :param url: full url with host and path
        :param path: used in combination with self.host when url is not provided
        :param body: request body for post requests
        :return: Response or response data dict
        """
        if url is None:
            if path is None:
                raise ValueError("Invalid path")
            if self.host is None:
                raise ValueError("Host is None & url is not provided")
            url = self.host + path

        try:
            if body is not None:
                body = json_utils.get_json_dump(body)

            response = request(
                method=method,
                url=url,
                data=body,
                headers=self.headers,
                timeout=self.timeout,
                params=params
            )

            response.json = MethodType(json_polyfill, response)

            if response is None:
                logging.error('Response None received for request : %s %s %s', method, url, path)
                return ExceptionResponse()
            if response.status_code != 200:
                logging.error("Failed %s : %s status: %s, response: %s, headers: %s",
                              method,
                              url,
                              response.status_code,
                              str(response.text),
                              self.headers
                              )

            if self.response_type == 'verbose':
                return response
            return response.json()
        except Exception as exception:
            logging.exception('Exception while making request to url: %s, method: %s : %s', url,
                              method, exception)
            return ExceptionResponse()

    def request(self, method, url=None, path=None, body=None, params=None):
        """
        Proxy for _request method
        :param method: http method
        :param url: full url with host and path
        :param path: used in combination with self.host when url is not provided
        :param body: post request body
        :param params: query parameters as a dict
        :return: Response or response json data
        """
        try:
            return self._request(method=method, url=url, path=path, body=body, params=params)
        except Exception as exception:
            if self.fail_silently:
                if self.response_type == 'verbose':
                    return Response(status_code=500, data=None, headers={})
            logging.exception('Exception while trying to make request: %s to url: %s', exception,
                              url)
            return ExceptionResponse()

    def get(self, url=None, path=None, params=None):
        """
        Perform HTTP get request
        :param url: full url with host and path
        :param path: used in combination with self.host when url is not provided
        :param params: query parameters as a dict
        :return: Response or response json data
        """
        return self.request(method='get', url=url, path=path, params=params)

    def post(self, url=None, path=None, body=None):
        """
        Perform HTTP post request
        :param url: full url with host and path
        :param path: used in combination with self.host when url is not provided
        :param body: post request body
        :return: Response or response json data
        """
        return self.request(method='post', url=url, path=path, body=body)

    def delete(self, url=None, path=None, params=None):
        """
        Perform HTTP delete request
        :param url: full url with host and path
        :param path: used in combination with self.host when url is not provided
        :param params: query parameters as a dict
        :return: Response
        """
        return self.request(method='delete', url=url, path=path, params=params)


class ExceptionResponse(object):
    """
    Send crisis response for callee while exception
    """
    def __init__(self, status_code=520, text=''):
        self.status_code = status_code
        self.text = text


rest_client = RestClient(response_type='verbose')
