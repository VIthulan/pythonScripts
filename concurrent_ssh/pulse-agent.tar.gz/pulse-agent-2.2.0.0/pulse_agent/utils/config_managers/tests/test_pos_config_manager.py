"""
tests for pos_config_manager module
"""
# core modules
import logging
import xml.dom.minidom as xml
import mock
from mock import Mock

# testing module
from pulse_agent.utils.config_managers import pos_config_manager
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


def setup_module(module):
    """
    setup test module
    :param module:
    """
    log = logging.getLogger('setup_module')
    log.info("setup_module module:%s", module.__name__)


def teardown_module(module):
    """
    teardown test module
    :param module:
    """
    log = logging.getLogger('teardown_module')
    log.info("teardown_module module:%s", module.__name__)


def setup_function(function):
    """
    setup test function
    :param function:
    """
    logging.info("setup_function function:%s", function.__name__)


def teardown_function(function):
    """
    teardown test function
    :param function:
    """
    log = logging.getLogger('teardown_function')
    log.info("teardown_function function:%s", function.__name__)


@mock.patch('os.path.exists')
@mock.patch('xml.dom.minidom.parse')
def test_load_pref_entries(mock_xml_parse, mock_os_path):
    """
    test load_pref_entries
    :param mock_xml_parse:
    :param mock_os_path:
    :return:
    """
    path = '/home/leapset/.java/.userPrefs/CincoTinyServer/prefs.xml'

    # check whether it works as expected if the given path doesn't exist
    mock_os_path.return_value = False
    assert pos_config_manager.load_pref_entries(path) == {}
    assert mock_os_path.mock_calls == [mock.call(path)]

    # check whether it works as expected if the given path exists
    mock_os_path.return_value = True

    get_elements_by_tag_name = Mock(return_value={})
    entries = Mock(getElementsByTagName=get_elements_by_tag_name)

    mock_xml_parse.return_value = entries
    assert pos_config_manager.load_pref_entries(path) == {}
    assert mock_xml_parse.mock_calls == [mock.call(path), mock.call().getElementsByTagName('entry')]

    # check whether it handles exceptions properly
    mock_os_path.side_effect = Exception
    assert pos_config_manager.load_pref_entries(path) is None


def test_get_preference_value():
    """
    test get_preference_value
    """
    key_merchant_id = 'merchant.id'
    key_station_id = 'station.id'
    key_build_env = 'build.environment'
    value_merchant_id = 'c0010-10422725'
    path = 'pulse_agent/utils/config_managers/tests/pref.xml'
    preference_entries = xml.parse(path).getElementsByTagName('entry')

    # check whether it works as expected if the given key exists in pref.xml
    assert pos_config_manager.get_preference_value(preference_entries, key_merchant_id) == value_merchant_id

    # check whether it works as expected if the value for given key doesn't exist
    assert pos_config_manager.get_preference_value(preference_entries, key_build_env) == config.ERROR_MESSAGE

    # check whether it handles exceptions properly
    try:
        pos_config_manager.get_preference_value(None, key_station_id)
        assert False
    except Exception:
        assert True


@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.load_pref_entries')
@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.get_preference_value')
def test_get_pos_build_env(mock_get_preference_value, mock_load_pref_entries):
    """
    test get_pos_build_env()
    :param mock_get_preference_value:
    :param mock_load_pref_entries:
    :return:
    """
    # checks whether it works as expected if load_pref_entries and get_preference_value works properly
    mock_load_pref_entries.return_value = ''
    mock_get_preference_value.return_value = 'TST6'
    assert pos_config_manager.get_pos_build_env() == 'TST6'

    # check whether it handles exceptions properly
    mock_load_pref_entries.side_effect = Exception
    try:
        pos_config_manager.get_pos_build_env()
        assert False
    except Exception:
        assert True
