"""
Localized stub logic of config managers package
"""


def decorate_mock_get_node_server_url(mock_get_node_server_url):
    """
    return mock dedicated and dev Pulse API urls based on the env param
    :param mock_get_node_server_url: mock of get_node_server_url method
    :return: mock_url string
    """
    def side_effect_get_node_server_url(env):
        """
        Side effect function for switching between mock dev and mock dedicated urls
        :param env: enum 'dev' or 'dedicated'
        :return: mock_url str
        """
        if env == 'dev':
            return 'https://dev-pulse.leapset.com:8080'
        else:
            return 'https://pulse.leapset.com:8080'

    mock_get_node_server_url.side_effect = side_effect_get_node_server_url
    return mock_get_node_server_url
