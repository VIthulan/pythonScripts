"""
tests for server_config_manager module
"""
# core modules
import logging
import mock

# testing module
from pulse_agent.utils.config_managers import server_config_manager
from pulse_agent.utils.config import config

logging.basicConfig(level=logging.INFO)


def setup_module(module):
    """
    setup test module
    :param module:
    """
    log = logging.getLogger('setup_module')
    log.info("setup_module module:%s", module.__name__)


def teardown_module(module):
    """
    teardown test module
    :param module:
    """
    log = logging.getLogger('teardown_module')
    log.info("teardown_module module:%s", module.__name__)


def setup_function(function):
    """
    setup test function
    :param function:
    """
    logging.info("setup_function function:%s", function.__name__)


def teardown_function(function):
    """
    teardown test function
    :param function:
    """
    log = logging.getLogger('teardown_function')
    log.info("teardown_function function:%s", function.__name__)


@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.get_pos_build_env')
def test_get_web_socket_url(mock_get_pos_build_env):
    """
    test get_web_socket_url()
    :param mock_get_pos_build_env:
    :return:
    """
    env = config.DEDICATED

    # checks whether it works as expected if the configs for the dedicated env are available
    mock_get_pos_build_env.return_value = 'TST6'
    assert server_config_manager.get_web_socket_url(env) == 'wss://tst6-pulse.leapset.com:8080/'

    # checks whether it works as expected if the configs for the dev env are available
    env = config.DEV
    mock_get_pos_build_env.return_value = 'DEV'
    assert server_config_manager.get_web_socket_url(env) == 'wss://dev-pulse.leapset.com:8080/'

    # checks whether it works as expected if the configs for the given env is not available
    env = ''
    assert server_config_manager.get_web_socket_url(env) is None

    # check whether it handles exceptions properly
    mock_get_pos_build_env.side_effect = Exception
    env = config.DEDICATED
    try:
        server_config_manager.get_web_socket_url(env)
        assert False
    except Exception:
        assert True


@mock.patch('pulse_agent.utils.config_managers.pos_config_manager.get_pos_build_env')
def test_get_node_server_url(mock_get_pos_build_env):
    """
    test get_node_server_url()
    :param mock_get_pos_build_env:
    :return:
    """
    env = config.DEDICATED

    # checks whether it works as expected if the configs for the dedicated env are available
    mock_get_pos_build_env.return_value = 'TST6'
    assert server_config_manager.get_node_server_url(env) == 'https://tst6-pulse.leapset.com:8080'

    # checks whether it works as expected if the configs for the dev env are available
    env = config.DEV
    mock_get_pos_build_env.return_value = 'DEV'
    assert server_config_manager.get_node_server_url(env) == 'https://dev-pulse.leapset.com:8080'

    # checks whether it works as expected if the configs for the given env is not available
    env = ''
    assert server_config_manager.get_node_server_url(env) == ''

    # check whether it handles exceptions properly
    mock_get_pos_build_env.side_effect = Exception
    env = config.DEDICATED
    try:
        server_config_manager.get_web_socket_url(env)
        assert False
    except Exception:
        assert True
