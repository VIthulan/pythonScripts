"""
This module handles about server configs
"""
import logging
import logging.config
from pulse_agent.utils.config import config, env_config
from pulse_agent.utils.config_managers import pos_config_manager


def get_web_socket_url(env):
    """
    This gets the web socket url of given environment
    :param env: Environment (prod, dev, tst)
    :return: url
    """
    try:
        if env == config.DEDICATED:
            build_env = pos_config_manager.get_pos_build_env().lower()
            logging.info("build_env: %s", build_env)
            api_server_url = env_config.ENV_CONFIG.get(build_env).get('API_SERVER_URL')
            api_server_port = env_config.ENV_CONFIG.get(build_env).get('API_SERVER_PORT')

            if (api_server_url is not None) and (api_server_port is not None):
                return 'wss://%s:%s/%s' % (api_server_url, api_server_port, config.SERVER_PATH)

            logging.error(
                "Error: not a valid build environment  provided : "
                "So returns ENV_PROD as default %s:", build_env)
            prod_api_server_url = env_config.ENV_CONFIG.get('prod').get('API_SERVER_URL')
            prod_api_server_port = env_config.ENV_CONFIG.get('prod').get('API_SERVER_PORT')
            return 'wss://%s:%s/%s' % (prod_api_server_url, prod_api_server_port,
                                       config.SERVER_PATH)
        elif env == config.DEV:
            dev_api_server_url = env_config.ENV_CONFIG.get('dev').get('API_SERVER_URL')
            dev_api_server_port = env_config.ENV_CONFIG.get('dev').get('API_SERVER_PORT')
            return 'wss://%s:%s/%s' % (dev_api_server_url, dev_api_server_port, config.SERVER_PATH)
        else:
            logging.error("url type is not mentioned")
    except Exception as exception:
        logging.exception("Error while generating web socket url: %s", exception)
        return ""


def get_node_server_url(env):
    """
    Gets the pulse API server URL
    :param env: Given environment dev/prod,tst
    :return: URL
    """
    try:
        if env == config.DEDICATED:
            build_env = pos_config_manager.get_pos_build_env().lower()
            logging.info("build_env: %s", build_env)
            api_server_url = env_config.ENV_CONFIG.get(build_env).get('API_SERVER_URL')
            api_server_port = env_config.ENV_CONFIG.get(build_env).get('API_SERVER_PORT')

            if (api_server_url is not None) and (api_server_port is not None):
                return 'https://%s:%s' % (api_server_url, api_server_port)

            logging.error(
                "Error: not a valid build environment  provided : "
                "So returns ENV_PROD as default %s:", build_env)
            prod_api_server_url = env_config.ENV_CONFIG.get('prod').get('API_SERVER_URL')
            prod_api_server_port = env_config.ENV_CONFIG.get('prod').get('API_SERVER_PORT')
            return 'https://%s:%s' % (prod_api_server_url, prod_api_server_port)

        elif env == config.DEV:
            dev_api_server_url = env_config.ENV_CONFIG.get('dev').get('API_SERVER_URL')
            dev_api_server_port = env_config.ENV_CONFIG.get('dev').get('API_SERVER_PORT')
            return 'https://%s:%s' % (dev_api_server_url, dev_api_server_port)
        else:
            logging.error("url type is not mentioned")
            return ""
    except Exception as exception:
        logging.exception("Error while generating node server url: %s", exception)
        return ""
