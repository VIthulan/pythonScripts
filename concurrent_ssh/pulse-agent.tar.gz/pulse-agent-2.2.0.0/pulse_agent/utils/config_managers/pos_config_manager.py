"""
This module gives access to pos configs like pref.xml
"""
import logging
import logging.config
import os
import xml.dom.minidom as xml

from pulse_agent.utils.config import config


def get_pos_build_env():
    """
    Get pos build environment
    :return: build environment
    """
    try:
        return get_preference_value(load_pref_entries(config.PREFS_FILE)
                                    , config.BUILD_ENV)
    except Exception as exception:
        logging.exception("Error while getting pos build environment: %s", exception)
        raise Exception


def load_pref_entries(path):
    """
    load given file
    :param path: path of file
    :return: entries
    """
    try:
        if not os.path.exists(path):
            return {}

        # parse the XML file 'entry' elements. All of the preference
        preference_entries = xml.parse(path).getElementsByTagName(config.ENTRY)
        return preference_entries

    except Exception as exception:
        logging.exception("Error while getting preference data from pref.xml file: %s", exception)
        return None


def get_preference_value(preference_entries, key):
    """
    Get the value of given key
    :param preference_entries: list of entries
    :param key: key
    :return: value of key
    """
    try:
        for entry in preference_entries:
            if entry.getAttribute(config.KEY) == key:
                data_value = entry.getAttribute(config.VALUE)
                if data_value:
                    return str(data_value) or ''
                return config.ERROR_MESSAGE

        return ''

    except Exception as exception:
        logging.exception("Error while getting preference value for key: %s :%s", key, exception)
        return config.ERROR_MESSAGE
