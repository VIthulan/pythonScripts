"""
This module has utils to handle and manipulate json objects
"""
import json
import logging


def get_pretty_json(data):
    """
    This method returns prettified json
    :param data: data
    :return: Prettified json object
    """
    try:
        return json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '),
                          default=lambda o: o.__dict__)
    except Exception as exception:
        logging.exception('Error while transforming json: %s', exception)
        return data


def get_json_dump(data):
    """
    get json dump from dict
    :param data: dict data
    :return: json dump
    """
    try:
        return json.dumps(data, default=lambda o: o.__dict__)
    except Exception as exception:
        logging.exception('Error while transforming json: %s', exception)
        return data
