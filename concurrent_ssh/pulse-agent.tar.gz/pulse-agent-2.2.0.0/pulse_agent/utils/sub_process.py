"""
This module gives access to standard subprocess module
"""
import subprocess
import logging


def p_open_stripped(command):
    """
    Execute subprocess Popen command through this util method
    :param command: Command to execute | string/array
    :return: Output from subprocess with readable format
    """
    try:
        output = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
        return output.stdout.read().strip()
    except Exception as exception:
        logging.exception("Error while running subprocess command: %s", exception)
        return None


def p_open(command):
    """
    Execute subprocess Popen command through this util method
    :param command: Command to execute | string/array
    :return: Output from subprocess with readable format
    """
    try:
        output = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
        return output
    except Exception as exception:
        logging.exception("Error while running subprocess command: %s", exception)
        return None


def p_open_no_shell(command):
    """
    Execute subprocess Popen command through this util method
    :param command: command
    :return: output
    """
    try:
        output = subprocess.Popen(command, stdout=subprocess.PIPE)
        return output
    except Exception as exception:
        logging.exception("Error while running subprocess command: %s", exception)
        return None


def p_open_default(command, **kwargs):
    """
    Execute subprocess Popen command through this util method for given args
    :param command: command
    :param kwargs: any args
    :return: output
    """
    try:
        output = subprocess.Popen(command, **kwargs)
        return output
    except Exception as exception:
        logging.exception("Error while running subprocess command: %s", exception)
        return None
