"""
Utils to manipulate file
"""
import logging
import os
import glob
import math
import shutil
import configobj
from pulse_agent.utils.config import config


def load_config(file_url):
    """
    Load a config file as a dict given the url
    :param file_url: url of the config file
    :return: config obj dictionary
    """
    return configobj.ConfigObj(
        file_url,
        raise_errors=True,
        file_error=True,  # don't create file if it doesn't exist
        encoding=config.ENCODING,  # used to read/write file
        default_encoding=config.ENCODING  # str -> unicode internally
    )


def update_conf_file(conf_file, key, value):
    """
    Update given conf file
    :param conf_file: file path
    :param key: key of value to be updated
    :param value: value
    :return: nothing
    """
    try:
        conf = load_config(conf_file)
        conf[key] = value
        conf.write()
    except Exception as exception:
        logging.exception(exception)


def update_last_heart_beat(time):
    """
    update the agent-records.conf file with the LAST_HEART_BEAT

    """
    try:
        rec = load_config(config.RECORDS_FILE_PATH)
        rec.update(dict(
            LAST_HEART_BEAT=time.strip()
        ))
        rec.write()
    except Exception as exception:
        logging.exception("Error: upgrading LAST HEART BEAT in version.conf file: %s", exception)


def get_file_size_array(file_path_regex):
    """
    Get file size array in given path
    :param file_path_regex: path
    :return: list of size
    """
    try:
        matching_files = glob.glob(file_path_regex)
        file_size_arr = []
        for matching_file in matching_files:
            stat_info = os.stat(matching_file)
            file_size_arr.append(stat_info.st_size / math.pow(1024, 2))
        logging.debug('File Sizes in MB: %s', file_size_arr)
        return file_size_arr
    except Exception as exception:
        logging.exception('Error checking file size: %s', exception)
        return []


def does_file_exceeds_threshold(file_path_regex, threshold_mb):
    """
    Checks if at least one file exceeds threshold
    :param file_path_regex: dir path
    :param threshold_mb: threshold
    :return: true/false
    """
    try:
        for file_size in get_file_size_array(file_path_regex):
            if file_size > threshold_mb:
                return True
        return False
    except Exception as exception:
        logging.exception('Error checking file sizes. So returns true for safe side: %s', exception)
        return True


def update_statistics(version, ctd):
    """
    update the version.conf file with the latest xorg version
    :param version:          latest xorg version from os
    :param ctd:              latest CTD status from os
    :return:                none
    """
    try:
        conf = load_config(config.CONF_FILE_PATH)
        conf.update(dict(
            XORG_VERSION=version.strip(),
            CTD_STATUS=ctd
        ))
        conf.write()
    except Exception as exception:
        logging.exception('Error while updating statistics: %s', exception)


def update_startup_status(status):
    """
    update the agent-records.conf file with the STARTUP_STATUS_SUCCESS

    """
    try:
        logging.info("start updating start up status")
        rec = load_config(config.RECORDS_FILE_PATH)
        rec.update(dict(
            STARTUP_STATUS_SUCCESS=status.strip()
        ))
        rec.write()
    except Exception as exception:
        logging.exception("Error while upgrading START UP STATUS in version.conf file: %s", exception)


def update_version_to_upgrade(version):
    """
    update the agent-records.conf file with the VERSION_TO_UPDATE

    """
    try:
        logging.info("start updating version to upgrade")
        rec = load_config(config.RECORDS_FILE_PATH)
        rec.update(dict(
            VERSION_TO_UPDATE=version.strip()
        ))
        rec.write()
    except Exception as exception:
        logging.exception('Error while updating the version to upgrade: %s', exception)
        raise Exception


def update_upgrade_rq_status(status):
    """
    update the agent-records.conf file with the UPGRADE_REQUEST_STATUS

    """
    try:
        logging.info("start updating upgrade request status")
        rec = load_config(config.RECORDS_FILE_PATH)
        rec.update(dict(
            UPGRADE_REQUEST_STATUS=status.strip()
        ))
        rec.write()
    except Exception as excepton:
        logging.exception("Error while upgrading UPGRADE_REQUEST_STATUS in version.conf file: %s",
                          excepton)
        raise Exception


def zip_dir(path, zip_h):
    """
    Zip directory
    :param path: Dir path
    :param zip_h: zip_h
    """
    try:
        for root, _, files in os.walk(path):
            for file_name in files:
                zip_h.write(os.path.join(root, file_name))
    except Exception as exception:
        logging.exception(" Error while zipping the directory : %s", exception)


def compress_logs(src_directory, dest_directory, file_name):
    """
    Compress files
    :param src_directory: src
    :param dest_directory: dest
    :param file_name: name
    """
    try:
        shutil.make_archive("{}/{}".format(dest_directory, file_name), 'zip', src_directory)
        logging.debug("Zipped log files successfully to : %s", dest_directory)
    except Exception as exception:
        logging.exception("Error while compressing files : %s", exception)
        raise Exception


def read_app_secret():
    """
    read app secret from secret.conf
    :return: app secret
    """

    try:
        conf = load_config(config.AUTH_FILE_PATH)
        return conf["VALUE"]
    except Exception as exception:
        logging.exception("Error while reading app secret : %s", exception)
        return ""
