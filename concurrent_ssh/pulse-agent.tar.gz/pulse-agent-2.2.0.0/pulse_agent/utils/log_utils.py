"""
This module will contain utils related to logs handling/manipulations
"""
import time
import logging
from pulse_agent.utils import sub_process
from pulse_agent.utils.decorators.try_except import try_except


@try_except(level='exception', default=None)
def grep_switch_logs(path, *args, **kwargs):
    """
    Grep Switch logs
    :param path: Log path
    :param args: Keywords to grep
    :param kwargs: Base switch, Date
    :return: List with grep outputs
    """
    base = kwargs.get('base') or 'PULSE'
    base_command = "zgrep --no-filename '%s' %s" % (base, path)
    if kwargs.get('date') is not None:
        try:
            today_date = time.strftime(kwargs.get('date'))
            base_command = base_command + "| grep '%s'" % today_date
        except Exception as exception:
            logging.exception('Exception while getting time from format given: %s', exception)
    if args:
        base_command = base_command + "| grep "
        for key in args:
            base_command = base_command + "'\[%s\]'" % key

    logging.debug(base_command)
    output = sub_process.p_open(base_command).stdout.readlines()
    logging.debug('Response for grepping switch log: %s', output)
    return output


@try_except(level='exception', default=None)
def get_switch_message(log, excess):
    """
    Get messages from grepped switch logs
    :param log: Grepped log
    :param excess: Excess to drop from message
    :return: Message string
    """
    if not log or log is None or not excess or excess is None:
        return None
    messages = []
    for log_line in log:
        if log_line.split(excess):
            messages.append(
                log_line.split(excess)[1])

    return messages
