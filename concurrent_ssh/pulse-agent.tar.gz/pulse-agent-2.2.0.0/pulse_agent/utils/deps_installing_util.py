"""
Install dependencies
"""
import sys
import os


def install_package(package, prefix=''):
    """
    Install packages
    :param package:
    :param prefix:
    :return:
    """
    try:
        command = 'pip install ' + prefix + ' ' + package
        os.system(command)
    except Exception as exception:
        sys.stdout.write('Error installing package: %s - %s' % (package, exception))


def install_deps():
    """
    Install dependencies
    :return:
    """
    install_package('speedtest-cli')
    install_package('scapy')
    install_package('coloredlogs==8.0', '--index-url=https://pypi.python.org/simple/')
    install_package('docutils==0.13.1', '--no-deps')
    install_package('jmespath==0.9.3', '--no-deps')
    install_package('python-dateutil==2.6.1', '--no-deps')
    install_package('botocore==1.5.90', '--no-deps')
    install_package('futures==3.1.1', '--no-deps')
    install_package('s3transfer==0.1.10', '--no-deps')
    install_package('boto3==1.4.4', '--no-deps')


def no_ops():
    """
    No operations
    :return:
    """
    sys.stdout.write('Hello POS! - Pulse Agent')


install_deps()
