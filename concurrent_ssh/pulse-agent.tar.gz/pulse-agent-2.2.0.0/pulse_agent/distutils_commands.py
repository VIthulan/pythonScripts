"""
Command class definitions for distutils extensions
"""
# Core packages
from distutils.command.sdist import sdist
from distutils.core import Command

# Custom modules
from pulse_agent.utils.config import config
from pulse_agent.utils import file_utils
from pulse_agent.utils import sub_process


class DistutilsCommand(Command):
    """
    distutils parent command class
    """
    user_options = []

    def initialize_options(self):
        """Initialize distutil command options"""
        pass

    def finalize_options(self):
        """Finalize distutil command options"""
        pass

    def run(self):
        """Logic of distutil command"""
        pass


class SDistCommand(sdist):
    """
    sdist parent command class
    """
    @staticmethod
    def update_conf_file(env):
        """
        Save Pulse-Agent build env information in agent-version.conf file
        :param env: target environment
        :return: None
        """
        file_utils.update_conf_file(
            config.AGENT_VERSION_CONF_FILE_PATH,
            config.BUILD_ENVIRONMENT,
            env
        )


class SDistProd(SDistCommand):
    """
    sdist command class for PROD env
    """

    def run(self):
        """
        distutils command run method
        :return: None
        """
        self.update_conf_file(config.PROD)


class SDistQA(SDistCommand):
    """
    sdist command class for QA env
    """

    def run(self):
        """
        distutils command run method
        :return: None
        """
        self.update_conf_file(config.QA)


class SDistDev(SDistCommand):
    """
    sdist command class for DEV env
    """

    def run(self):
        """
        distutils command run method
        :return: None
        """
        self.update_conf_file(config.DEV)


class CleanCoverage(DistutilsCommand):
    """
    Clean test coverage files & directories
    """

    def run(self):
        # Remove html_cov directories recursively
        html_cov_dirs = sub_process.p_open_stripped('find -type d -name htmlcov')
        if html_cov_dirs:
            sub_process.p_open_stripped('rm -r `find -type d -name htmlcov`')

        # Remove .coverage files recursively
        cov_files = sub_process.p_open_stripped('find -name .coverage')
        if cov_files:
            sub_process.p_open_stripped('rm -r `find -name .coverage`')
