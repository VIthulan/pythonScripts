"""
Unit tests for the ws_client module
Here it is tested whether the corresponding methods in websocket.WebSocketApp are called from the WebSocketClient
& WebSocketClient responds properly to the function calls in websocket.WebSocketApp
"""
import json
import mock
from pulse_agent.websocket.ws_client import WebSocketClient


@mock.patch('websocket.WebSocketApp.__init__')
def test_websocket_init(mock_websocket_app_init):
    """
    Test for the WebSocketClient initialization
    :param mock_websocket_app: magic mock object of WebSocketApp __ini__ method
    :return: None
    """
    mock_websocket_app_init.return_value = None

    # Create instance
    ws_client = WebSocketClient('url')

    mock_websocket_app_init.assert_called_with(ws_client.url,
                                               on_open=ws_client.on_open,
                                               on_close=ws_client.on_close,
                                               on_error=ws_client.on_error,
                                               on_message=ws_client.on_message)


@mock.patch('pulse_agent.websocket.ws_client.WebSocketClient.on_open')
def test_on_open(mock_on_open):
    """
    Test for the on_open lifecycle method
    :param mock_websocket_app_on_open: magic mock object of WebSocketClient on_openlifecycle method
    :return: None
    """
    # Create instance
    ws_client = WebSocketClient('url')

    # Call private callback method of WebSocketApp to test WebSocketClient callbacks
    ws_client._callback(ws_client.on_open)  # pylint: disable=protected-access

    mock_on_open.assert_called_with(mock.ANY)


@mock.patch('pulse_agent.websocket.ws_client.WebSocketClient.on_close')
def test_on_close(mock_on_close):
    """
    Test for the on_close lifecycle method
    :param mock_websocket_app_on_close: magic mock object of WebSocketClient on_close lifecycle method
    :return: None
    """
    # Create instance
    ws_client = WebSocketClient('url')

    mock_close_args = [1234, 'ERROR']

    # Call private callback method of WebSocketApp to test WebSocketClient callbacks
    ws_client._callback(ws_client.on_close, mock_close_args)  # pylint: disable=protected-access

    mock_on_close.assert_called_with(mock.ANY, mock_close_args)


@mock.patch('pulse_agent.websocket.ws_client.WebSocketClient.on_message')
def test_on_message(mock_on_message):
    """
    Test for the on_message lifecycle method
    :param mock_websocket_app_on_message: magic mock object of WebSocketClient on_message lifecycle method
    :return: None
    """
    # Create instance
    ws_client = WebSocketClient('url')

    mock_data = {'data': 'somedata'}

    # Call private callback method of WebSocketApp to test WebSocketClient callbacks
    ws_client._callback(ws_client.on_message, mock_data)  # pylint: disable=protected-access

    mock_on_message.assert_called_with(mock.ANY, mock_data)


@mock.patch('websocket.WebSocketApp.send')
def test_send(mock_websocket_app_send):
    """
    Test for the send method
    :param mock_websocket_app_send:
    :return: None
    """
    # Create instance
    ws_client = WebSocketClient('url')

    mock_websocket_app_send.return_value = None

    # Make as websocket is connected
    ws_client.is_connected = True

    ws_client.send('name', 'data')
    mock_websocket_app_send.assert_called_with(json.dumps({'name': 'name', 'data': 'data'}))


@mock.patch('websocket.WebSocketApp.run_forever')
def test_connect(mock_websocket_app_run_forever):
    """
    Test for the connect method
    :param mock_websocket_app_run_forever:
    :return:
    """
    # Create instance
    ws_client = WebSocketClient('url')

    mock_websocket_app_run_forever.return_value = None

    ws_client.connect(reconnect=0, timeout=5)
    mock_websocket_app_run_forever.assert_called()
