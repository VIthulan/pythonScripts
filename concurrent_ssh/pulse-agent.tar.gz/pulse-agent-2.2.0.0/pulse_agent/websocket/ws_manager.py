"""
This module contains Websocket on functions for both dedicated and dev.
Two instances can be created for both dedicated and dev
"""
import os
import logging

from pulse_agent.utils.config import config
from pulse_agent.websocket import ws_client
from pulse_agent.monitor.tunnel.tunnel import tunnel
from pulse_agent.monitor.system_stats.stats_facade import stats_facade
from pulse_agent.monitor.network.network_facade import network_facade
from pulse_agent.monitor.on_demand import on_demand_jobs
from pulse_agent.actuator.image_upgrade.image_upgrader_facade import image_upgrader_facade
from pulse_agent.utils.config_managers import server_config_manager
from pulse_agent.utils import file_utils
from pulse_agent.utils import utils


class WSManager(object):
    """ Initialize and defines the dedicated web socket process """

    def __init__(self, env):
        """
        __init__ method
        :type env: string running environment
        """
        self.client = ws_client.WebSocketClient(server_config_manager.get_web_socket_url(env))
        self.env = env

        @self.client.on('open')
        def connected(ws):
            self.client.send('JOIN', stats_facade.gather_join_stats())
            logging.info("Websocket connection is opened to %s env", env.upper())
            if env == config.DEDICATED:  # Updating conf only for dedicated env connection open
                file_utils.update_startup_status('true')

        @self.client.on('refresh')
        def refresh_stats(ws, data):
            logging.info("[%s] Received refresh command.", env.upper())
            self.send_system_stats_update()

        @self.client.on('tunnel')
        def handle_tunnel(ws, data):
            logging.info("[%s] Received tunnel command to %s", env.upper(), env.upper())

            if tunnel.is_tunnel_exists(config.SSH_USER,
                                       tunnel.get_tunnel_server(env)):
                # TODO: This will destroy both dedicated and dev tunnels
                tunnel.destroy_tunnel()
            else:
                # if there was no port specified in the data then we cannot open the tunnel
                if not data:
                    logging.error("No tunnel port was specified from %s server on tunnel request",
                                  env)
                    return None

                # create the tunnel
                tunnel.create_tunnel(server=tunnel.get_tunnel_server(env),
                                     port=data,
                                     user=config.SSH_USER,
                                     key=config.SSH_KEY)

            self.send_system_stats_update()

        @self.client.on('upgrade')
        def upgrade_client(ws, data):
            logging.info("[%s] Received upgrade command.", env.upper())
            os.system('pulse-agent upgrade')

        @self.client.on('advance_network_check')
        def on_advanced_network_check(ws, data):
            try:
                logging.info('[%s] Received advanced network check command', env.upper())
                network_facade.do_advanced_check(env=env)
            except Exception as exception:
                logging.exception("Error while doing advanced network checkup on demand: %s",
                                  exception)

        @self.client.on('trace_route')
        def traceroute_check(ws, data):
            logging.info('[%s] Received trace route command', env.upper())
            network_facade.send_tracerout_results(env=env, host=data)

        @self.client.on('begin_sniffing')
        def sniffing_check(ws, data):
            logging.info('[%s] Received begin sniffing command', env.upper())
            network_facade.perform_sniffing(env=env)

        @self.client.on('begin_UDP_sending')
        def send_udp(ws, data):
            logging.info('[%s] Received begin UDP packet sending command', env.upper())
            network_facade.send_udp_packets(ip_address=data)

        @self.client.on('max_isp_check')
        def max_isp_check(ws, data):
            logging.info("[%s] Received max isp check command", env.upper())
            network_facade.send_max_isp_speed()

        @self.client.on('clean_hdd')
        def clean_hard_disk(ws, data):
            logging.info("[%s] Received clean hdd command", env.upper())
            on_demand_jobs.clean_hdd()

        @self.client.on('pulse_agent_upgrade')
        def on_pulse_upgrade_agent(ws, data):
            try:
                logging.info("[%s] Received pulse agent upgrade command", env.upper())
                file_utils.update_version_to_upgrade(str(data))
                file_utils.update_upgrade_rq_status('true')
                utils.kill_process('pulse-upgrader')
                utils.kill_process('pulse-agent')
            except Exception as exception:
                logging.exception("[%s] Error while on-demand upgrading agent: %s", env.upper(),
                                  exception)

        @self.client.on('pulse_agent_restart')
        def on_pulse_agent_restart(ws, data):
            try:
                logging.info("[%s] Received pulse agent restart command", env.upper())
                utils.kill_process('pulse-upgrader')
                utils.kill_process('pulse-agent')
            except Exception as exception:
                logging.exception("[%s] Error while on-demand restarting pulse-agent: %s",
                                  env.upper(), exception)

        @self.client.on('pulse_agent_gdm_debug_restart')
        def on_pulse_agent_gdm_debug_restart(ws, data):
            logging.info("[%s] Received gdm restart command", env.upper())
            on_demand_jobs.debug_gdm_restart(env)

        @self.client.on('pulse_agent_debug_futon')
        def on_pulse_agent_debug_futon(ws, data):
            logging.info("[%s] Received debug futon command", env.upper())
            on_demand_jobs.debug_futon()

        @self.client.on('pulse_agent_debug_phantom_printer')
        def on_pulse_agent_debug_phantom_printer(ws, data):
            logging.info("[%s] Received debug phantom printer command", env.upper())
            on_demand_jobs.debug_phantom_printer(env)

        @self.client.on('pulse_agent_debug_add_couch_user')
        def on_pulse_agent_debug_add_couch_user(ws, data):
            logging.info("[%s] Received debug add couch user command", env.upper())
            on_demand_jobs.add_new_couch_user(env)

        @self.client.on('rename_register')
        def on_pulse_agent_rename_register(ws, data):
            logging.info("[%s] Received rename register command", env.upper())
            on_demand_jobs.rename_register(env, previous_name=data[0], new_name=data[1],
                                           admin_pass=data[2])

        @self.client.on('check_lp_pulse_status')
        def on_check_lp_pulse_status(ws, data):
            logging.info("[%s] Received lp-pulse status command", env.upper())
            on_demand_jobs.check_lp_pulse_state_in_peer_registers(env, data)

        @self.client.on('save_logs')
        def on_save_logs(ws, data):
            logging.info("[%s] Received save logs command", env.upper())
            on_demand_jobs.save_logs(env)

        @self.client.on('collect_and_upload_logs')
        def on_pulse_agent_upload_logs(ws, data):
            logging.info("[%s] Received collect and upload logs command", env.upper())
            on_demand_jobs.upload_log_files_to_server(env, data['sfIssueId'],
                                                      data['logs'],
                                                      data['s3Configs'])

        @self.client.on('image_upgrade_sync')
        def on_pulse_agent_upload_logs(ws, data):
            logging.info("[%s] Received image upgrade sync request", env.upper())
            image_upgrader_facade.upgrade_flag_status()

        @self.client.on('image_upgrade')
        def on_pulse_agent_upload_logs(ws, data):
            logging.info("[%s] Received image upgrade flag setting request", env.upper())
            image_upgrader_facade.insert_flag(data['action'])

    def send_system_stats_update(self):
        """ Sends stats """
        self.client.send('HEART_BEAT', stats_facade.gather_stats(self.env))

    def get_client(self):
        return self.client

    def start_job(self):
        self.client.connect(reconnect=config.RECONNECT_INTERVAL)
