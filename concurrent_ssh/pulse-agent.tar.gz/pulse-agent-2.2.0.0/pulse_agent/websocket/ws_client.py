import websocket
import json
import logging
import random
import Queue
import threading
import time


class WebSocketClient(websocket.WebSocketApp):
    def __init__(self, url):
        self.url = url
        self.is_connected = False
        self.is_processing = False
        self.message_callbacks = {}
        self.message_queue = Queue.Queue()

        super(WebSocketClient, self).__init__(self.url,
                                              on_open=self.on_open,
                                              on_close=self.on_close,
                                              on_error=self.on_error,
                                              on_message=self.on_message)

    def connect(self, reconnect=0, timeout=5):
        websocket.setdefaulttimeout(timeout)

        while True:
            logging.debug("WebSocket is connecting.")
            self.run_forever()

            if reconnect == 0 or reconnect is None:
                break
            time.sleep(reconnect + random.randint(1, 30))

    def on_open(self, ws):  # pylint: disable=method-hidden
        self.is_connected = True
        logging.debug("WebSocket connected.")
        if not self.is_processing:
            self.process_messages()

        if 'open' in self.message_callbacks:
            self.message_callbacks['open'](self)

    def on_close(self, ws):  # pylint: disable=method-hidden
        self.is_connected = False
        logging.critical("WebSocket disconnected.")

        if 'close' in self.message_callbacks:
            self.message_callbacks['close'](self)

    def on_error(self, ws, error):  # pylint: disable=method-hidden
        logging.error("WebSocket error: %s" % error)

    def on_message(self, ws, message):  # pylint: disable=method-hidden
        self.message_queue.put(message)

    def process_messages(self):
        def _worker():
            self.is_processing = True
            logging.debug("Started processing messages.")

            while True:
                message = json.loads(self.message_queue.get())
                name = message['name']
                data = message['data']

                if name in self.message_callbacks:
                    self.message_callbacks[name](self, data)

            logging.debug("Stopped processing messages.")

        worker_thread = threading.Thread(target=_worker)
        worker_thread.daemon = True
        worker_thread.start()

    def send(self, name, data):
        message = json.dumps({'name': name, 'data': data})

        if self.is_connected:
            super(WebSocketClient, self).send(message)

    def on(self, name):
        def decorator(f):
            self.message_callbacks[name] = f

        return decorator
