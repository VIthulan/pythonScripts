# Pulse Agent V2
This is the biggest update to the pulse agent in the recent history. 
The core architecture of the application was changed and the most visible change is the new directory structure, 
which was mostly adopted from the Pulse API.


## Getting Started
This project is setup using `setuptools` and `ditutils` packages.
Thus standard `setuptools` commands should work as expected.

For example, to do a clean install, you can execute,

    python setup.py clean install
    # This takes the form `python setup.py <command(s)>`  
    
**A highly useful alias defined in the `setup.cfg` is the `build` command.**

    python setup.py build

This will run all necessary commands required 
for building a reliable shippable source distribution of the Pulse agent in the `dist/` directory.  


## Developer environment
It is highly recommended to use the virtualenv when working with this project.
The `venv` directory is a placeholder for creating and using a virtualenv.

Following commands are worth mentioning,

    # Create a virtualenv in `venv` directory
    virtualenv venv

    # Activate virtualenv
    source venv/bin/activate

    # Install dependencies
    pip install -r requirements.txt

    # Start working :D

    # deactivate virtual env
    deactivate
    

## Testing
The package used for writing tests is `pytest`. It is integrated with `setuptools` using `pytest-runner`.

To run tests,
    
    python setup.py test
    
While the above command will run tests, it will also trigger a `pylint` run.
This is because `pylint` is integrated with `pytest` using `pytest-pylint`.

Test coverage results generated using `pytest-cov` will be saved to the `htmlcov/` directory & to the`.coverage` file.

Test coverage configs can be done in the `.coveragerc` config file 


## PET: Python Elegant Tool
**To make things even easier** for the regular developers, the `pet` script is included 

To run the script, you must source it.

    source pet
    
This will
create a virtual environment, 
activate it,
install dependencies
create git-hooks 
& create a few aliases.

Now you can use the `pet` command to run setuptools commands 
in a quite **elegant**(*guess how the name `pet` came to exist :D*) way.

    # Activate virtual environment
    pet venv
    
    # Create source distribution
    pet build
    
    # Run tests
    pet test
    
    # Clean build, dist and coverage
    pet clean

Also, the registered git-hooks will be triggered when you commit or push changes to git.

### Upgrading PET
When you first ran `source pet`, two main things happened.

1. A `.petrc` file was created in your `home` directory 
2. An entry was added to your profile config(eg: `.bashrc`) to source the `.petrc` file

The profile config will be updated only once in a life time. 
But the `.petrc` will be replaced with the `petrc` file contents every time you run `source pet`.

Thus to upgrade pet, follow these steps,

1. Update the `petrc` file.
2. Update the version in the `petrc` file.
3. Run `source pet`.

### Adding New Commands to PET 
With the introduction of the `scripts.json` file, adding new commands to pet has become a piece of cake, and
you rarely (or hopefully never) would want to modify the petrc.

To add a new command, all you have to do is add the command to the `scripts.json` file.

#### How does the scripts.json file function?
When you run `pet <my_command>`, pet will first check if `<my_command>` is there in the `scripts.json` file.
If it is there, the corresponding command will be run. 

If the `<my_command>` is not there in the `scripts.json` file, then pet will assume that it is a 
setuptools command. Hence it will be executed as `python setup.py <my_command>`

You can even chain pet commands in every possible way. For example, if you have two commands, say `abc` and `xyz`,
then you can have a 3rd command `klm` by chaining the first two commands. For example,

    {
        "abc": "some command",
        "xyz": "some other command",
        "klm": "pet abc && pet xyz"
    }  
