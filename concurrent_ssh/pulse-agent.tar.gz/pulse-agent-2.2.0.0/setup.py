"""
Root setup module
"""
import setuptools
from pulse_agent.distutils_commands import SDistProd, SDistDev, SDistQA, CleanCoverage

setuptools.setup(
    name='pulse-agent',
    version='2.2.0.0',
    description='Cake Pulse Agent.',
    author='Ops Engineering',
    author_email='OpsEngineering@syscolabs.com',
    url='https://stash.leapset.com/projects/OE/repos/pulse-agent-v2',
    install_requires=[
        'click==3.1',
        'websocket-client==0.16.0',
        'requests==2.5.3',
        'configobj==5.0.6',
        'speedtest-cli'
    ],
    packages=setuptools.find_packages(),
    data_files=[('', ['meta.conf', 'auth.conf'])],
    scripts=[
        'pulse_agent/pulse-agent'
    ],
    tests_require=[
        'pytest',
        'mock',
        'pytest-pylint',
        'pytest-cov'
    ],
    cmdclass={
        'dev': SDistDev,
        'qa': SDistQA,
        'prod': SDistProd,
        'clean_cov': CleanCoverage
    }
)
