"""
Automation script to install pulse agent in test POS devices
"""
import subprocess
import getpass
import time
import paramiko
from pulse_agent.utils.config.config import VERSION

TAR_BALL_NAME = 'pulse-agent-%s.tar.gz' % VERSION
IP_LIST = ['10.10.10.91', '10.10.10.121']

print subprocess.Popen('python setup.py install', stdout=subprocess.PIPE, shell=True).communicate()
print subprocess.Popen('python setup.py sdist', stdout=subprocess.PIPE, shell=True).communicate()

PASSWORD = getpass.getpass("POS root password?\n")

for ip in IP_LIST:
    command = 'scp dist/%s root@%s:/home/leapset' % (TAR_BALL_NAME, ip)
    print command
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True, stdin=subprocess.PIPE)
    process.communicate()

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ip, 22, 'root', PASSWORD)

    stdin1, stdout1, stderr1 = ssh.exec_command('service lp-pulse stop')
    exit_status1 = stdout1.channel.recv_exit_status()  # Blocking call
    if exit_status1 == 0:
        print "Service stopped"
    else:
        print "Couldn't stop lp-pulse", exit_status1

    stdin2, stdout2, stderr2 = ssh.exec_command('pip uninstall --yes pulse-agent')
    while not stdout2.channel.eof_received:
        time.sleep(1)
    print "Uninstalled pulse agent"

    install_agent = 'pip install /home/leapset/%s' % TAR_BALL_NAME
    stdin3, stdout3, stderr3 = ssh.exec_command(install_agent)
    exit_status3 = stdout3.channel.recv_exit_status()  # Blocking call
    if exit_status3 == 0:
        print "Installed new agent"
    else:
        print "Couldn't install new agent", exit_status3

    stdin4, stdout4, stderr4 = ssh.exec_command('service lp-pulse restart')
    exit_status4 = stdout4.channel.recv_exit_status()  # Blocking call
    if exit_status4 == 0:
        print "Restarted lp-pulse service"
    else:
        print "Couldn't restart lp-pulse service", exit_status4

    ssh.close()
