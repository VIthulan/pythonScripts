#!/usr/bin/env bash

find pulse_agent/ -iname "*.py" | xargs pylint $1 $2 $3