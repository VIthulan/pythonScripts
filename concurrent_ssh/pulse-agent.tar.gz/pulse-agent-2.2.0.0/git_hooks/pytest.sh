#!/usr/bin/env bash

# This is only a placeholder script
# One possible enhancement is to find the unstaged files and run only the associated with them in pre-commit hook
python setup.py test