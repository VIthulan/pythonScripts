#!/usr/bin/env bash

running_dir="$(dirname "$0")"
source "$running_dir/common.sh" # Relative path


# Get the profile name based on the OS of the user
unameOut="$(uname -s)"
case "${unameOut}" in
    Linux*)     profile=".bashrc";;
    Darwin*)    profile=".bash_profile";;
esac

# However, we give precedence to zsh
zsh=`which zsh`
if [ "$zsh" == "" ]
then
    printf "${ORANGE}${BOLD}zsh is not installed${REGULAR}${NC}\n"
else
    profile=".zshrc"
fi

# Check if pet alias is already there
cat ~/${profile} | grep -q '.petrc'
if [ $? -eq 0  ]
then
    printf "${BLUE}${BOLD}petrc is already there in the profile config${REGULAR}${NC}\n"
else
    # Test if profile corresponding to OS exists. If not, skip persisting aliases
    ${1+"test" "-f" "~/$profile"}
    if [ "$?" -ne 0 ]
    then
        printf "${RED}${BOLD}Unable to detect user profile config. Skipping persistent aliases${REGULAR}${NC}\n"
    else
        # Add aliases to profile config and source it
        echo "source ~/.petrc" >> ~/${profile}
    fi
fi

# Finally source the user profile config
source ~/${profile}
