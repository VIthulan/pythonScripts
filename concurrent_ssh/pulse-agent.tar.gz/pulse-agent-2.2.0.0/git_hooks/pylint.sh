#!/usr/bin/env bash

# Pylint is run by the git-pylint-commit-hook package
# This is to run pylint only on staged files
# Read their docs for more info
git-pylint-commit-hook --limit 9