#!/usr/bin/env bash
bash git_hooks/pre-push.sh
exit $?
