#!/usr/bin/env bash

running_dir="$(dirname "$0")"

# Font-Weights
BOLD=$(tput bold)
REGULAR=$(tput sgr0)

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0;0m'
ORANGE='\e[38;5;214m'


# Print a formatted success/failure message
print_message(){
    exit_code=$1
    if [ ${exit_code} -eq 0 ]
    then
      printf "${GREEN}==>${BOLD}Hook:${BLUE}${BOLD} $2 ${NC}${BOLD}executed successfully ${NC}${REGULAR}\n"
    else
      printf "${GREEN}==>${BOLD}Hook:${RED}${BOLD} $2 exited with status: $exit_code ${NC}${REGULAR}\n"
    fi
}

# Execute a bash script and print status message
execute() {
    ${1+"bash" "$running_dir/$1"}
    exit_code=$?

    print_message ${exit_code} $2

    if [ ${exit_code} -ne 0 ]
        then
            exit ${exit_code}
    fi
}
