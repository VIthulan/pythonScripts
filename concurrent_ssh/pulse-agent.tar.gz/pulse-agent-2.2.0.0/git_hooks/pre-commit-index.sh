#!/usr/bin/env bash
bash git_hooks/pre-commit.sh
exit $?
