#!/usr/bin/env bash
# Stops committing debug commands like print

FILES_PATTERN='\.(py)(\..+)?$'

FORBIDDEN='^print' # Uses shell-script regex format

git diff --cached --name-only | \
    grep -E ${FILES_PATTERN} | \
    GREP_COLOR='1;31' xargs grep --color --with-filename -n ${FORBIDDEN} \
    && echo "Found Forbidden references(i.e. ${FORBIDDEN}). Please remove them before committing" \
    && exit 1

exit 0