#!/usr/bin/env bash

running_dir="$(dirname "$0")"
source "$running_dir/common.sh" # Relative path

# Execute scripts
execute forbidden_commands.sh "forbidden_Commands"
execute branch.sh "Git_branch"
execute pytest.sh "Pytest"

exit 0